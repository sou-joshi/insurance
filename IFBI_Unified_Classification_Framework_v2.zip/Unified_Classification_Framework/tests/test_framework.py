import copy,json,tempfile,unittest
from collections import defaultdict
from datetime import datetime,timedelta,timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from ucf.core import *
from ucf.model import train,predict,restore,split_group
from ucf.app import run,prepare_state,recommend,SingleWriter,approve_model
from ucf.monitor import evaluate,ScopeError
from ucf.warehouse import Warehouse,Journal

ROOT=Path(__file__).resolve().parents[1]
def config():
    c=load_config(ROOT/'config.toml');c['notifications']['enabled']=False
    c['content']['enabled']=False;c['anomalies']['enabled']=False;c['ml']['enabled']=True
    return c
def raw(name='customer_id',label=None,table_name='customers'):
    return dict(catalog_name='ifbi_edw_dev_raw',schema_name='source',table_name=table_name,column_name=name,
      data_type='string',description=None,sensitivity_values=[] if label is None else [label],signals=[],remediation_owner='Owner')
def gold_fixture():
    c=config();rows=[];reviews=[]
    keywords=['social security number person identifier','bank account routing payment identifier',
              'customer email contact telephone address','pipeline batch ingestion technical status']
    for li,label in enumerate(LABELS):
        for part,minimum in [('TRAIN',6),('CALIBRATION',4),('TEST',4)]:
            count=0;i=0
            while count<minimum:
                group=f'domain_{li}_{part}_{i}';i+=1
                if split_group(group,c['ml']['seed'])!=part:continue
                r=decorate(raw(f'field_{li}_{part}_{count}',label,group));rows.append(r)
                reviews.append(dict(asset_key=r['asset_key'],input_hash=r['input_hash'],evidence_hash=r['evidence_hash'],
                  decision='APPROVED',label=label,logical_group=group,sanitized_text=keywords[li]+' '+group,
                  reviewer='synthetic_steward',reason='Synthetic fixture only',reviewed_at=now()))
                count+=1
    return c,rows,reviews

class MemoryJournal:
    def __init__(self):self.records=[]
    def append(self,run_id,kind,records):
        for key,payload in records:
            if not any(r['_run_id']==run_id and r['_record_id']==key and r['_kind']==kind for r in self.records):
                self.records.append(dict(copy.deepcopy(payload),_record_id=key,_run_id=run_id,_kind=kind))
    def read(self,kind,run_id=None,published=True):
        committed={r['_run_id'] for r in self.records if r['_kind']=='RUN'}
        return [copy.deepcopy(r) for r in self.records if r['_kind']==kind and (run_id is None or r['_run_id']==run_id) and (not published or r['_run_id'] in committed)]
    def latest_run(self):
        rows=self.read('RUN',published=False)
        return dict(rows[-1],run_id=rows[-1]['_run_id']) if rows else None
    def load_state(self,run_id):
        h=self.read('CONTROL',run_id)[0]
        return dict(control=h['control'],summary=h['summary'],**{key:{r['_record_id']:clean(r) for r in self.read(kind,run_id)} for kind,key in [('COLUMN','columns'),('ISSUE','issues'),('NOTICE','pending')]})
    publish=Journal.publish
def clean(r):return {k:v for k,v in r.items() if not k.startswith('_')}
class FakeWarehouse:
    def __init__(self,rows):self.rows=rows;self.calls=0
    def collect(self):self.calls+=1;return copy.deepcopy(self.rows)
    def rules(self):return []
    def identity(self):return {'metadata_reader':'fixture','metastore_id':'fixture','workspace_host':'https://fixture'}

class FrameworkTests(unittest.TestCase):
    def test_missing_and_conflict_preserved(self):
        self.assertEqual(decorate(raw())['sensitivity_state'],'Missing sensitivity tag')
        x=raw();x['sensitivity_values']=[LABELS[0],LABELS[3]]
        self.assertEqual(decorate(x)['sensitivity_state'],'Conflicting sensitivity values')
    def test_distinct_identity_same_name(self):
        self.assertNotEqual(decorate(raw(table_name='a'))['asset_key'],decorate(raw(table_name='b'))['asset_key'])
    def test_target_leakage_not_features(self):
        r=decorate(raw(label=LABELS[0]));self.assertNotIn(LABELS[0],r['feature_text'])
    def test_basic_redaction(self):self.assertNotIn('person@example.com',redacted_text('person@example.com token=abc 123456789'))
    def test_rule_conflict_abstains(self):
        r=decorate(raw());r['signals']=[{'tag_name':'auto_class','tag_value':'Person'}]
        rules=[dict(source_tag_name='auto_class',source_tag_value='Person',ifbi_classification=s,tier_priority=PRIORITY[s]) for s in LABELS[:2]]
        self.assertEqual(mapped_requirement(r,rules,['auto_class'])[0],None)
        rec,_=recommend([r],rules,config(),None);self.assertEqual(rec[0]['recommendation_status'],'CONFLICTING_EVIDENCE')
    def test_no_model_honest_abstention(self):
        rec,_=recommend([decorate(raw())],[],config(),None)
        self.assertIsNone(rec[0]['recommended_label'])
    def test_sample_excludes_connector_and_balances_tables(self):
        rows=[decorate(raw(str(i),LABELS[3],'big')) for i in range(100)]+[decorate(raw('small',LABELS[3],'small')),decorate(raw('_fivetran_synced'))]
        c=config()['review'];c['per_label']=2
        sample=review_sample(rows,c)
        self.assertEqual(len(sample),2);self.assertEqual(len({r['table_key'] for r in sample}),2)
    def test_stale_gold_excluded(self):
        c,rows,decisions=gold_fixture();rows[0]['input_hash']='changed'
        self.assertEqual(len(accepted_gold(rows,decisions)),len(rows)-1)
    def test_disputed_latest_review_wins(self):
        c,rows,decisions=gold_fixture();new=dict(decisions[0],decision='DISPUTED')
        self.assertEqual(len(accepted_gold(rows,decisions+[new])),len(rows)-1)
    def test_identical_input_transitive_group_union(self):
        c,rows,d=gold_fixture();d=d[:3];rows=rows[:3]
        d[0]['logical_group']='A';d[1]['logical_group']='B';d[2]['logical_group']='B'
        d[0]['sanitized_text']=d[1]['sanitized_text']='same'
        self.assertEqual(len({g['logical_group'] for g in accepted_gold(rows,d)}),1)
    def test_group_split_deterministic(self):self.assertEqual(split_group('sourceA','seed'),split_group('sourceA','seed'))
    def test_dashboard_uses_shared_environment_bindings(self):
        from ucf.views import dashboard_queries
        c=config();c.update(output_catalog='other_raw',output_schema='observability',table_prefix='classification')
        query=dashboard_queries(c)
        self.assertIn('`other_raw`.`observability`.`classification_health`',query)
        self.assertNotIn('ifbi_edw_dev_raw',query)
    def test_missing_class_support_blocks_training(self):
        artifact,metrics=train([],config()['ml']);self.assertIsNone(artifact);self.assertIn('WAITING',metrics['status'])
    def test_model_json_roundtrip_and_metrics(self):
        c,rows,d=gold_fixture();gold=accepted_gold(rows,d)
        artifact,metrics=train(gold,c['ml']);self.assertIsNotNone(artifact)
        text=['social security number person identifier','bank account routing payment identifier']
        before=predict(artifact,text);after=predict(json.loads(dumps(artifact)),text)
        self.assertEqual(before,after);self.assertTrue(metrics['quality_gate_passed'])
        self.assertEqual(before[0]['model_label'],LABELS[0]);self.assertEqual(before[0]['score_interpretation'],'UNCALIBRATED_MODEL_SCORE')
    def test_version_mismatch_rejected(self):
        c,rows,d=gold_fixture();a,_=train(accepted_gold(rows,d),c['ml']);a['sklearn_version']='invalid'
        with self.assertRaises(ValueError):restore(a)
    def test_baseline_one_activation_not_incidents(self):
        c=config();rows=[decorate(raw(str(i))) for i in range(1000)]
        state=prepare_state(rows,[],None,{'actor':'x'},c,[])
        self.assertEqual(len(state['pending']),1);self.assertEqual(len(state['issues']),0)
    def test_new_untagged_after_grace(self):
        c=config();settings=dict(c['monitor'],maximum_columns=100,maximum_inventory_drop_fraction=.2)
        row=dict(decorate(raw(label=LABELS[3])),expected_priority=None,expected_sensitivity=None,invalid_rule_label_count=0)
        t=datetime.now(timezone.utc);s=evaluate([row],None,t,{},'scope',settings)
        new=dict(decorate(raw('new')),expected_priority=None,expected_sensitivity=None,invalid_rule_label_count=0)
        s=evaluate([row,new],s,t+timedelta(minutes=1),{},'scope',settings)
        self.assertEqual(s['summary']['new_untagged_open'],0)
        s=evaluate([row,new],s,t+timedelta(minutes=32),{},'scope',settings)
        self.assertEqual(s['summary']['new_untagged_open'],1)
    def test_lost_schema_not_recovery(self):
        c=config();r=decorate(raw(label=LABELS[3]));s=prepare_state([r],[],None,{},c,[])
        other=dict(r,schema_name='other')
        with self.assertRaises(ScopeError):prepare_state([other],[],s,{},c,[])
    def test_pipeline_and_replay_collect_once(self):
        c=config();j=MemoryJournal();w=FakeWarehouse([raw(label=LABELS[3])])
        out=run(w,j,c,'run1');again=run(w,j,c,'run1')
        self.assertEqual(w.calls,1);self.assertTrue(again['reused_committed_run']);self.assertEqual(out['inventory_columns'],1)
    def test_partial_stage_invisible_and_retry_rejected(self):
        c=config();j=MemoryJournal();w=FakeWarehouse([raw()]);j.append('broken','ATTEMPT',[('broken',{})]);j.append('broken','SNAPSHOT',[('x',{})])
        self.assertEqual(j.read('SNAPSHOT'),[])
        with self.assertRaises(RuntimeError):run(w,j,c,'broken')
    def test_changed_identity_blocks_publication(self):
        c=config();j=MemoryJournal();w=FakeWarehouse([raw()]);run(w,j,c,'one')
        w.identity=lambda:{'metadata_reader':'other'}
        with self.assertRaises(ScopeError):run(w,j,c,'two')
        self.assertEqual(j.latest_run()['run_id'],'one')
    def test_changed_input_rescores_unchanged_reuses(self):
        c=config();r=decorate(raw());a,n=recommend([r],[],c,None)
        b,n=recommend([r],[],c,None,a);self.assertEqual(a,b)
        changed=dict(r,input_hash='different');b,n=recommend([changed],[],c,None,a)
        self.assertNotEqual(a[0]['recommendation_signature'],b[0]['recommendation_signature'])
    def test_mapping_order_does_not_invalidate_recommendations(self):
        c=config();r=decorate(raw());rules=[{'source_tag_name':'auto_class','source_tag_value':'A','ifbi_classification':LABELS[0],'tier_priority':1},
          {'source_tag_name':'auto_class','source_tag_value':'B','ifbi_classification':LABELS[1],'tier_priority':2}]
        first,_=recommend([r],rules,c,None)
        again,_=recommend([r],list(reversed(rules)),c,None,first)
        self.assertEqual(first,again)
    def test_local_writer_lock(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'writer'
            with SingleWriter(path):
                with self.assertRaises(RuntimeError):
                    with SingleWriter(path):pass
            self.assertFalse(path.exists())
    def test_end_to_end_gold_candidate_approval_and_incremental_score(self):
        c,rows,d=gold_fixture();j=MemoryJournal();w=FakeWarehouse([])
        # Pass raw rows to the real collector adapter, not pre-decorated records.
        w.rows=[{k:r[k] for k in ('catalog_name','schema_name','table_name','column_name','data_type','description','sensitivity_values','signals','remediation_owner')} for r in rows]
        first=run(w,j,c,'first');self.assertIsNone(first['active_model_id'])
        j.append('steward','REVIEW',[(str(i),x) for i,x in enumerate(d)])
        second=run(w,j,c,'second');self.assertEqual(second['model_stage']['status'],'CANDIDATE_EVALUATED')
        candidate=j.read('MODEL')[-1]
        approve_model(j,w,c,SimpleNamespace(model_id=candidate['model_id'],reason='Synthetic test approval'))
        third=run(w,j,c,'third');self.assertEqual(third['active_model_id'],candidate['model_id'])
        self.assertEqual(third['model_scored_rows'],len(rows))
        fourth=run(w,j,c,'fourth');self.assertEqual(fourth['model_scored_rows'],0)
        self.assertEqual(len(j.read('MODEL')),1)
    def test_ml_dependency_failure_keeps_monitor_running(self):
        c=config();j=MemoryJournal();w=FakeWarehouse([raw()])
        with patch('ucf.app.train',side_effect=ImportError('dependency unavailable')):
            out=run(w,j,c,'run')
        self.assertEqual(out['model_stage']['status'],'ML_STAGE_ERROR')
        self.assertEqual(j.latest_run()['run_id'],'run')
    def test_bulk_review_stale_decision_guard_and_idempotency(self):
        import csv
        from ucf.app import review_export,review_import
        c=config();j=MemoryJournal();w=FakeWarehouse([raw()]);run(w,j,c,'first')
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'review.csv';args=SimpleNamespace(file=str(path))
            review_export(j,args)
            with open(path,newline='') as f: reader=csv.DictReader(f);fields=reader.fieldnames;data=list(reader)
            data[0].update(decision='APPROVED',label=LABELS[3],logical_group='original_source_table',reason='Reviewed source metadata')
            def write():
                with open(path,'w',newline='') as f:
                    out=csv.DictWriter(f,fieldnames=fields);out.writeheader();out.writerows(data)
            write();review_import(j,w,args);review_import(j,w,args)
            self.assertEqual(len(j.read('REVIEW',published=False)),1)
            data[0]['label']=LABELS[0];write()
            with self.assertRaises(ValueError):review_import(j,w,args)

class NotificationTests(unittest.TestCase):
    def test_definition_and_subscriber(self):
        from ucf.notifications import alert_definitions
        c=config();defs=alert_definitions(c)
        self.assertEqual(defs['changes']['schedule']['pause_status'],'PAUSED')
        self.assertEqual(defs['health']['schedule']['pause_status'],'UNPAUSED')
        self.assertEqual(defs['changes']['evaluation']['notification']['subscriptions'],[{'user_email':'C000926@infarmbureau.com'}])
        self.assertNotIn('column_name',defs['changes']['query_text'])
    def test_receipt_only_after_success(self):
        from ucf.notifications import evaluate_alert
        c=config();c['notifications']['enabled']=True;j=MemoryJournal();calls=[]
        def api(method,path,**kw):
            calls.append((method,path,kw))
            if method=='POST':return {'run_id':9}
            return {'state':{'life_cycle_state':'TERMINATED','result_state':'SUCCESS'}}
        w=SimpleNamespace(client=SimpleNamespace(api_client=SimpleNamespace(do=api)))
        notices=[{'notice_id':'notice','selected_for_batch':True}]
        outcome=evaluate_alert(w,j,c,{'changes':'alert'},notices)
        self.assertIn('DELIVERY_NOT_ATTESTED',outcome)
        self.assertEqual(len(j.read('ACK',published=False)),1)
        self.assertEqual(len(calls[0][2]['body']['idempotency_token']),64)
    def test_failed_evaluation_keeps_unacknowledged(self):
        from ucf.notifications import evaluate_alert
        c=config();c['notifications']['enabled']=True;j=MemoryJournal()
        def api(method,path,**kw):
            return {'run_id':9} if method=='POST' else {'state':{'life_cycle_state':'TERMINATED','result_state':'FAILED'}}
        w=SimpleNamespace(client=SimpleNamespace(api_client=SimpleNamespace(do=api)))
        with self.assertRaises(RuntimeError):evaluate_alert(w,j,c,{'changes':'alert'},[{'notice_id':'n','selected_for_batch':True}])
        self.assertEqual(j.read('ACK',published=False),[])

class TransportTests(unittest.TestCase):
    def w(self,replies):
        class Api:
            def do(self,*a,**kw):return replies.pop(0)
        return Warehouse(config(),SimpleNamespace(api_client=Api()))
    def test_chunk_pagination(self):
        first={'statement_id':'abc','status':{'state':'SUCCEEDED'},'manifest':{'schema':{'columns':[{'name':'x'}]},'total_row_count':2},
          'result':{'data_array':[['one']],'next_chunk_internal_link':'/api/2.0/sql/statements/abc/result/chunks/1'}}
        rows=self.w([first,{'data_array':[['two']]}]).sql('SELECT x')
        self.assertEqual(rows,[{'x':'one'},{'x':'two'}])
    def test_truncation_rejected(self):
        with self.assertRaises(RuntimeError):self.w([{'statement_id':'x','status':{'state':'SUCCEEDED'},'manifest':{'truncated':True}}]).sql('SELECT x')
    def test_external_link_rejected(self):
        response={'statement_id':'x','status':{'state':'SUCCEEDED'},'manifest':{},'result':{'next_chunk_internal_link':'https://other-host/file'}}
        with self.assertRaises(RuntimeError):self.w([response]).sql('SELECT x')
    def test_incomplete_count_rejected(self):
        response={'statement_id':'x','status':{'state':'SUCCEEDED'},'manifest':{'total_row_count':1}}
        with self.assertRaises(RuntimeError):self.w([response]).sql('SELECT x')
    def test_malformed_result_rejected(self):
        response={'statement_id':'x','status':{'state':'SUCCEEDED'},'manifest':{'schema':{'columns':[{'name':'x'}]}},'result':{'data_array':[['one','two']]}}
        with self.assertRaises(RuntimeError):self.w([response]).sql('SELECT x')
    def test_failed_sql_does_not_print_sensitive_message(self):
        response={'statement_id':'x','status':{'state':'FAILED','error':{'message':'SECRET'}}}
        with self.assertRaises(RuntimeError) as err:self.w([response]).sql('SELECT x')
        self.assertNotIn('SECRET',str(err.exception))

if __name__=='__main__':unittest.main()
