import copy,json,tempfile,unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from test_framework import config,raw,MemoryJournal,FakeWarehouse
from ucf.core import decorate,digest,now,dumps,LABELS
from ucf.value_models import Span,Ensemble,fuse,luhn,vin_valid,chunks
from ucf.content_config import content_settings
from ucf.content import profile_column,reconciliation,sample_query,read_sample_batches,scan,drift
from ucf.content_alerts import update,merge_notices
from ucf.quality import evaluate_file,wilson,match
from ucf.anomalies import calibrated_findings,settings as anomaly_settings
from ucf.assets import verify_bundle,sha256

def settings():
    c=config();c['content']['enabled']=True;c['content']['require_delta_snapshot']=False
    return content_settings(c)

class Detector:
    def __init__(self,name):self.name=name
    def detect(self,text):
        import re
        return [Span(x.start(),x.end(),'EMAIL',.99,self.name) for x in re.finditer(r'[\w.+-]+@[\w.-]+\.[A-Za-z]+',text)]
def ensemble():return Ensemble([Detector('modelA'),Detector('modelB')],settings())

class FusionTests(unittest.TestCase):
    def test_same_span_two_models(self):
        out=fuse('Jane Doe',[Span(0,8,'PERSON',.95,'a'),Span(0,8,'PERSON',.9,'b')])
        self.assertTrue(out[0]['consensus']);self.assertEqual(out[0]['evidence_strength'],.9)
    def test_different_spans_cannot_vote_together(self):
        out=fuse('Jane Doe Bob Smith',[Span(0,8,'PERSON',.95,'a'),Span(9,18,'PERSON',.9,'b')])
        self.assertFalse(any(x['consensus'] for x in out))
    def test_duplicate_source_not_extra_vote(self):
        out=fuse('Jane Doe',[Span(0,8,'PERSON',.95,'a')]*3)
        self.assertFalse(out[0]['consensus'])
    def test_low_score_cannot_corroborate(self):
        out=fuse('Jane Doe',[Span(0,8,'PERSON',.95,'a'),Span(0,8,'PERSON',.6,'b')])
        self.assertFalse(out[0]['consensus'])
    def test_one_model_with_validated_ssn(self):
        out=fuse('123-45-6789',[Span(0,11,'SSN',.96,'a')])
        self.assertTrue(out[0]['consensus'])
    def test_validator_only_is_not_ml_consensus(self):self.assertFalse(fuse('123-45-6789',[])[0]['consensus'])
    def test_organization_cannot_veto_validated_ssn(self):
        out=fuse('123-45-6789',[Span(0,11,'SSN',.96,'a'),Span(0,11,'ORGANIZATION',.99,'b')])
        self.assertTrue(next(x for x in out if x['entity']=='SSN')['consensus'])
    def test_competing_sensitive_labels_require_review(self):
        out=fuse('ABCDEFGH',[Span(0,8,'POLICY_ID',.95,'a'),Span(0,8,'POLICY_ID',.96,'b'),Span(0,8,'CLAIM_ID',.95,'a')])
        self.assertFalse(any(x['consensus'] for x in out))
    def test_malformed_model_spans_rejected(self):
        for s in [Span(0,100,'PERSON',.9,'a'),Span(0,3,'PERSON',float('nan'),'a')]:
            with self.assertRaises(ValueError):fuse('Joe',[s])
    def test_luhn_and_vin_checks(self):
        self.assertTrue(luhn('4111 1111 1111 1111'));self.assertFalse(luhn('0000000000000000'))
        self.assertTrue(vin_valid('1M8GDM9AXKP042788'));self.assertFalse(vin_valid('1M8GDM9A1KP042788'))
    def test_batch_equals_single(self):
        e=ensemble();values=['a@example.com','nothing','b@example.com']
        self.assertEqual(e.identify_many(values),[e.identify(x) for x in values])
    def test_overlapping_chunks_no_extra_model_votes(self):
        e=ensemble();self.assertTrue(e.identify(' '*210+'a@example.com'+' '*200)[0]['consensus'])
    def test_chunk_boundaries(self):
        self.assertEqual(list(chunks('abc',64,8)),[(0,'abc')])
        with self.assertRaises(ValueError):list(chunks('abc',64,64))

class ProfileTests(unittest.TestCase):
    def profile(self,values,row=None):return profile_column(row or decorate(raw('contact')),values,ensemble(),settings(),'signature')
    def test_raw_values_never_persist(self):
        p=self.profile(['secret@example.com']*12)
        self.assertNotIn('secret@example.com',dumps(p));self.assertTrue(p['sensitive_signal'])
    def test_all_null_is_insufficient_not_safe(self):self.assertEqual(self.profile([None]*12)['profile_status'],'ALL_NULL_OR_MASKED')
    def test_empty_sample_is_not_safe(self):self.assertEqual(self.profile([])['profile_status'],'EMPTY_SAMPLE')
    def test_no_detection_never_assigns_internal(self):
        r=decorate(raw('x'));p=self.profile(['123']*12,r)
        out=reconciliation(r,p,(None,0),settings())
        self.assertIsNone(out['recommended_label'])
    def test_model_input_has_no_existing_label(self):
        seen=[]
        class E:
            def identify_many(self,x):seen.extend(x);return [[] for _ in x]
        r=decorate(raw('x',LABELS[0]));profile_column(r,['opaque']*12,E(),settings(),'sig')
        self.assertNotIn(LABELS[0],str(seen))
    def test_context_only_entities_cannot_become_value_evidence(self):
        r=decorate(raw('secret@example.com'));p=self.profile(['123']*12,r)
        self.assertFalse(p['sensitive_signal'])
    def test_existing_unprotected_column_mismatch(self):
        r=decorate(raw('contact',LABELS[3]));p=self.profile(['abc@example.com']*12,r)
        out=reconciliation(r,p,(None,0),settings())
        self.assertEqual(out['recommended_label'],LABELS[1]);self.assertIn('CONTENT_TIER_STRONGER_THAN_EXISTING',out['findings'])
    def test_stronger_existing_tier_no_automatic_downgrade(self):
        r=decorate(raw('contact',LABELS[0]));out=reconciliation(r,self.profile(['a@example.com']*12,r),(None,0),settings())
        self.assertEqual(out['recommendation_status'],'REVIEW_POSSIBLE_DOWNGRADE')
    def test_source_conflict_retains_ml_label_but_abstains_recommendation(self):
        r=decorate(raw());out=reconciliation(r,self.profile(['a@example.com']*12,r),(LABELS[0],0),settings())
        self.assertEqual(out['ml_identified_label'],LABELS[1]);self.assertIsNone(out['recommended_label'])
    def test_collate_comparison(self):
        r=decorate(raw());out=reconciliation(r,self.profile(['a@example.com']*12,r),(None,0),settings(),
                {'status':'CURRENT_ASSIGNMENT','classifications':[LABELS[0]]})
        self.assertEqual(out['collate_comparison'],'DISAGREES')
    def test_strict_budgets(self):
        c=config();c['content']['chunk_chars']=1000
        with self.assertRaises(ValueError):content_settings(c)
    def test_query_quotes_identifiers_and_no_values(self):
        r=decorate(raw('a`b'));q=sample_query([r],settings(),42)
        self.assertIn('`a``b`',q);self.assertIn('VERSION AS OF 42',q)
        self.assertIn('TABLESAMPLE',q)
    def test_value_and_collate_sql_parses(self):
        try:import sqlglot
        except ImportError:self.skipTest('Optional SQL parser unavailable')
        for version in (None,42):
            sqlglot.parse_one(sample_query([decorate(raw('a`b'))],settings(),version),read='databricks',error_level='RAISE')
        from ucf.collate import collect
        c=config();c['collate'].update(enabled=True,service_by_catalog={c['source_catalogs'][0]:'service'})
        queries=[]
        collect(SimpleNamespace(sql=lambda q:queries.append(q) or []),[decorate(raw())],c)
        self.assertEqual(len(queries),1)
        sqlglot.parse_one(queries[0],read='databricks',error_level='RAISE')
    def test_sampler_rotates_unscanned_columns(self):
        c=config();c['content'].update(enabled=True,require_delta_snapshot=False,maximum_columns_per_run=1)
        rows=[decorate(raw('x')),decorate(raw('y'))]
        w=SimpleNamespace(sql=lambda q:[{'c0':'a@example.com','t0':False}]*12)
        first,_=scan(w,rows,c,ensemble=ensemble(),signature='s')
        next_,summary=scan(w,rows,c,first,ensemble=ensemble(),signature='s')
        self.assertEqual(sum(p['profile_status']=='PROFILED' for p in next_),2)
    def test_sampling_failure_is_degraded(self):
        c=config();c['content'].update(enabled=True,require_delta_snapshot=False)
        def fail(q):raise RuntimeError('sensitive secret value')
        profiles,summary=scan(SimpleNamespace(sql=fail),[decorate(raw())],c,ensemble=ensemble())
        self.assertEqual(summary['status'],'DEGRADED');self.assertNotIn('sensitive secret value',dumps(profiles))
    def test_wide_result_splits_without_dropping_columns(self):
        rows=[decorate(raw('a')),decorate(raw('b'))];calls=[]
        def sql(q):
            calls.append(q)
            if 'AS c1' in q:raise RuntimeError('TRUNCATED_RESULT_REJECTED')
            return [{'c0':'a@example.com','t0':False}]
        groups=list(read_sample_batches(SimpleNamespace(sql=sql),rows,settings(),None))
        self.assertEqual(sum(len(r) for r,_ in groups),2);self.assertEqual(len(calls),3)
    def test_model_volume_path_is_environment_derived(self):
        c=config();c.update(output_catalog='production_raw',output_schema='observability')
        c['content']['model_directory']=''
        self.assertEqual(content_settings(c)['model_directory'],'/Volumes/production_raw/observability/classification_models/ucf_v2')
    def test_readable_positive_change_drift(self):
        p={'profile_signature':'s','sampled_rows':100,'evaluated_rows':100,'null_fraction':0.,'entities':[]}
        q=dict(p,null_fraction=.9)
        self.assertIn('NULL_RATE_CHANGED',drift(p,q,settings()))
    def test_small_samples_not_declared_drift(self):
        p={'profile_signature':'s','sampled_rows':3,'evaluated_rows':3,'null_fraction':0.,'entities':[]}
        self.assertEqual(drift(p,dict(p,null_fraction=1.),settings()),[])

class AlertTests(unittest.TestCase):
    def fixture(self,name='contact'):
        r=decorate(raw(name));p=profile_column(r,['a@example.com']*12,ensemble(),settings(),'s')
        return r,p,reconciliation(r,p,(None,0),settings())
    def test_baseline_muted_and_one_digest(self):
        r,p,rec=self.fixture();s=update([r],[rec],[p],None,[],config())
        self.assertEqual(len(s['pending']),1);self.assertTrue(all(x['baseline_muted'] for x in s['issues'].values()))
    def test_delayed_first_scan_is_still_baseline(self):
        a,p,rec=self.fixture('a');b,q,brec=self.fixture('b')
        first=update([a,b],[rec],[p],None,[],config())
        second=update([a,b],[rec,brec],[p,q],first,[],config())
        self.assertTrue(all(x['baseline_muted'] for x in second['issues'].values()))
    def test_new_sensitive_column_alerts(self):
        a,p,rec=self.fixture('a');b,q,brec=self.fixture('b')
        first=update([a],[rec],[p],None,[],config())
        second=update([a,b],[rec,brec],[p,q],first,[],config())
        self.assertTrue(any(x['asset_key']==b['asset_key'] and not x['baseline_muted'] for x in second['issues'].values()))
    def test_absent_sample_cannot_resolve_sensitive_finding(self):
        r,p,rec=self.fixture();first=update([r],[rec],[p],None,[],config())
        missing=dict(rec,evidence_stale=True,findings=[])
        second=update([r],[missing],[],first,[],config())
        self.assertEqual(next(iter(second['issues'].values()))['status'],'EVIDENCE_GAP')
    def test_corrected_tag_can_resolve(self):
        r,p,rec=self.fixture();first=update([r],[rec],[p],None,[],config())
        corrected=dict(r,current_sensitivity=LABELS[0],actual_priority=1)
        second=update([corrected],[dict(rec,findings=[])],[p],first,[],config())
        self.assertEqual(next(iter(second['issues'].values()))['status'],'RESOLVED')

class EvaluationTests(unittest.TestCase):
    def test_perfect_tiny_set_cannot_pass_high_accuracy_gate(self):
        text='a@example.com'
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'test.jsonl';path.write_text(json.dumps({'id':'1','group':'source1','split':'TEST',
                'text':text,'entities':[{'start':0,'end':len(text),'entity':'EMAIL'}]})+'\n')
            result=evaluate_file(path,ensemble(),settings(),'bundle')
            self.assertEqual(result['overall']['precision'],1.)
            self.assertFalse(result['quality_gate_passed']);self.assertLess(result['overall']['precision_95ci'][0],.99)
            self.assertNotIn(text,dumps(result))
    def test_wilson_zero_support_not_perfect(self):self.assertIsNone(wilson(0,0))
    def test_matching_one_to_one(self):
        p=[{'start':0,'end':5,'entity':'PERSON'}]*2
        self.assertEqual(len(match(p,p[:1])[0]),1)
    def test_nonheldout_data_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'test.jsonl';p.write_text(json.dumps({'id':'1','group':'g','split':'TRAIN','text':'a','entities':[]}))
            with self.assertRaises(ValueError):evaluate_file(p,ensemble(),settings(),'bundle')
    def test_duplicate_text_cannot_inflate_accuracy_support(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'test.jsonl'
            p.write_text('\n'.join(json.dumps({'id':str(i),'group':'g'+str(i),'split':'TEST',
                'text':'same exact negative','entities':[]}) for i in range(2)))
            with self.assertRaises(ValueError):evaluate_file(p,ensemble(),settings(),'bundle')

class AnomalyTests(unittest.TestCase):
    def test_disjoint_calibration_and_correct_tail(self):
        import numpy as np
        cfg=anomaly_settings(config());rng=np.random.default_rng(19)
        class Scorer:
            def fit(self,x):self.reference=x.copy()
            def score(self,x):return -np.sum(x*x,axis=1)
        scorer=Scorer();ref=rng.normal(size=(256,3));cal=rng.normal(size=(128,3));test=rng.normal(size=(32,3));test[0]=100
        result=calibrated_findings(ref,cal,test,scorer,cfg)
        hit=next(r for r in result if r['candidate_index']==0)
        self.assertEqual(hit['evidence'],'TABPFN_AND_ROBUST');self.assertLessEqual(hit['tail_rank'],.01)
        self.assertTrue(np.array_equal(scorer.reference,ref.astype(np.float32)))
    def test_insufficient_calibration_resolution_rejected(self):
        c=config();c['anomalies']['tail_probability']=.0001
        with self.assertRaises(ValueError):anomaly_settings(c)

class AssetTests(unittest.TestCase):
    def bundle(self,root):
        m=settings()['models'][0];folder=root/m['name'];folder.mkdir()
        p=folder/'model.safetensors';p.write_bytes(b'unit-test-not-real-weights')
        manifest={'format':'ucf_local_models_v2','models':[m],
          'files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha256(p)}]}
        (root/'manifest.json').write_text(json.dumps(manifest));cfg=settings();cfg['models']=[m]
        return p,cfg
    def test_modified_weights_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p,cfg=self.bundle(root);verify_bundle(root,cfg);p.write_bytes(b'changed')
            with self.assertRaises(ValueError):verify_bundle(root,cfg)
    def test_revision_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p,cfg=self.bundle(root);cfg['models'][0]['revision']='wrong'
            with self.assertRaises(ValueError):verify_bundle(root,cfg)

class PipelineTests(unittest.TestCase):
    def test_value_path_never_requires_custom_training(self):
        from ucf.app import run
        c=config();c['content']['enabled']=True;c['ml']['enabled']=False
        row=decorate(raw());p=profile_column(row,['a@example.com']*12,ensemble(),settings(),'s')
        with patch('ucf.content.scan',return_value=([p],{'status':'COMPLETE','attempted_columns':1,'profile_signature':'s'})),patch('ucf.app.train',side_effect=AssertionError('must not train')):
            j=MemoryJournal();out=run(FakeWarehouse([raw()]),j,c,'content')
        self.assertEqual(out['model_stage']['status'],'PRETRAINED_CONTENT_INFERENCE')
        self.assertEqual(len(j.read('CONTENT_PROFILE')),1)
        self.assertFalse(out['security_tags_changed'])
    def test_model_load_failure_retains_inventory_and_flags_error(self):
        from ucf.app import run
        c=config();c['content']['enabled']=True;c['ml']['enabled']=False
        with patch('ucf.content.scan',side_effect=ValueError('missing model assets')):
            j=MemoryJournal();out=run(FakeWarehouse([raw()]),j,c,'content')
        self.assertEqual(out['content_stage']['status'],'CONTENT_STAGE_ERROR')
        self.assertEqual(len(j.read('SNAPSHOT')),1)
    def test_email_destination_subscription(self):
        from ucf.notifications import alert_definitions
        c=config();c['notifications'].update(emails=[],destination_ids=['existing-destination'])
        defs=alert_definitions(c)
        self.assertEqual(defs['changes']['evaluation']['notification']['subscriptions'],[{'destination_id':'existing-destination'}])
    def test_managed_mailbox_creation_and_cached_reuse(self):
        from ucf.notifications import managed_email_destination
        calls=[]
        def do(method,path,**kwargs):
            calls.append((method,path,kwargs))
            return {'results':[]} if method=='GET' else {'id':'managed-email-id'}
        c=config();j=MemoryJournal();w=SimpleNamespace(client=SimpleNamespace(api_client=SimpleNamespace(do=do)))
        self.assertEqual(managed_email_destination(w,j,c),'managed-email-id')
        self.assertEqual(managed_email_destination(w,j,c),'managed-email-id')
        self.assertEqual(len(calls),2)
        self.assertEqual(calls[1][2]['body']['config']['email']['addresses'],['C000926@infarmbureau.com'])
    def test_managed_mailbox_permission_failure_is_explicit(self):
        from ucf.notifications import managed_email_destination,EmailDestinationSetupError
        def fail(*args,**kwargs):raise PermissionError('sensitive response text')
        w=SimpleNamespace(client=SimpleNamespace(api_client=SimpleNamespace(do=fail)))
        with self.assertRaises(EmailDestinationSetupError) as error:managed_email_destination(w,MemoryJournal(),config())
        self.assertNotIn('sensitive response text',str(error.exception))

if __name__=='__main__':unittest.main()
