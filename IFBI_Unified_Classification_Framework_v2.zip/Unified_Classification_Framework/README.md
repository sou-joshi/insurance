# Unified classification framework — value inference release 2.0

This release reads actual values, runs existing pretrained models, compares the results with current Unity Catalog classifications and optional Collate assignments, and monitors changes. No IFBI-specific training set is required to start. It never writes security tags, changes ABAC policies, or grants access.

The ZIP contains application code and one Databricks launcher. Model weights are staged separately to approved storage. They total roughly 3 GB for the supplied ensemble and TabPFN-v2 checkpoints. This is a deployment candidate with local automated and real-model synthetic checks; IFBI business accuracy and workspace deployment acceptance remain to be measured. Do not describe it as 99–100% accurate based on the synthetic checks.

## Models and decisions

| Component | Model / method | Purpose |
|---|---|---|
| Sensitive information | NVIDIA `nvidia/gliner-PII` | Pretrained PII/PHI span recognition on actual values |
| Complementary semantic recognition | `urchade/gliner_medium-v2.1` | Pretrained zero-shot recognition, including proposed insurance identifier types |
| Independent name recognizer | `dslim/bert-base-NER` | Person-name corroboration; ORG/LOC mentions do not establish sensitivity |
| Structured record anomalies | Pretrained TabPFN **v2** + unsupervised extension | Unusual joint numerical values within sampled table/cohort reference data |
| Corroboration and diagnostics | SSN format, email format, Luhn, VIN checksum, robust MAD, distribution-change test | Additional evidence, not additional pretrained models |

Revisions are pinned in `ucf/content_config.py` and `ucf/anomalies.py`. Local files are hashed and checked before loading. GLiNER/BERT use safetensors and disable remote custom code. TabPFN-v2 uses its original checkpoint format from pinned publisher revisions; stage only the supplied trusted checkpoints and protect the manifest and model directory against untrusted modification.

Two models must agree on the same entity span inside the same value, or a model must have strong evidence corroborated by a supported format validator. Repeating one model's output is not an extra vote. Competing sensitive entity labels enter review. Scores are **uncalibrated evidence strength**, not the probability that a sensitivity tier is correct. Related GLiNER models can share errors; agreement does not establish accuracy.

Names of tables and columns provide context; existing sensitivity labels are excluded from model input. Only spans inside actual values count. Entity-to-tier mapping is a separate business policy. The shipped IFBI mapping is a **draft** and produces review proposals immediately; its approval is not required to run inference.

`recommended_label` abstains when source mapping and model evidence conflict. `ml_identified_label` preserves the model-derived proposal for side-by-side comparison. No detection never automatically becomes `Internal Use Only`.

## Run in your existing Databricks setup

Keep the existing SQL warehouse for metadata, source sampling and Delta journal writes. The pretrained models run in your approved Python notebook compute. A SQL warehouse alone cannot execute the Python model libraries. The supplied implementation does not use Spark APIs, public model inference APIs, or serverless endpoints.

1. Back up your current `config.toml`. Replace the framework code in its existing workspace/Git folder with this release. Keep `ucf/` and the dependency files as regular workspace files. Import only `Run_Classification_Framework.py` as a notebook if needed. Importing the whole ZIP through **Import Notebooks** can turn Python modules into notebooks and break imports.
2. Edit the supplied `config.toml` in that folder. Carry over your working `warehouse_id`, environment, source/output catalogs, schema and existing notification binding. Preserve the same source scope/output prefix to retain the existing metadata baseline. The supplied example bindings are DEV; do not copy DEV names into another environment.
3. Attach `Run_Classification_Framework` to approved non-serverless Python compute with access to that folder and Unity Catalog volumes. Start with sufficient memory for three local classifiers; the local smoke run used CPU inference. Install the supplied CPU lock file once, restart Python, then run the notebook's launcher cell. For GPU deployment use a compatible approved PyTorch 2.8 build and `requirements.txt`; do not install the CPU lock onto a GPU runtime.
4. Run the notebook's **prepare model volume** cell. This creates the configured output schema and a managed model volume if absent. The runner needs permission to create it, or an administrator can create it beforehand. `model_directory=""` derives `/Volumes/<output_catalog>/<output_schema>/<model_volume_name>/ucf_v2` automatically. A configured approved absolute model directory can override this.
5. Run **stage pretrained models** once. This fetches pinned public model artifacts and tokenizer/configuration dependencies, then writes a checksum manifest. It sends no customer values. If outbound model download is blocked, perform this staging on an approved machine and transfer the complete staged folder to the configured volume. Keep the manifest and directory together. Interrupted staging is resumable for the same pinned configuration. Production inference needs only read access to staged assets.
6. Run **check model runtime**. It checks hashes and performs actual synthetic email, name, SSN, negative-case and numerical-outlier checks. Then run **collect, classify, reconcile and monitor**. Do not run setup/staging cells on every scheduled job execution.
7. Run **status**, then **write dashboard queries**. Add the generated SQL datasets to the dashboard you already built. This package does not publish or replace that dashboard automatically.
8. Schedule only the operational launcher/run cells hourly using Jobs & Pipelines. Set maximum concurrent runs to **1** across this deployment, a hard task timeout appropriate to your measured run duration, and failure notifications. A local lock prevents overlapping processes on the same runner; it is not a distributed lock. Never run a second scheduled writer against the same output prefix.

Equivalent calls inside your existing launcher are:

```python
framework("prepare-model-volume")
from ucf.content_config import content_settings
from ucf.core import load_config
cfg = load_config(ROOT / "config.toml")
model_dir = content_settings(cfg)["model_directory"]
framework("models-stage", "--destination", model_dir)
framework("models-check", "--smoke")
framework("run")
framework("status")
framework("dashboard-queries", "--file", str(ROOT / "Value_Classification_Dashboard.sql"))
```

The first three are deployment/setup operations. `run` is the scheduled operation. Output file commands use exclusive creation: choose another filename or remove your own prior generated export before regenerating it.

## Access and data handling

Use an authorised, least-privilege profiling identity. It needs visibility of in-scope metadata, SELECT on the source columns it may inspect, write privileges on the dedicated output objects, and access to approved model storage. The framework does not bypass masking or change policy exceptions. Your earlier identity returned NULL for protected synthetic columns: those columns cannot be meaningfully classified from those reads.

`ALL_NULL_OR_MASKED` means all sampled values were NULL; the framework cannot determine whether that was genuine data, masking, or both. Empty, unsupported, unreadable, pending, stale and insufficient samples have separate outcomes. They are not clean classifications.

Source values and detected spans are processed in memory and not included in journal payloads, dashboards, CSV review templates, notifications or routine exception messages. Persisted information consists of metadata identifiers, aggregate counts, entity names, model provenance, proposals and finding state. Numeric cohort values are omitted. Optional record tokens use HMAC with `UCF_RECORD_TOKEN_KEY` injected from an approved secret; raw record keys are never stored. Without that secret, numeric output is aggregate-only. Keep notebook debug displays, driver logs, evaluation input files and output object permissions under IFBI controls.

Model downloads and package installation require approved artifact/network access during setup. Runtime model loading sets offline flags and disables model telemetry. The local inference smoke test also blocked outbound sockets; the supplied adapters made zero connection attempts. Enforce your normal network controls independently.

## What the first run reports

- The full visible metadata inventory and the existing tag monitor continue.
- A bounded batch of value profiles is added. Default limits: 30 tables, 1,000 columns, 256 sampled rows per table/query, up to 64 distinct values per column, with values capped at 4,096 characters. Long values and value-budget limits are explicit diagnostics.
- Supported Delta tables are read at a recorded table version. `require_delta_snapshot=true` rejects sampling when a Delta version cannot be obtained. Views/other sources need a deliberately configured `false` setting to use live-query sampling, with that limitation exposed.
- Remaining columns appear as `PENDING_SCAN` or `STALE_RESCAN_DUE`, never as completed classifications. Subsequent runs rotate through work. Fresh profiles are reused for the configured 24-hour interval; current tag-only changes can be reconciled without re-reading values.
- Existing baseline content findings are muted into a summary. Columns present at deployment but reached in later batches are still baseline, avoiding a delayed flood of alerts. New-column and subsequent content-change findings are eligible for the bounded digest.
- Numeric inference examines a separate sampled table batch. Default split: 256 reference rows, 128 calibration rows and at least 32 candidate rows. The reference rows are not scored against themselves. All three sets are disjoint.

Sampling cannot establish absence of rare sensitive values throughout a table. Reservoir sampling and Delta history queries can still scan large sources and incur warehouse cost. Stage deadlines are cooperative between work units; set a hard Databricks job timeout as well. Tune sample sizes, run budgets and schedule after measuring your actual workload. A 24-hour refresh setting plus a rotating budget is not a guarantee that every source is inspected every 24 hours. Metadata new-column checks still run on every collector execution.

## Dashboard datasets

All views derive from the same environment/output configuration:

| View suffix | Use |
|---|---|
| `current_inventory` | Full visible inventory and current tags |
| `content_profiles` | Sample coverage, read gaps, entity distributions, source versions and profile age |
| `content_comparison` | Existing tier vs ML-identified tier vs recommended proposal; source/Collate agreement |
| `content_findings` | Stateful sampled-content findings and backlog |
| `anomaly_tables` | Numeric feature lists, cohort scoring counts and bounded outlier details |
| `incidents`, `pending_notices` | Metadata incidents and the unified bounded notification queue |
| `health`, `runs` | Pipeline stages, failed/degraded stages and freshness |

The generated dashboard SQL is environment-specific output generated from configuration, not a second configuration file to maintain. Inspect both `incidents` and `content_findings`; they represent separate evidence channels.

## Numeric insurance anomalies

Auto mode selects numeric, non-identifier fields within each table. It is a discovery mode, not an insurance fraud classifier. For useful production results define explicit feature/cohort contracts for materially different populations:

```toml
[[anomalies.table_settings]]
table = "your_catalog.your_schema.your_claim_table"
numeric_columns = ["claim_amount", "premium_amount", "deductible_amount"]
cohort_columns = ["coverage_type"]
record_key_columns = ["claim_id"]
```

Use actual column names. A cohort must have enough sampled rows for all three splits. Small cohorts show `INSUFFICIENT_CONTEXT`; values are not pooled across unlike cohorts to force a result. All-null/nonfinite rows are counted and excluded. TabPFN lower-density values are unusual; a calibrated empirical tail rank is combined with robust marginal checks. The tail rank is not a fraud probability. The reference sample should mostly represent ordinary business activity; a contaminated reference or inappropriate cohort can reduce detection quality. Current and stale table batches are explicitly distinguished.

Optional HMAC record tokens can be reproduced inside the approved environment with the same secret and source key columns. They do not by themselves authorise anyone to access a claim. Dates, policy conditions, duplicate claims and business-validity constraints require separate approved domain rules; the numerical model does not establish those rules automatically.

## Collate

The supplied feed evidence had **zero Raw candidate assignments**. A successful metadata classifier cannot fix an absent classification feed. Collate is disabled by default until the correct Raw feed is configured.

Configure `assignment_table`, the exact service name per catalog, freshness limit and exact `term_tiers` mappings. Only Confirmed column assignments with both deletion flags false and a recent observation are comparable. A business glossary term is not automatically a sensitivity tier. Exact service/catalog/schema/table/column FQNs are joined; suffix matching is intentionally avoided. Stale/no-match/failed feeds are explicit outcomes and do not become evidence of agreement. No code writes back to Collate.

## Alerts, including your email

Keep `notifications.enabled=true` for operational alerts. The supplied `delivery_mode="managed_email_destination"` creates or reuses a dedicated email destination for the configured mailbox on the first operational run, then subscribes alerts by destination ID. Initial creation requires workspace administrator permissions; later runs reuse the recorded destination. Explicit `destination_ids` avoid provisioning. The `workspace_user` delivery mode instead requires `emails` to identify active workspace users. Your earlier error explicitly said it could not resolve `C000926@infarmbureau.com` as a workspace user. The supplied destination-based mode avoids repeating that workspace-user lookup. A non-admin runner needs an administrator to supply an existing destination ID.

For a non-admin operational runner, use an administrator-configured **email Notification Destination**, then configure:

```toml
[notifications]
enabled = true
emails = []
destination_ids = ["EXACT_EXISTING_EMAIL_NOTIFICATION_DESTINATION_ID"]
timezone = "UTC"
```

Alternatively use the actual workspace username if it is the same mailbox destination you intend. The framework supports both subscription forms; it does not provision users or silently substitute a different recipient. Destination setup instructions: https://docs.databricks.com/aws/en/admin/workspace-settings/notification-destinations

The collector commits its run before native alert configuration/evaluation. If alert creation fails, the core results remain available through `status` and the views, but the command fails and the health view records attention. Fix the destination and rerun. An evaluation receipt means Databricks accepted/succeeded the evaluation job, not proof that a mailbox received or read an email. First-run activation/content summaries are bounded; historical missing tags do not create thousands of notifications. New untagged columns, tag removal, classification disagreement, content drift and numerical outlier digests are supported. Missing sampled evidence holds earlier content findings for review; it does not falsely mark them remediated.

## Measure the 99% target correctly

Initial inference does **not** require manually labelled training data or `review_export.csv`. To substantiate an accuracy claim, independently labelled, held-out test examples are still necessary. That is validation of existing models, not training a new IFBI model.

Create a JSONL file in approved storage. Include actual representative formats, free-text claims, short identifiers, negatives, masked cases and rare critical entities. Annotate true entity spans; have an independent reviewer check the evaluation set. Use multiple source tables/coverage populations and keep the test set separate from threshold tuning.

```json
{"id":"synthetic-1","group":"source-table-A","split":"TEST","text":"Email: sample@example.com","entities":[{"start":7,"end":25,"entity":"EMAIL"}],"tier":"Confidential Restricted"}
```

Run:

```python
framework("evaluate-values", "--file", "/Volumes/your_catalog/your_schema/your_volume/heldout.jsonl",
          "--report", "/Volumes/your_catalog/your_schema/your_volume/value_quality_report.json")
```

The report includes per-entity precision/recall, false positives on negative examples, source-group support, decision coverage, tier accuracy, model/config fingerprints and 95% intervals. The supplied gate targets **99% precision lower bound**, **99% recall lower bound for every configured critical entity**, a 99% tier-accuracy lower bound, minimum entity/tier support, at least ten source groups and a coverage floor. A perfect result on a tiny sample fails; exact duplicate test texts are rejected. Tier abstentions count as incorrect in tier accuracy. Abstentions count as missed expected detections for recall. Several hundred independent observations may be necessary even with zero errors; correlated spans from one table do not establish generalisation. Review source/table stratification and confidence-interval assumptions before making a production accuracy claim.

This gate measures value/entity and supplied tier examples, not whole-column sampling recall or numeric-anomaly accuracy. Numeric anomalies need a separate adjudicated business test set; the injected-outlier smoke test proves execution only.

Passing the gate does not trigger tag writeback. Security policy changes remain a separate controlled workflow. Changing models, prompts, thresholds, sampling, cohorts or entity-to-tier policy requires re-evaluation. If the target fails, tune/replace detectors and repeat the evaluation on an untouched test set rather than declaring model confidence to be accuracy.

## Deployment acceptance and operations

Before production release, demonstrate: authorised readable samples; complete/aged coverage visible; model integrity and offline loading; correct strongest-tier proposals on a representative held-out set; masking/read failures preserved; business cohort validity; bounded baseline digests; a new-column alert; and receipt of a real test email at the requested mailbox. Local checks do not replace those workspace acceptance checks.

Use one job identity and writer, restricted output/model ACLs, approved package mirrors, staged immutable model releases and a separate output deployment in each environment. Keep historical journal access restricted. Define retention/archival under IFBI policy; no destructive journal cleanup is automatic in this release. Monitor journal growth and SQL warehouse costs. Retain package/model manifests, evaluation reports and the prior release for rollback. Disabling `[content].enabled` returns to metadata-only operation without erasing the journal; do not reset the original inventory baseline merely to clear a health issue.

## Source model terms

- NVIDIA model: https://huggingface.co/nvidia/gliner-PII — NVIDIA Open Model License.
- GLiNER medium: https://huggingface.co/urchade/gliner_medium-v2.1 — Apache 2.0.
- BERT NER: https://huggingface.co/dslim/bert-base-NER — MIT; trained on general NER, not an IFBI insurance benchmark.
- TabPFN-v2 classifier: https://huggingface.co/Prior-Labs/TabPFN-v2-clf
- TabPFN-v2 regressor: https://huggingface.co/Prior-Labs/TabPFN-v2-reg
- TabPFN-v2 uses the Prior Labs License with attribution requirements. **Built with PriorLabs-TabPFN.** Later weight families can have different/noncommercial terms; this framework explicitly selects v2 and never downloads the current default family for inference.
- Unsupervised extension: https://github.com/PriorLabs/tabpfn-extensions

Model suitability, thresholds and insurance entity definitions still require IFBI validation. No single pretrained model establishes all insurance classifications, fraud, legal compliance or absence of sensitive data.
