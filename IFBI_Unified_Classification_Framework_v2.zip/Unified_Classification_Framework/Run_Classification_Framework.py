# Databricks notebook source
# MAGIC %md
# MAGIC # Value classification and monitoring
# MAGIC Keep this notebook beside `config.toml`, `ucf/`, and the dependency files.
# MAGIC Use approved non-serverless Python compute; SQL work uses the existing warehouse.
# MAGIC
# MAGIC **Once:** install the CPU dependencies in a separate Python cell using
# MAGIC `%pip install -r ./requirements-cpu.lock.txt`, then run `dbutils.library.restartPython()`.
# MAGIC Use an approved package mirror/wheelhouse if internet package access is restricted.
# MAGIC For scheduled jobs, supply these dependencies through the approved compute/job environment.
# MAGIC
# MAGIC First run: leave `ACTION = "setup"`. After successful setup, change it to `"run"`.
# MAGIC Schedule only with `ACTION = "run"` and maximum concurrent runs = 1.

# COMMAND ----------
from pathlib import Path
import sys

ROOT = Path.cwd()
if not (ROOT / 'config.toml').is_file() or not (ROOT / 'ucf').is_dir():
    raise RuntimeError('Open this notebook in the framework folder, or set ROOT to its absolute workspace/Git path.')
sys.path.insert(0, str(ROOT))

# Edit this one value. There are no required notebook widgets.
ACTION = 'setup'  # setup | run | status | queries | evaluate

# Used only for ACTION='evaluate'; initial classification needs no labelled file.
HELDOUT_FILE = ''
QUALITY_REPORT = ''

# COMMAND ----------
from ucf.app import main
from ucf.core import load_config
from ucf.content_config import content_settings

def framework(*arguments):
    previous = sys.argv[:]
    try:
        sys.argv = ['run_framework.py', '--config', str(ROOT / 'config.toml'), *map(str, arguments)]
        code = main()
    finally:
        sys.argv = previous
    if code:
        raise RuntimeError('Framework command failed or quality target not met. Check the preceding stage output and framework status.')

config = load_config(ROOT / 'config.toml')

# COMMAND ----------
if ACTION == 'setup':
    framework('prepare-model-volume')
    framework('models-stage', '--destination', content_settings(config)['model_directory'])
    framework('models-check', '--smoke')
    print('Setup completed. Change ACTION to run, then run this notebook again.')
elif ACTION == 'run':
    framework('run')
    framework('status')
elif ACTION == 'status':
    framework('status')
elif ACTION == 'queries':
    framework('dashboard-queries', '--file', ROOT / 'Value_Classification_Dashboard.sql')
elif ACTION == 'evaluate':
    if not HELDOUT_FILE or not QUALITY_REPORT:
        raise ValueError('Set the held-out JSONL path and a new quality-report path inside approved storage.')
    framework('evaluate-values', '--file', HELDOUT_FILE, '--report', QUALITY_REPORT)
else:
    raise ValueError('Unknown ACTION. Use setup, run, status, queries, or evaluate.')
