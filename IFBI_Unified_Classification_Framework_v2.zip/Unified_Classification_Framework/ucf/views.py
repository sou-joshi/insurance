from .core import table

def definitions(c):
    journal=table(c,'journal');fid=c['environment'].replace("'","''")
    latest=f"SELECT run_id FROM {journal} WHERE framework_id='{fid}' AND record_type='RUN' ORDER BY observed_at DESC,run_id DESC LIMIT 1"
    def current(kind):return f"SELECT j.* FROM {journal} j WHERE j.framework_id='{fid}' AND j.record_type='{kind}' AND j.run_id=({latest})"
    def field(name,typ='STRING'):return f"CAST(get_json_object(payload_json,'$.{name}') AS {typ}) AS {name}"
    result={}
    result['current_inventory']='SELECT run_id,observed_at AS collected_at,'+','.join(field(k) for k in
      ('asset_key','catalog_name','schema_name','table_name','column_name','data_type','current_sensitivity','sensitivity_state','input_hash','evidence_hash'))+f' FROM ({current("SNAPSHOT")})'
    result['recommendations']='SELECT run_id,observed_at,'+','.join(field(k) for k in
      ('asset_key','input_hash','evidence_hash','model_id','recommended_label','recommendation_status','reason','current_sensitivity'))+','+field('model_score','DOUBLE')+f' FROM ({current("RECOMMENDATION")})'
    result['incidents']='SELECT run_id,'+','.join(field(k) for k in
      ('issue_key','asset_key','finding_type','priority','status','column_fqn','owner','opened_at','updated_at'))+f' FROM ({current("ISSUE")})'
    result['pending_notices']='SELECT run_id,'+','.join(field(k) for k in
      ('notice_id','priority','kind','finding_type','owner','catalog_name','schema_name','table_name'))+f" FROM ({current('NOTICE')}) n WHERE get_json_object(payload_json,'$.selected_for_batch')='true' AND NOT EXISTS(SELECT 1 FROM {journal} a WHERE a.framework_id='{fid}' AND a.record_type='ACK' AND a.record_id=n.record_id)"
    result['runs']=f"SELECT run_id,observed_at,payload_json FROM {journal} WHERE framework_id='{fid}' AND record_type='RUN'"
    result['models']=f"SELECT record_id AS model_id,observed_at,get_json_object(payload_json,'$.metrics') AS metrics_json FROM {journal} j WHERE framework_id='{fid}' AND record_type='MODEL' AND EXISTS(SELECT 1 FROM {journal} p WHERE p.framework_id=j.framework_id AND p.run_id=j.run_id AND p.record_type='RUN')"
    result['review_queue']=f'''WITH sample AS ({current('REVIEW_CANDIDATE')}), decisions AS (
      SELECT record_id,payload_json,ROW_NUMBER() OVER(PARTITION BY get_json_object(payload_json,'$.asset_key') ORDER BY observed_at DESC,run_id DESC) AS rn
      FROM {journal} WHERE framework_id='{fid}' AND record_type='REVIEW')
      SELECT s.run_id,s.record_id AS asset_key,s.payload_json AS candidate_json,
       COALESCE(CASE WHEN get_json_object(d.payload_json,'$.input_hash')=get_json_object(s.payload_json,'$.input_hash')
         AND get_json_object(d.payload_json,'$.evidence_hash')=get_json_object(s.payload_json,'$.evidence_hash')
         THEN get_json_object(d.payload_json,'$.decision') END,'PENDING_STEWARD_REVIEW') AS review_status
      FROM sample s LEFT JOIN decisions d ON get_json_object(d.payload_json,'$.asset_key')=s.record_id AND d.rn=1'''
    result['content_profiles']='SELECT run_id,'+','.join(field(k) for k in
      ('asset_key','input_hash','profile_status','profiled_at','profile_signature','sample_strategy','scope','source_snapshot_mode'))+','+','.join(field(k,'BIGINT') for k in
      ('sampled_rows','non_null_rows','evaluated_rows','unique_values_evaluated','truncated_rows','source_version'))+','+field('null_fraction','DOUBLE')+",get_json_object(payload_json,'$.entities') AS entities_json,get_json_object(payload_json,'$.drift_findings') AS drift_json"+f' FROM ({current("CONTENT_PROFILE")})'
    result['content_comparison']='SELECT run_id,'+','.join(field(k) for k in
      ('asset_key','input_hash','evidence_hash','current_sensitivity','recommended_label','recommendation_status',
       'ml_identified_label','policy_status','policy_version','profile_status','profiled_at','collate_feed_status','collate_comparison'))+','+field('model_score','DOUBLE')+",get_json_object(payload_json,'$.detected_entities') AS detected_entities_json,get_json_object(payload_json,'$.findings') AS findings_json"+f' FROM ({current("RECOMMENDATION")})'
    result['content_findings']='SELECT run_id,'+','.join(field(k) for k in
      ('issue_key','asset_key','finding_type','priority','status','column_fqn','owner','opened_at','updated_at'))+f' FROM ({current("CONTENT_ISSUE")})'
    result['anomaly_tables']='SELECT run_id,'+','.join(field(k) for k in
      ('table_key','table_fqn','attempted_at','status','bundle_id'))+','+field('sampled_rows','BIGINT')+','+field('stale','BOOLEAN')+",get_json_object(payload_json,'$.features') AS features_json,get_json_object(payload_json,'$.cohorts') AS cohorts_json"+f' FROM ({current("ANOMALY_TABLE")})'
    stale=2*c['monitor']['poll_minutes']+15
    result['health']=f'''WITH success AS (
       SELECT MAX(observed_at) AS last_success FROM {journal} WHERE framework_id='{fid}' AND record_type='RUN'),
      failure AS (SELECT MAX(observed_at) AS last_failure FROM {journal} WHERE framework_id='{fid}' AND record_type='FAILURE')
      SELECT last_success,last_failure,CASE WHEN last_success IS NULL OR last_success<current_timestamp()-INTERVAL {stale} MINUTES
       OR last_failure>last_success OR EXISTS(SELECT 1 FROM {journal} WHERE framework_id='{fid}'
        AND record_type='RUN' AND run_id=({latest})
        AND (get_json_object(payload_json,'$.model_stage.status')='ML_STAGE_ERROR'
          OR get_json_object(payload_json,'$.content_stage.status') IN ('CONTENT_STAGE_ERROR','DEGRADED','READ_GAPS')
          OR get_json_object(payload_json,'$.anomaly_stage.status') IN ('ANOMALY_STAGE_ERROR','DEGRADED')
          OR get_json_object(payload_json,'$.collate_stage.status') IN ('COLLATE_STAGE_ERROR','NO_CURRENT_RAW_ASSIGNMENTS')))
       THEN 1 ELSE 0 END AS attention_required FROM success CROSS JOIN failure'''
    return result

def install_views(w,c):
    # Never replace another component's object that happens to use this prefix.
    existing=w.sql('''SELECT table_name,comment,table_type FROM system.information_schema.tables
       WHERE table_catalog=:catalog AND table_schema=:schema''',
       {'catalog':c['output_catalog'],'schema':c['output_schema']})
    by_name={r['table_name']:r for r in existing}
    for name,query in definitions(c).items():
        old=by_name.get(c['table_prefix']+'_'+name)
        if old and (old.get('comment')!='Unified classification framework 1.0' or old['table_type']!='VIEW'):
            raise RuntimeError('View name is owned by another component')
        w.sql('CREATE OR REPLACE VIEW '+table(c,name)+" COMMENT 'Unified classification framework 1.0' AS "+query)

def dashboard_queries(c):
    return '\n\n'.join([
      '-- Generated from the framework configuration; add datasets to the existing dashboard.',
      f'''-- Recommendation outcomes\nSELECT recommendation_status,COUNT(*) AS columns
FROM {table(c,'recommendations')} GROUP BY recommendation_status ORDER BY columns DESC;''',
      f'''-- Steward progress\nSELECT review_status,COUNT(*) AS columns
FROM {table(c,'review_queue')} GROUP BY review_status;''',
      f'''-- Evidence-bound recommendations\nSELECT i.catalog_name,i.schema_name,i.table_name,i.column_name,i.data_type,
i.current_sensitivity,r.recommended_label,r.recommendation_status,r.model_score,r.reason,r.model_id
FROM {table(c,'current_inventory')} i JOIN {table(c,'recommendations')} r USING(asset_key,input_hash,evidence_hash)
WHERE r.recommendation_status IN ('REVIEW_CLASSIFICATION_MISMATCH','REVIEW_POSSIBLE_DOWNGRADE','CONFLICTING_EVIDENCE');''',
      f'''-- Value profiling coverage and readable-sample gaps\nSELECT profile_status,COUNT(*) AS columns FROM {table(c,'content_profiles')} GROUP BY profile_status;''',
      f'''-- Existing versus pretrained value classification\nSELECT i.catalog_name,i.schema_name,i.table_name,i.column_name,v.*\nFROM {table(c,'current_inventory')} i JOIN {table(c,'content_comparison')} v USING(asset_key,input_hash,evidence_hash);''',
      f'''-- Content findings\nSELECT * FROM {table(c,'content_findings')} WHERE status<>'RESOLVED';''',
      f'''-- Pretrained numeric anomalies (aggregates and optional HMAC record tokens)\nSELECT * FROM {table(c,'anomaly_tables')};''',
      f'''-- Health\nSELECT * FROM {table(c,'health')};''',
      f'''-- Run history\nSELECT run_id,observed_at,
get_json_object(payload_json,'$.inventory_columns') AS visible_columns,
get_json_object(payload_json,'$.reviewed_gold_rows') AS reviewed_gold_rows,
get_json_object(payload_json,'$.model_stage.status') AS model_stage,
get_json_object(payload_json,'$.active_model_id') AS active_model_id,
get_json_object(payload_json,'$.model_scored_rows') AS model_scored_rows,
get_json_object(payload_json,'$.monitor.open_incidents') AS open_incidents
FROM {table(c,'runs')} ORDER BY observed_at DESC;'''])+'\n'


