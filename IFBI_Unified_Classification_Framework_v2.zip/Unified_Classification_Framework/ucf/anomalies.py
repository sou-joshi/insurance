"""Pretrained TabPFN-v2 record outliers + robust per-feature checks.

Reference, calibration, and candidate rows are disjoint. No fraud labels, no
supervised weight training, no raw values in output. Numerical columns only;
cohort definitions are configured per table when business populations differ.
"""
from __future__ import annotations
from collections import defaultdict
import hashlib,hmac,json,math,os,re,time
from pathlib import Path
from .core import qi,digest,now

CHECKPOINTS=[
 {'name':'tabpfn_classifier','repo':'Prior-Labs/TabPFN-v2-clf','revision':'275f19d2add9c2c0de38f9ebaded3856599fa2e7',
  'file':'tabpfn-v2-classifier-finetuned-zk73skhh.ckpt'},
 {'name':'tabpfn_regressor','repo':'Prior-Labs/TabPFN-v2-reg','revision':'02a44705ff7790b50cded404bc59adb94da456a1',
  'file':'tabpfn-v2-regressor.ckpt'}]

DEFAULTS={'enabled':False,'maximum_tables_per_run':1,'rows_per_table':512,'maximum_features':8,
    'reference_rows':256,'calibration_rows':128,'minimum_candidate_rows':32,
    'tail_probability':.01,'mad_threshold':6.,'permutations':3,'maximum_run_seconds':600,
    'maximum_record_findings':25,'seed':1729,'table_settings':[]}

def settings(c):
    out=dict(DEFAULTS);out.update(c.get('anomalies',{}))
    for k,low,high in [('maximum_tables_per_run',1,100),('rows_per_table',128,4096),('maximum_features',2,32),
      ('reference_rows',32,2048),('calibration_rows',32,1024),('minimum_candidate_rows',16,1024),
      ('permutations',1,10),('maximum_run_seconds',30,7200),('maximum_record_findings',1,1000)]:
        if type(out[k]) is not int or not low<=out[k]<=high:raise ValueError('INVALID_ANOMALY_SETTING:'+k)
    if out['reference_rows']+out['calibration_rows']+out['minimum_candidate_rows']>out['rows_per_table']:
        raise ValueError('ANOMALY_SPLIT_EXCEEDS_SAMPLE')
    if not 0<out['tail_probability']<.5 or out['mad_threshold']<3:raise ValueError('INVALID_ANOMALY_THRESHOLD')
    if out['tail_probability']<1/(out['calibration_rows']+1):raise ValueError('CALIBRATION_TOO_SMALL_FOR_TAIL_THRESHOLD')
    return out

class TabPFNScorer:
    def __init__(self,root,device='cpu',permutations=3,seed=1729):
        from .value_models import offline_environment
        offline_environment()
        from tabpfn import TabPFNClassifier,TabPFNRegressor
        from tabpfn.constants import ModelVersion
        from tabpfn_extensions.unsupervised import TabPFNUnsupervisedModel
        root=Path(root)
        for cp in CHECKPOINTS:
            if not (root/'tabpfn'/cp['file']).is_file():raise ValueError('STAGE_TABPFN_V2_CHECKPOINTS')
        options={'device':device,'n_estimators':2,'random_state':seed}
        clf=TabPFNClassifier.create_default_for_version(ModelVersion.V2,
            model_path=str(root/'tabpfn'/CHECKPOINTS[0]['file']),**options)
        reg=TabPFNRegressor.create_default_for_version(ModelVersion.V2,
            model_path=str(root/'tabpfn'/CHECKPOINTS[1]['file']),**options)
        self.model=TabPFNUnsupervisedModel(tabpfn_clf=clf,tabpfn_reg=reg)
        self.permutations=permutations;self.seed=seed

    def fit(self,reference):
        # fit supplies inference context to the pretrained foundation model.
        self.model.fit(reference)
        return self

    def score(self,candidates):
        import numpy as np,torch
        torch.manual_seed(self.seed);np.random.seed(self.seed)
        result=self.model.outliers(candidates,n_permutations=self.permutations)
        if hasattr(result,'detach'):result=result.detach().cpu().numpy()
        result=np.asarray(result,dtype=float)
        if result.shape!=(len(candidates),) or not np.isfinite(result).all():raise ValueError('INVALID_OUTLIER_SCORES')
        # Lower density / log-density = more unusual. Both are monotonically
        # compatible with the empirical calibration below; no probability claim.
        return result

def calibrated_findings(reference,calibration,candidates,scorer,cfg):
    import numpy as np
    ref=np.asarray(reference,dtype=np.float32);cal=np.asarray(calibration,dtype=np.float32);test=np.asarray(candidates,dtype=np.float32)
    if len(ref)<cfg['reference_rows'] or len(cal)<cfg['calibration_rows'] or len(test)<cfg['minimum_candidate_rows']:
        raise ValueError('INSUFFICIENT_DISJOINT_ANOMALY_CONTEXT')
    if not all(np.isfinite(x).all() for x in (ref,cal,test)):raise ValueError('NONFINITE_ANOMALY_INPUT')
    scorer.fit(ref)
    # One call ensures calibration and candidate scores use the same permutation
    # ensemble. Rows used as inference context are never evaluated against self.
    scores=scorer.score(np.concatenate([cal,test],axis=0));cal_scores=scores[:len(cal)];test_scores=scores[len(cal):]
    med=np.median(ref,axis=0);mad=np.median(np.abs(ref-med),axis=0)
    robust=np.divide(np.abs(test-med),1.4826*mad,out=np.zeros_like(test),where=mad>0)
    # Zero MAD: a different value in a constant reference feature is unusual,
    # while equal constants are not. Record an aggregate flag, no source value.
    robust=np.where((mad==0)&(np.abs(test-med)>0),np.inf,robust)
    findings=[]
    for i,score in enumerate(test_scores):
        # Finite-sample empirical lower-tail rank, including ties conservatively.
        p=(1+int(np.sum(cal_scores<=score)))/(len(cal_scores)+1)
        marginal=np.flatnonzero(robust[i]>cfg['mad_threshold']).tolist()
        if p<=cfg['tail_probability'] or marginal:
            findings.append({'candidate_index':i,'tail_rank':p,'marginal_feature_indices':marginal,
                'evidence':'TABPFN_AND_ROBUST' if p<=cfg['tail_probability'] and marginal else 'TABPFN_JOINT' if p<=cfg['tail_probability'] else 'ROBUST_MARGINAL',
                'interpretation':'UNUSUAL_RELATIVE_TO_SAMPLED_REFERENCE_NOT_FRAUD'})
    return findings

def run(w,rows,c,previous=(),scorer_factory=None,clock=time.monotonic):
    cfg=settings(c)
    if not cfg['enabled']:return [],{'status':'DISABLED'}
    from .content_config import content_settings
    from .assets import verify_bundle
    cs=content_settings(c)
    manifest,bundle_id=verify_bundle(cs['model_directory'],cs)
    if manifest.get('anomaly_checkpoints')!=CHECKPOINTS:raise ValueError('TABPFN_CHECKPOINT_MANIFEST_MISMATCH')
    if scorer_factory is None:scorer_factory=lambda:TabPFNScorer(cs['model_directory'],cs['device'],cfg['permutations'],cfg['seed'])
    by_table=defaultdict(list)
    for r in rows:
        if r.get('is_connector_metadata'):continue
        if re.match(r'^(tinyint|smallint|int|bigint|float|double|decimal)',r['data_type'].lower()) and not re.search(r'(^|_)(id|key|code|cd|version|zip|ssn|phone)(_|$)',r['column_name'],re.I):
            by_table[r['table_key']].append(r)
    history={x['table_key']:{k:v for k,v in x.items() if not k.startswith('_')} for x in previous}
    ordered=sorted(by_table,key=lambda k:history.get(k,{}).get('attempted_at',''))
    started=clock();outputs=[];attempted=0
    for key in ordered:
        if attempted>=cfg['maximum_tables_per_run'] or clock()-started>=cfg['maximum_run_seconds']:break
        numeric=by_table[key]
        if len(numeric)<2:continue
        first=numeric[0];table_fqn='.'.join(first[k] for k in ('catalog_name','schema_name','table_name'))
        tc=next((x for x in cfg['table_settings'] if x['table']==table_fqn),{})
        cols=tc.get('numeric_columns',[r['column_name'] for r in sorted(numeric,key=lambda r:r['column_name'])[:cfg['maximum_features']]])
        # Explicit features must still be numeric visible columns. Never silently
        # substitute features in a saved cohort contract.
        visible={r['column_name'] for r in rows if r['table_key']==key}
        cohorts=tc.get('cohort_columns',[]);keys=tc.get('record_key_columns',[])
        if not set(cols)<={r['column_name'] for r in numeric} or not set(cols+cohorts+keys)<=visible:raise ValueError('ANOMALY_TABLE_CONTRACT_COLUMN_NOT_VISIBLE')
        if not 2<=len(cols)<=cfg['maximum_features']:raise ValueError('ANOMALY_FEATURE_BUDGET')
        attempted+=1
        out={'table_key':key,'table_fqn':table_fqn,'attempted_at':now(),'bundle_id':bundle_id,
            'features':cols,'cohort_columns':cohorts,'status':'COMPLETE','cohorts':[]}
        try:
            projections=[f'{qi(col)} AS f{i}' for i,col in enumerate(cols)]
            projections += [f'CAST({qi(col)} AS STRING) AS g{i}' for i,col in enumerate(cohorts)]
            projections += [f'CAST({qi(col)} AS STRING) AS k{i}' for i,col in enumerate(keys)]
            source='.'.join(qi(first[k]) for k in ('catalog_name','schema_name','table_name'))
            raw=w.sql('SELECT '+','.join(projections)+f' FROM {source} TABLESAMPLE ({cfg["rows_per_table"]} ROWS) LIMIT {cfg["rows_per_table"]}')
            grouped=defaultdict(list);skipped=0
            for record in raw:
                try:
                    values=[float(record['f'+str(i)]) for i in range(len(cols))]
                    if not all(math.isfinite(v) for v in values):raise ValueError()
                except (ValueError,TypeError,KeyError,OverflowError):skipped+=1;continue
                cohort=tuple(record.get('g'+str(i)) for i in range(len(cohorts)))
                grouped[cohort].append((values,record))
            out.update(sampled_rows=len(raw),skipped_null_or_nonfinite_rows=skipped)
            import numpy as np
            for cohort,records in grouped.items():
                minimum=cfg['reference_rows']+cfg['calibration_rows']+cfg['minimum_candidate_rows']
                if len(records)<minimum:
                    out['cohorts'].append({'status':'INSUFFICIENT_CONTEXT','rows':len(records)});continue
                order=np.random.default_rng(cfg['seed']).permutation(len(records));records=[records[i] for i in order]
                ref=records[:cfg['reference_rows']];cal=records[cfg['reference_rows']:cfg['reference_rows']+cfg['calibration_rows']]
                test=records[cfg['reference_rows']+cfg['calibration_rows']:]
                findings=calibrated_findings([v for v,_ in ref],[v for v,_ in cal],[v for v,_ in test],scorer_factory(),cfg)
                safe=[];secret=os.getenv('UCF_RECORD_TOKEN_KEY','')
                for finding in findings[:cfg['maximum_record_findings']]:
                    i=finding.pop('candidate_index')
                    finding['feature_names']=[cols[j] for j in finding.pop('marginal_feature_indices')]
                    if keys and len(secret)>=32:
                        key_values=[test[i][1].get('k'+str(j)) for j in range(len(keys))]
                        finding['record_token']=hmac.new(secret.encode(),json.dumps([table_fqn,key_values],ensure_ascii=True).encode(),hashlib.sha256).hexdigest()
                    safe.append(finding)
                out['cohorts'].append({'status':'SCORED','reference_rows':len(ref),'calibration_rows':len(cal),'candidate_rows':len(test),
                    'outlier_count':len(findings),'findings':safe,'cohort_values_omitted':True,
                    'record_tokens_enabled':bool(keys and len(secret)>=32)})
            if not any(x['status']=='SCORED' for x in out['cohorts']):out['status']='INSUFFICIENT_CONTEXT'
        except Exception as exc:
            out.update(status='ANOMALY_STAGE_ERROR',error_type=type(exc).__name__,statement_id=getattr(exc,'statement_id',None))
        outputs.append(out)
    # Retain other table results as stale, never claim the whole catalog scored.
    for key,old in history.items():
        if key in by_table and key not in {x['table_key'] for x in outputs}:outputs.append(dict(old,stale=True))
    scored=any(y['status']=='SCORED' for x in outputs if not x.get('stale') for y in x['cohorts'])
    return outputs,{'status':'DEGRADED' if any(x['status']=='ANOMALY_STAGE_ERROR' for x in outputs if not x.get('stale')) else 'COMPLETE_SAMPLED_TABLE_BATCH' if scored else 'INSUFFICIENT_CONTEXT',
        'attempted_tables':attempted,'eligible_tables':sum(len(v)>=2 for v in by_table.values()),
        'outliers_in_current_batch':sum(y.get('outlier_count',0) for x in outputs if not x.get('stale') for y in x['cohorts']),
        'scope':'DISJOINT_CANDIDATES_WITHIN_SAMPLED_NUMERIC_TABLE_COHORTS'}
