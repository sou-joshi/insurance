"""Digest-oriented content findings; sampled absence never proves remediation."""
from datetime import datetime,timedelta,timezone
from .core import digest,now,PRIORITY

ACTIONABLE={'SENSITIVE_CONTENT_WITHOUT_CLASSIFICATION','CONTENT_TIER_STRONGER_THAN_EXISTING',
 'SOURCE_MODEL_DISAGREEMENT','COLLATE_MODEL_DISAGREEMENT','SENSITIVE_CONTENT_DISTRIBUTION_CHANGED','NULL_RATE_CHANGED'}

def update(rows,recommendations,profiles,previous,acks,c,stamp=None):
    stamp=stamp or datetime.now(timezone.utc)
    first=previous is None
    old=previous or {'issues':{},'pending':{},'baseline_at':stamp.isoformat()}
    issues={k:dict(v) for k,v in old['issues'].items()}
    pending={k:dict(v) for k,v in old['pending'].items()}
    by_asset={r['asset_key']:r for r in rows};pr={p['asset_key']:p for p in profiles}
    recs={r['asset_key']:r for r in recommendations}
    for ack in acks:
        notice=pending.pop(ack['notice_id'],None)
        if notice and notice.get('issue_key') in issues:
            issues[notice['issue_key']]['last_accepted_at']=ack['accepted_at']
    baseline_assets=set(old.get('baseline_assets',[r['asset_key'] for r in rows] if first else []))
    seen_assets=set(old.get('seen_assets',[]))
    present=set()
    for r in recommendations:
        row=by_asset[r['asset_key']]
        if r.get('evidence_stale'):continue
        for finding in ACTIONABLE.intersection(r.get('findings',[])):
            key=digest(['CONTENT',r['asset_key'],finding]);present.add(key)
            prior=issues.get(key)
            issue=dict(prior or {},issue_key=key,asset_key=r['asset_key'],finding_type=finding,
                status='BACKLOG' if first else 'OPEN',priority='P1' if finding in ('SENSITIVE_CONTENT_WITHOUT_CLASSIFICATION','CONTENT_TIER_STRONGER_THAN_EXISTING') else 'P2',
                owner=row.get('remediation_owner','Governance team'),
                catalog_name=row['catalog_name'],schema_name=row['schema_name'],table_name=row['table_name'],
                column_name=row['column_name'],column_fqn='.'.join(row[k] for k in ('catalog_name','schema_name','table_name','column_name')),
                current_sensitivity=r['current_sensitivity'],recommended_label=r['recommended_label'],
                opened_at=(prior or {}).get('opened_at',stamp.isoformat()),updated_at=stamp.isoformat(),
                baseline_muted=(prior or {}).get('baseline_muted',r['asset_key'] in baseline_assets and r['asset_key'] not in seen_assets),generation=(prior or {}).get('generation',1),
                detail='Sampled content finding requires review; no business values in notification')
            if prior and prior['status']=='RESOLVED':issue.update(generation=prior['generation']+1,baseline_muted=False,last_accepted_at=None)
            if issue['baseline_muted']:issue['status']='BACKLOG'
            issues[key]=issue
    for key,issue in issues.items():
        if key in present or issue['status']=='RESOLVED':continue
        row=by_asset.get(issue['asset_key']);rec=recs.get(issue['asset_key'])
        readable=rec and not rec.get('evidence_stale')
        # A valid tag can settle a missing-tag finding. If a tier was proposed,
        # require equal/stronger protection. Other sampled findings need review.
        tier=PRIORITY.get(issue.get('recommended_label'))
        fixed=(issue['finding_type'] in ('SENSITIVE_CONTENT_WITHOUT_CLASSIFICATION','CONTENT_TIER_STRONGER_THAN_EXISTING')
               and row and row.get('actual_priority') is not None
               and (tier is None or row['actual_priority']<=tier))
        issue['status']='RESOLVED' if fixed else 'REVIEW_REQUIRED' if readable else 'EVIDENCE_GAP'
        issue['updated_at']=stamp.isoformat()
    active_keys={v['issue_key'] for v in pending.values()}
    for key,issue in issues.items():
        if issue['status']=='RESOLVED':
            for notice_id,n in list(pending.items()):
                if n.get('issue_key')==key:pending.pop(notice_id)
            continue
        if issue['baseline_muted'] or key in active_keys:continue
        last=issue.get('last_accepted_at')
        if last and stamp-datetime.fromisoformat(last)<timedelta(hours=c['monitor']['reminder_hours']):continue
        notice_id=digest([key,issue['generation'],last or 'NEW'])
        pending[notice_id]=dict(issue,notice_id=notice_id,kind='REMINDER' if last else 'NEW',created_at=stamp.isoformat())
    # One first-run summary, never one email per existing column.
    if first:
        notice_id=digest(['CONTENT_BASELINE',c['environment'],old['baseline_at']])
        pending[notice_id]={'notice_id':notice_id,'issue_key':'CONTENT_BASELINE','asset_key':'CONTENT_BASELINE',
            'generation':1,'priority':'P3','kind':'SUMMARY','finding_type':'CONTENT_BASELINE_SUMMARY',
            'owner':'Governance team','catalog_name':'(configured scope)','schema_name':'(summary)',
            'table_name':'(content profiling)','created_at':stamp.isoformat(),'finding_count':len(issues)}
    return {'issues':issues,'pending':pending,'baseline_at':old['baseline_at'],
        'baseline_assets':sorted(baseline_assets),
        'seen_assets':sorted(seen_assets|{r['asset_key'] for r in recommendations if not r.get('evidence_stale')})}

def merge_notices(state,content,c):
    state['pending'].update(content['pending'])
    ordered=sorted(state['pending'].values(),key=lambda n:(n['priority'],n.get('created_at',''),n['notice_id']))
    selected={n['notice_id'] for n in ordered[:c['monitor']['maximum_notifications_per_run']]}
    for notice in state['pending'].values():notice['selected_for_batch']=notice['notice_id'] in selected
    state['summary'].update(pending_notifications=len(state['pending']),selected_notifications=len(selected),
        content_open_findings=sum(x['status'] in ('OPEN','EVIDENCE_GAP','REVIEW_REQUIRED') for x in content['issues'].values()),
        content_baseline_backlog=sum(x.get('baseline_muted',False) and x['status']!='RESOLVED' for x in content['issues'].values()))
