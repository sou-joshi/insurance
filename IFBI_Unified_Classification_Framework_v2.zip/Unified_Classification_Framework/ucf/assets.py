"""Explicit online staging; strictly local, checksum-verified inference.

No customer values are accepted by the staging operation. Deploy the staged
directory to read-only approved storage; no weights are bundled in this ZIP.
"""
from __future__ import annotations
import hashlib,json,os,re,tempfile
from contextlib import contextmanager
from pathlib import Path
from .core import digest,now

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
    return h.hexdigest()

def checked_path(root,relative):
    path=(root/relative).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():raise ValueError('MODEL_FILE_OUTSIDE_BUNDLE_OR_MISSING')
    return path

def verify_bundle(directory,settings):
    root=Path(directory).resolve();manifest=json.loads((root/'manifest.json').read_text())
    if manifest.get('format')!='ucf_local_models_v2':raise ValueError('INVALID_MODEL_MANIFEST')
    definitions={m['name']:m for m in manifest['models']}
    for m in settings['models']:
        if not m.get('enabled',True):continue
        actual=definitions.get(m['name'])
        if not actual or any(actual.get(k)!=m[k] for k in ('repo','revision','kind')):raise ValueError('MODEL_REVISION_MISMATCH')
    for entry in manifest['files']:
        p=checked_path(root,entry['path'])
        if p.stat().st_size!=entry['bytes'] or sha256(p)!=entry['sha256']:raise ValueError('MODEL_CHECKSUM_MISMATCH')
    declared={x['path'] for x in manifest['files']}
    present={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='manifest.json' and '.cache' not in p.parts}
    if declared!=present:raise ValueError('MODEL_BUNDLE_HAS_UNTRACKED_FILES')
    for m in settings['models']:
        if m.get('enabled',True) and f"{m['name']}/model.safetensors" not in declared:raise ValueError('SAFETENSORS_REQUIRED')
    return manifest,digest(manifest)

@contextmanager
def online_staging():
    """An explicit staging command may fetch weights after an offline scan."""
    keys=('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE')
    old={k:os.environ.get(k) for k in keys}
    for key in keys:os.environ[key]='0'
    os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
    from huggingface_hub import constants
    from transformers.utils import hub
    prior_hf=constants.HF_HUB_OFFLINE;prior_tr=hub._is_offline_mode
    constants.HF_HUB_OFFLINE=False;hub._is_offline_mode=False
    try:yield
    finally:
        constants.HF_HUB_OFFLINE=prior_hf;hub._is_offline_mode=prior_tr
        for key,value in old.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value

def stage_models(settings,destination,anomaly_settings=None):
    with online_staging():return _stage_models(settings,destination,anomaly_settings)

def _stage_models(settings,destination,anomaly_settings=None):
    """Run once with approved Hub access. Never called by run/scan/inference."""
    from huggingface_hub import HfApi,snapshot_download
    from transformers import AutoConfig,AutoTokenizer
    root=Path(destination).resolve()
    marker=root/'.ucf_staging.json'
    contract={'models':settings['models'],'anomalies_enabled':bool((anomaly_settings or {}).get('enabled',False))}
    if (root/'manifest.json').exists():
        manifest,bundle_id=verify_bundle(root,settings)
        if contract['anomalies_enabled'] and not manifest.get('anomaly_checkpoints'):raise ValueError('STAGE_TABPFN_V2_CHECKPOINTS')
        return {'status':'EXISTING_MODEL_BUNDLE_VERIFIED','directory':str(root),'bundle_id':bundle_id}
    if root.exists() and any(root.iterdir()) and (not marker.exists() or json.loads(marker.read_text())!=contract):
        raise ValueError('STAGING_DESTINATION_MUST_BE_EMPTY')
    root.mkdir(parents=True,exist_ok=True)
    marker.write_text(json.dumps(contract,sort_keys=True))
    api=HfApi();models=[];dependencies=[];checkpoints=[]
    for m in settings['models']:
        if not m.get('enabled',True):continue
        if not re.fullmatch(r'[a-z][a-z0-9_]*',m['name']) or not re.fullmatch(r'[0-9a-f]{40}',m['revision']):
            raise ValueError('PIN_MODEL_NAME_AND_FULL_REVISION')
        folder=root/m['name']
        info=api.model_info(m['repo'],revision=m['revision'])
        files={x.rfilename for x in info.siblings}
        if 'model.safetensors' not in files:raise ValueError('MODEL_REVISION_HAS_NO_SAFETENSORS: '+m['name'])
        snapshot_download(m['repo'],revision=m['revision'],local_dir=str(folder),
            allow_patterns=['*.json','*.txt','*.model','*.safetensors','README.md','LICENSE*','NOTICE*'],
            ignore_patterns=['*.bin','*.pt','*.py','*.onnx','*.h5','*.msgpack'])
        if m['kind']=='gliner':
            cfg=json.loads((folder/'gliner_config.json').read_text())
            if cfg.get('labels_encoder'):raise ValueError('BIENCODER_REQUIRES_EXPLICIT_LOCAL_LABEL_ASSETS')
            if not cfg.get('encoder_config') or not (folder/'tokenizer_config.json').exists():
                backbone=cfg['model_name'];backbone_info=api.model_info(backbone)
                revision=backbone_info.sha
                if not cfg.get('encoder_config'):
                    cfg['encoder_config']=AutoConfig.from_pretrained(backbone,revision=revision,trust_remote_code=False).to_dict()
                    (folder/'gliner_config.json').write_text(json.dumps(cfg,indent=2))
                AutoTokenizer.from_pretrained(backbone,revision=revision,trust_remote_code=False).save_pretrained(str(folder))
                dependencies.append({'model':m['name'],'repo':backbone,'revision':revision,'assets':'CONFIG_AND_TOKENIZER_ONLY'})
        models.append({k:m[k] for k in ('name','repo','revision','kind')})
    if (anomaly_settings or {}).get('enabled',False):
        from .anomalies import CHECKPOINTS
        from huggingface_hub import hf_hub_download
        for cp in CHECKPOINTS:
            hf_hub_download(cp['repo'],filename=cp['file'],revision=cp['revision'],local_dir=str(root/'tabpfn'))
            # Retain model-specific terms alongside pinned trusted checkpoints.
            info=api.model_info(cp['repo'],revision=cp['revision'])
            for file in info.siblings:
                if file.rfilename.upper().startswith(('LICENSE','README','NOTICE')):
                    hf_hub_download(cp['repo'],filename=file.rfilename,revision=cp['revision'],
                        local_dir=str(root/'tabpfn'/cp['name']))
        checkpoints=CHECKPOINTS
    # HF local_dir cache is staging metadata, not a deployment dependency.
    import shutil
    for folder in root.rglob('.cache'):shutil.rmtree(folder)
    marker.unlink()
    files=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha256(p)}
           for p in sorted(root.rglob('*')) if p.is_file() and p.name!='manifest.json']
    manifest={'format':'ucf_local_models_v2','created_at':now(),'models':models,'dependencies':dependencies,
              'anomaly_checkpoints':checkpoints,'files':files}
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2))
    verify_bundle(root,settings)
    return {'status':'MODELS_STAGED_AND_CHECKSUMMED','directory':str(root),'bundle_id':digest(manifest)}

def load_ensemble(settings):
    from .value_models import GLiNERDetector,BertNERDetector,Ensemble,offline_environment
    offline_environment()
    root=Path(settings['model_directory']).resolve()
    manifest,signature=verify_bundle(root,settings)
    detectors=[]
    for m in settings['models']:
        if not m.get('enabled',True):continue
        cls=GLiNERDetector if m['kind']=='gliner' else BertNERDetector
        detectors.append(cls(m['name'],root/m['name'],settings['device'],m['threshold']))
    return Ensemble(detectors,settings),signature
