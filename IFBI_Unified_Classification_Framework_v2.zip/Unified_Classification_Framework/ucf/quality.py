"""Held-out evaluation for pretrained inference, not custom-model training."""
from collections import Counter,defaultdict
import json,math
from .core import PRIORITY,digest,now,RELEASE_VERSION
from .value_models import ENTITIES,PROMPTS

def wilson(successes,total,z=1.959963984540054):
    if not total:return None
    p=successes/total;den=1+z*z/total
    mid=p+z*z/(2*total);rad=z*math.sqrt(p*(1-p)/total+z*z/(4*total*total))
    return [(mid-rad)/den,(mid+rad)/den]

def stats(tp,fp,fn):
    return {'tp':tp,'fp':fp,'fn':fn,'precision':tp/(tp+fp) if tp+fp else None,
        'recall':tp/(tp+fn) if tp+fn else None,
        'precision_95ci':wilson(tp,tp+fp),'recall_95ci':wilson(tp,tp+fn)}

def match(predicted,gold):
    """Maximum bipartite span matching: same label and IoU >= 0.5."""
    edges={}
    for i,p in enumerate(predicted):
        edges[i]=[]
        for j,g in enumerate(gold):
            intersection=max(0,min(p['end'],g['end'])-max(p['start'],g['start']))
            union=max(p['end'],g['end'])-min(p['start'],g['start'])
            if p['entity']==g['entity'] and union and intersection/union>=.5:edges[i].append(j)
    paired={}
    def visit(i,seen):
        for j in edges[i]:
            if j in seen:continue
            seen.add(j)
            if j not in paired or visit(paired[j],seen):paired[j]=i;return True
        return False
    for i in edges:visit(i,set())
    matched_pred=set(paired.values());matched_gold=set(paired)
    return matched_pred,matched_gold

def evaluate_file(path,ensemble,settings,bundle_id,quality_settings=None):
    cfg={'target_precision':.99,'target_critical_recall':.99,'minimum_coverage':.50,
         'minimum_groups':10,'minimum_examples_per_entity':30,'maximum_rows':10000,
         'minimum_tier_examples':100,'target_tier_accuracy':.99}
    cfg.update(quality_settings or {})
    counters=defaultdict(Counter);groups=set();seen=set();seen_text=set();rows=0;decided=0;negative=0;false_positive_negative=0
    per_group=defaultdict(Counter)
    data_signature=[];tier_correct=0;tier_evaluated=0
    with open(path,encoding='utf-8') as f:
        for line in f:
            if not line.strip():continue
            item=json.loads(line);rows+=1
            if rows>cfg['maximum_rows']:raise ValueError('EVALUATION_ROW_BUDGET')
            if item.get('split')!='TEST' or not item.get('group') or not item.get('id'):
                raise ValueError('HELD_OUT_TEST_GROUP_AND_ID_REQUIRED')
            if item['id'] in seen:raise ValueError('DUPLICATE_EVALUATION_ID')
            seen.add(item['id']);groups.add(item['group'])
            text=item['text']
            if not isinstance(text,str) or len(text)>settings['maximum_value_chars']:raise ValueError('INVALID_EVALUATION_TEXT')
            text_fingerprint=digest(text)
            if text_fingerprint in seen_text:raise ValueError('DUPLICATE_EVALUATION_TEXT')
            seen_text.add(text_fingerprint)
            gold=item['entities']
            for g in gold:
                if g['entity'] not in ENTITIES or not 0<=g['start']<g['end']<=len(text):raise ValueError('INVALID_GOLD_SPAN')
            # Evaluation text is used in memory; only a dataset fingerprint and
            # counts leave this command, no snippets or value hashes per record.
            data_signature.append(item)
            all_findings=ensemble.identify(text)
            predicted=[p for p in all_findings if p['consensus'] and p['entity'] in settings['entity_tiers']]
            decided+=bool(predicted) or not all_findings
            gold=[g for g in gold if g['entity'] in settings['entity_tiers']]
            mp,mg=match(predicted,gold)
            if not gold:negative+=1;false_positive_negative+=bool(predicted)
            for i,p in enumerate(predicted):
                key='tp' if i in mp else 'fp';counters[p['entity']][key]+=1;per_group[item['group']][key]+=1
            for j,g in enumerate(gold):
                if j not in mg:counters[g['entity']]['fn']+=1;per_group[item['group']]['fn']+=1
            if item.get('tier'):
                if item['tier'] not in PRIORITY:raise ValueError('INVALID_EVALUATION_TIER')
                tier_evaluated+=1
                inferred=min((settings['entity_tiers'][p['entity']] for p in predicted),key=PRIORITY.get,default=None)
                tier_correct+=inferred==item['tier']
    if not rows:raise ValueError('EMPTY_EVALUATION_DATASET')
    total=sum(counters.values(),Counter());overall=stats(total['tp'],total['fp'],total['fn'])
    entities={e:stats(v['tp'],v['fp'],v['fn']) for e,v in counters.items()}
    critical=[e for e,tier in settings['entity_tiers'].items() if tier=='Confidential Critical']
    failure=[]
    if len(groups)<cfg['minimum_groups']:failure.append('INSUFFICIENT_SOURCE_GROUPS')
    if not overall['precision_95ci'] or overall['precision_95ci'][0]<cfg['target_precision']:failure.append('PRECISION_LOWER_BOUND_BELOW_TARGET')
    for entity in settings['entity_tiers']:
        v=entities.get(entity,stats(0,0,0))
        if v['tp']+v['fn']<cfg['minimum_examples_per_entity']:failure.append('INSUFFICIENT_SUPPORT:'+entity)
        if entity in critical and (not v['recall_95ci'] or v['recall_95ci'][0]<cfg['target_critical_recall']):
            failure.append('CRITICAL_RECALL_LOWER_BOUND_BELOW_TARGET:'+entity)
    if decided/rows<cfg['minimum_coverage']:failure.append('COVERAGE_BELOW_TARGET')
    # Require each source group's empirical precision: pooled success cannot hide
    # poor performance in an individual source. CI still refers to span counts;
    # examples within a table are correlated, not independent observations.
    for group,v in per_group.items():
        if v['tp']+v['fp'] and v['tp']/(v['tp']+v['fp'])<cfg['target_precision']:failure.append('SOURCE_GROUP_PRECISION_BELOW_TARGET')
    tier_ci=wilson(tier_correct,tier_evaluated)
    if tier_evaluated<cfg['minimum_tier_examples']:failure.append('INSUFFICIENT_TIER_EVALUATION_SUPPORT')
    if not tier_ci or tier_ci[0]<cfg['target_tier_accuracy']:failure.append('TIER_ACCURACY_LOWER_BOUND_BELOW_TARGET')
    return {'evaluated_at':now(),'bundle_id':bundle_id,'dataset_signature':digest(data_signature),
        'configuration_signature':digest([settings,PROMPTS,RELEASE_VERSION]),'rows':rows,'source_groups':len(groups),'overall':overall,
        'per_entity':entities,'decision_coverage':decided/rows,'negative_examples':negative,
        'false_positive_negative_examples':false_positive_negative,'tier_accuracy':tier_correct/tier_evaluated if tier_evaluated else None,
        'tier_examples':tier_evaluated,'tier_accuracy_95ci':tier_ci,'quality_gate_passed':not failure,'gate_failures':sorted(set(failure)),
        'targets':cfg,'match_rule':'SAME_ENTITY_IOU_AT_LEAST_0.5',
        'limitations':'Span-level Wilson intervals assume independence; also review table/source-stratified results and rare entities. Not a whole-catalog accuracy claim.'}
