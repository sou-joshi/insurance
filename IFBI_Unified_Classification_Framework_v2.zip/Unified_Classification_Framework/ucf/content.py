"""Bounded value profiling, content drift and evidence-bound reconciliation."""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
import math, time
from .core import digest, now, qi, PRIORITY, mapped_requirement, RELEASE_VERSION
from .content_config import content_settings
from .value_models import Ensemble,PROMPTS

def moment(value):return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(timezone.utc)
def supported(row):
    typ=row['data_type'].lower().strip()
    return not any(typ.startswith(t) for t in ('array','map','struct','binary','variant','interval','void'))

def sample_query(rows,settings,version=None):
    if not rows or len({r['table_key'] for r in rows})!=1:raise ValueError('SAMPLE_REQUIRES_ONE_TABLE')
    if len(rows)>settings['maximum_columns_per_query']:raise ValueError('SAMPLE_COLUMN_BUDGET')
    r=rows[0];table='.'.join(qi(r[k]) for k in ('catalog_name','schema_name','table_name'))
    projections=[]
    length=settings['maximum_value_chars']
    for i,row in enumerate(rows):
        col=qi(row['column_name'])
        projections.extend([f'substring(CAST({col} AS STRING),1,{length}) AS c{i}',
                            f'length(CAST({col} AS STRING))>{length} AS t{i}'])
    n=settings['rows_per_table']
    sample=f' TABLESAMPLE ({n} ROWS)' if settings['sample_strategy']=='RESERVOIR' else ''
    # Values appear only in the result, never SQL text or statement parameters.
    snapshot=f' VERSION AS OF {int(version)}' if version is not None else ''
    return f'SELECT '+','.join(projections)+f' FROM {table}{snapshot}{sample} LIMIT {n}'

def read_sample_batches(w,rows,settings,version):
    """Adapt wide text batches to the warehouse's inline-result byte cap."""
    try:data=w.sql(sample_query(rows,settings,version))
    except RuntimeError as exc:
        if str(exc)!='TRUNCATED_RESULT_REJECTED' or len(rows)<2:raise
        middle=len(rows)//2
        yield from read_sample_batches(w,rows[:middle],settings,version)
        yield from read_sample_batches(w,rows[middle:],settings,version)
        return
    yield rows,data

def profile_column(row,values,ensemble,settings,signature,truncated_rows=0):
    counts=Counter(str(v).strip() for v in values if v is not None and str(v).strip())
    # Hash ordering is ephemeral and never persisted; cap distinct inference work.
    chosen=sorted(counts,key=lambda x:digest(x))[:settings['maximum_values_per_column']]
    evaluated_rows=sum(counts[x] for x in chosen)
    hit_rows=Counter();candidate_rows=Counter();sources=defaultdict(set);strengths=defaultdict(list)
    conflict_rows=0
    # Context disambiguates policy/claim IDs while detections must lie inside
    # actual values. Existing sensitivity tags are never model input.
    prefix='Table '+row['table_name'][:80]+'; column '+row['column_name'][:80]+'; value: '
    batches=ensemble.identify_many([prefix+value for value in chosen])
    for value,findings in zip(chosen,batches):
        findings=[f for f in findings if f['start']>=len(prefix) and f['end']<=len(prefix)+len(value)]
        accepted={f['entity'] for f in findings if f['consensus']}
        candidates={f['entity'] for f in findings}
        for entity in accepted:hit_rows[entity]+=counts[value]
        for entity in candidates:candidate_rows[entity]+=counts[value]
        if any(f['conflict'] for f in findings):conflict_rows+=counts[value]
        for f in findings:
            sources[f['entity']].update(f['model_sources'])
            if f['consensus']:strengths[f['entity']].append(f['evidence_strength'])
    entities=[]
    for entity in sorted(candidate_rows):
        hits=hit_rows[entity];fraction=hits/evaluated_rows if evaluated_rows else 0.
        supported_evidence=(evaluated_rows>=settings['minimum_nonempty_values']
            and hits>=settings['minimum_matching_values'] and fraction>=settings['minimum_match_fraction'])
        entities.append({'entity':entity,'matching_rows':hits,'candidate_rows':candidate_rows[entity],
            'fraction':fraction,'model_sources':sorted(sources[entity]),
            'evidence_strength':min(strengths[entity],default=0.),'supported':supported_evidence})
    non_null=sum(v is not None for v in values);nonempty=sum(counts.values())
    status=('EMPTY_SAMPLE' if not values else 'ALL_NULL_OR_MASKED' if non_null==0 else
            'NO_READABLE_VALUES' if nonempty==0 else 'INSUFFICIENT_SAMPLE' if evaluated_rows<settings['minimum_nonempty_values'] else
            'PROFILED')
    return {'asset_key':row['asset_key'],'input_hash':row['input_hash'],'profile_signature':signature,
       'profile_status':status,'profiled_at':now(),'sampled_rows':len(values),'non_null_rows':non_null,
       'nonempty_rows':nonempty,'evaluated_rows':evaluated_rows,'unique_values_evaluated':len(chosen),
       'value_budget_limited':len(chosen)<len(counts),'truncated_rows':truncated_rows,
       'null_fraction':1-non_null/len(values) if values else None,'entities':entities,
       'sensitive_signal':any(hit_rows[e]>0 for e in settings['entity_tiers']),
       'conflicting_rows':conflict_rows,'sample_strategy':settings['sample_strategy'],
       'scope':'SAMPLED_VALUES_ONLY','policy_version':settings['policy_version'],
       'context_used':'TABLE_AND_COLUMN_NAMES_NO_EXISTING_TARGET_LABEL'}

def drift(previous,current,settings):
    """Large, statistically supported sample changes; not a fraud assertion."""
    if not previous or previous.get('profile_signature')!=current.get('profile_signature'):return []
    result=[]
    def changed(p,q,n,m):
        if min(n,m)<30 or p is None or q is None or abs(p-q)<settings['drift_fraction']:return False
        pooled=(p*n+q*m)/(n+m);se=math.sqrt(pooled*(1-pooled)*(1/n+1/m))
        return se==0 or abs(p-q)>3*se
    if changed(previous.get('null_fraction'),current.get('null_fraction'),previous.get('sampled_rows',0),current['sampled_rows']):
        result.append('NULL_RATE_CHANGED')
    old={x['entity']:x['fraction'] for x in previous.get('entities',[])}
    new={x['entity']:x['fraction'] for x in current.get('entities',[])}
    if any(changed(old.get(e,0.),new.get(e,0.),previous.get('evaluated_rows',0),current['evaluated_rows']) for e in old.keys()|new.keys()):
        result.append('SENSITIVE_CONTENT_DISTRIBUTION_CHANGED')
    return result

def reconciliation(row,profile,rules,settings,collate=None):
    # Source mappings are passed separately by caller; keep this function pure.
    source_label,source_bad=rules
    entities=[e for e in profile.get('entities',[]) if e.get('supported') and e['entity'] in settings['entity_tiers']]
    tier=min((settings['entity_tiers'][e['entity']] for e in entities),key=PRIORITY.get,default=None)
    score=min((e['evidence_strength'] for e in entities),default=None)
    status=profile['profile_status']
    findings=[]
    if profile.get('sensitive_signal') and row['current_sensitivity'] not in PRIORITY:
        findings.append('SENSITIVE_CONTENT_WITHOUT_CLASSIFICATION')
    if profile.get('conflicting_rows'):findings.append('MODEL_ENTITY_DISAGREEMENT')
    if len(entities)>1:findings.append('MULTIPLE_SENSITIVE_ENTITY_TYPES')
    current=row.get('current_sensitivity')
    usable=status=='PROFILED' and not profile.get('stale',False)
    if not usable:outcome='READABLE_SAMPLE_REQUIRED' if status in ('ALL_NULL_OR_MASKED','EMPTY_SAMPLE','NO_READABLE_VALUES','INSUFFICIENT_SAMPLE') else 'CONTENT_EVIDENCE_UNAVAILABLE'
    elif not tier:outcome='REVIEW_WEAK_OR_NO_SENSITIVE_EVIDENCE'
    elif source_bad or source_label and source_label!=tier:outcome='CONFLICTING_EVIDENCE';findings.append('SOURCE_MODEL_DISAGREEMENT')
    elif current not in PRIORITY:outcome='REVIEW_CLASSIFICATION_MISMATCH'
    elif PRIORITY[current]<PRIORITY[tier]:outcome='REVIEW_POSSIBLE_DOWNGRADE'
    elif current==tier:outcome='AGREES_WITH_CURRENT_LABEL'
    else:outcome='REVIEW_CLASSIFICATION_MISMATCH';findings.append('CONTENT_TIER_STRONGER_THAN_EXISTING')
    if row.get('is_connector_metadata'):outcome='CONNECTOR_METADATA_REVIEW_EXCLUDED';tier=None
    source=(collate or {}).get('status','DISABLED')
    collate_labels=(collate or {}).get('classifications',[])
    collate_result='NO_USABLE_COLLATE_CLASSIFICATION'
    if collate_labels and tier:
        collate_result='AGREES' if collate_labels==[tier] else 'DISAGREES'
        if collate_result=='DISAGREES':findings.append('COLLATE_MODEL_DISAGREEMENT')
    signature=digest([row['input_hash'],row['evidence_hash'],profile,source_label,collate,settings['entity_tiers']])
    return {'asset_key':row['asset_key'],'input_hash':row['input_hash'],'evidence_hash':row['evidence_hash'],
        'recommendation_signature':signature,'current_sensitivity':current,
        'ml_identified_label':tier if usable else None,
        'recommended_label':tier if usable and outcome!='CONFLICTING_EVIDENCE' else None,
        'recommendation_status':outcome,'model_id':profile.get('profile_signature'),'model_score':score,
        'score_interpretation':'UNCALIBRATED_ENSEMBLE_EVIDENCE_STRENGTH',
        'policy_status':'APPROVED' if settings['policy_approved'] else 'DRAFT_MAPPING_REVIEW_REQUIRED',
        'policy_version':settings['policy_version'],'source_mapped_label':source_label,
        'detected_entities':[e['entity'] for e in entities],
        'profile_status':status,'profiled_at':profile.get('profiled_at'),'evidence_stale':not usable,
        'collate_feed_status':source,'collate_classifications':collate_labels,'collate_comparison':collate_result,
        'findings':sorted(set(findings+profile.get('drift_findings',[]))),
        'reason':'Value-model evidence and configured entity policy; sampled scope only; no automatic tag changes',
        'generated_at':now()}

def scan(w,rows,c,previous=(),ensemble=None,signature=None,clock=time.monotonic):
    settings=content_settings(c)
    old={p['asset_key']:{k:v for k,v in p.items() if not k.startswith('_')} for p in previous}
    if not settings['enabled']:return [],{'status':'DISABLED'}
    started=clock();stamp=datetime.now(timezone.utc)
    if ensemble is None:
        from .assets import load_ensemble
        ensemble,signature=load_ensemble(settings)
    signature=signature or digest(['injected-test-ensemble',settings])
    # Include decisions in the profiling signature; changed thresholds never reuse
    # an old consensus. A tag-only change can reconcile a still-fresh value profile.
    signature=digest([signature,RELEASE_VERSION,PROMPTS,{k:v for k,v in settings.items() if k not in ('model_directory','device')}])
    due=[];profiles={};groups=defaultdict(list)
    for r in rows:
        prior=old.get(r['asset_key'])
        fresh=bool(prior and prior.get('input_hash')==r['input_hash'] and prior.get('profile_signature')==signature
            and prior.get('profile_status')=='PROFILED' and stamp-moment(prior['profiled_at'])<timedelta(hours=settings['refresh_hours']))
        if r['is_connector_metadata'] or not supported(r):
            profiles[r['asset_key']]={'asset_key':r['asset_key'],'input_hash':r['input_hash'],
                'profile_signature':signature,'profile_status':'EXCLUDED_CONNECTOR' if r['is_connector_metadata'] else 'UNSUPPORTED_TYPE',
                'profiled_at':now(),'entities':[],'sensitive_signal':False}
        elif fresh:profiles[r['asset_key']]=prior
        else:due.append(r)
    # New columns first, then oldest observations; no permanent starvation behind
    # unreadable tables. Each attempt advances the scheduling timestamp.
    due.sort(key=lambda r:(r['asset_key'] in old,old.get(r['asset_key'],{}).get('attempted_at',old.get(r['asset_key'],{}).get('profiled_at','')),r['asset_key']))
    selected=due[:settings['maximum_columns_per_run']]
    for r in selected:groups[r['table_key']].append(r)
    attempted=0;errors=0;tables=0
    for table_rows in groups.values():
        if tables>=settings['maximum_tables_per_run'] or clock()-started>=settings['maximum_run_seconds']:break
        tables+=1
        width=settings['maximum_columns_per_query']
        version=None;snapshot_error=None
        if settings.get('require_delta_snapshot',True):
            try:
                r=table_rows[0];source='.'.join(qi(r[k]) for k in ('catalog_name','schema_name','table_name'))
                history=w.sql('DESCRIBE HISTORY '+source+' LIMIT 1')
                version=int(history[0]['version'])
                if version<0:raise ValueError('INVALID_DELTA_VERSION')
            except Exception as exc:snapshot_error=exc
        for start in range(0,len(table_rows),width):
            if clock()-started>=settings['maximum_run_seconds']:break
            part=table_rows[start:start+width]
            try:
                if snapshot_error:raise snapshot_error
                for subgroup,data in read_sample_batches(w,part,settings,version):
                    for i,r in enumerate(subgroup):
                        if clock()-started>=settings['maximum_run_seconds']:break
                        attempted+=1
                        try:
                            profile=profile_column(r,[x.get('c'+str(i)) for x in data],ensemble,settings,signature,
                                sum(str(x.get('t'+str(i))).lower()=='true' for x in data))
                            profile['drift_findings']=drift(old.get(r['asset_key']),profile,settings)
                        except Exception as exc:
                            errors+=1;profile={'asset_key':r['asset_key'],'input_hash':r['input_hash'],'profile_signature':signature,
                              'profile_status':'MODEL_INFERENCE_ERROR','entities':[],'error_type':type(exc).__name__,
                              'profiled_at':now(),'sensitive_signal':False}
                        profile.update(attempted_at=now(),source_version=version,
                            source_snapshot_mode='DELTA_VERSION' if version is not None else 'LIVE_QUERY')
                        profiles[r['asset_key']]=profile
            except Exception as exc:
                errors+=len(part)
                for r in part:
                    attempted+=1;profiles[r['asset_key']]={'asset_key':r['asset_key'],'input_hash':r['input_hash'],
                        'profile_signature':signature,'profile_status':'SAMPLE_READ_ERROR','entities':[],
                        'error_type':type(exc).__name__,'statement_id':getattr(exc,'statement_id',None),
                        'profiled_at':now(),'attempted_at':now(),'sensitive_signal':False}
    for r in rows:
        if r['asset_key'] in profiles:continue
        prior=old.get(r['asset_key'])
        # Preserve prior evidence only with identical column metadata. It is
        # explicitly stale and cannot become a current positive/negative claim.
        if prior and prior.get('input_hash')==r['input_hash']:
            profiles[r['asset_key']]=dict(prior,stale=True,profile_status='STALE_RESCAN_DUE')
        else:profiles[r['asset_key']]={'asset_key':r['asset_key'],'input_hash':r['input_hash'],
            'profile_signature':signature,'profile_status':'PENDING_SCAN','entities':[],'sensitive_signal':False}
    outcomes=Counter(p['profile_status'] for p in profiles.values())
    unfinished=sum(p['profile_status'] in ('PENDING_SCAN','STALE_RESCAN_DUE') for p in profiles.values())
    read_gaps=sum(p['profile_status'] in ('ALL_NULL_OR_MASKED','EMPTY_SAMPLE','NO_READABLE_VALUES','INSUFFICIENT_SAMPLE') for p in profiles.values())
    return list(profiles.values()),{'status':'DEGRADED' if errors else 'PARTIAL' if unfinished else 'READ_GAPS' if read_gaps else 'COMPLETE',
        'profile_signature':signature,'attempted_columns':attempted,'profile_outcomes':dict(outcomes),
        'remaining_columns':unfinished,'error_columns':errors,'readable_profiled_columns':outcomes['PROFILED'],
        'read_gap_columns':read_gaps,'scope':'SAMPLED_VALUES_ONLY',
        'elapsed_seconds':round(clock()-started,2)}
