"""Local pretrained detectors. Raw values and spans never enter the journal.

The ensemble score is evidence strength, NOT a calibrated probability of a tier.
Model agreement is evaluated on overlapping spans within the SAME value.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
import math, os, re

PROMPTS = {
    'person name':'PERSON', 'email address':'EMAIL', 'phone number':'PHONE',
    'street address':'ADDRESS', 'social security number':'SSN',
    'date of birth':'DATE_OF_BIRTH', 'bank account number':'BANK_ACCOUNT',
    'credit card number':'CREDIT_CARD', 'driver license number':'DRIVER_LICENSE',
    'insurance policy number':'POLICY_ID', 'insurance claim number':'CLAIM_ID',
    'vehicle identification number':'VIN', 'medical record number':'MEDICAL_RECORD',
    'medical condition':'MEDICAL_CONDITION',
}
ENTITIES = set(PROMPTS.values()) | {'ORGANIZATION','LOCATION'}

@dataclass(frozen=True)
class Span:
    start: int
    end: int
    entity: str
    score: float
    source: str

def offline_environment():
    # Set before any model imports. Runtime uses local assets, never an API backend.
    for key in ('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_HUB_DISABLE_TELEMETRY','DO_NOT_TRACK'):
        os.environ[key] = '1'
    os.environ['TABPFN_DISABLE_TELEMETRY']='1'
    os.environ['SCARF_NO_ANALYTICS']='true'

class GLiNERDetector:
    def __init__(self, name, path, device='cpu', threshold=.65):
        offline_environment()
        from gliner import GLiNER
        self.name=name; self.threshold=threshold
        self.model=GLiNER.from_pretrained(str(path), local_files_only=True,
            map_location=device, strict=True)
        self.model.eval()

    def detect(self, text):
        result=self.model.predict_entities(text, list(PROMPTS), threshold=self.threshold,
                                           flat_ner=False, multi_label=True)
        return [Span(int(s['start']),int(s['end']),PROMPTS[s['label']],float(s['score']),self.name)
                for s in result if s['label'] in PROMPTS]

    def detect_many(self,texts,batch_size=8):
        result=self.model.inference(texts,list(PROMPTS),threshold=self.threshold,
            flat_ner=False,multi_label=True,batch_size=batch_size)
        return [[Span(int(s['start']),int(s['end']),PROMPTS[s['label']],float(s['score']),self.name)
                for s in group if s['label'] in PROMPTS] for group in result]

class BertNERDetector:
    """Independent architecture supporting PERSON only for sensitivity fusion.

    ORG/LOC are contextual entities; a location mention alone is not a PII claim.
    """
    def __init__(self, name, path, device='cpu', threshold=.80):
        offline_environment()
        from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
        self.name=name; self.threshold=threshold
        tokenizer=AutoTokenizer.from_pretrained(str(path),local_files_only=True,trust_remote_code=False)
        model=AutoModelForTokenClassification.from_pretrained(str(path),local_files_only=True,
            trust_remote_code=False,use_safetensors=True)
        model.eval()
        self.pipe=pipeline('token-classification',model=model,tokenizer=tokenizer,
            aggregation_strategy='simple',device=-1 if device=='cpu' else int(device.split(':')[-1]) if ':' in device else 0)

    def detect(self,text):
        labels={'PER':'PERSON','ORG':'ORGANIZATION','LOC':'LOCATION'}
        return [Span(int(s['start']),int(s['end']),labels[s['entity_group']],float(s['score']),self.name)
                for s in self.pipe(text) if s['entity_group'] in labels and float(s['score'])>=self.threshold]

    def detect_many(self,texts,batch_size=8):
        labels={'PER':'PERSON','ORG':'ORGANIZATION','LOC':'LOCATION'}
        return [[Span(int(s['start']),int(s['end']),labels[s['entity_group']],float(s['score']),self.name)
                 for s in group if s['entity_group'] in labels and float(s['score'])>=self.threshold]
                for group in self.pipe(texts,batch_size=batch_size)]

def luhn(value):
    digits=[int(x) for x in re.sub(r'\D','',value)]
    if not 13<=len(digits)<=19 or len(set(digits))<2:return False
    total=0
    for i,x in enumerate(reversed(digits)):
        if i%2:x=x*2-9 if x*2>9 else x*2
        total+=x
    return total%10==0

def vin_valid(value):
    value=value.upper()
    if not re.fullmatch(r'[A-HJ-NPR-Z0-9]{17}',value):return False
    groups=['ABCDEFGH','JKLMNPR','STUVWXYZ']
    nums=['12345678','1234579','23456789']
    convert={str(i):i for i in range(10)}
    for letters,values in zip(groups,nums):convert.update({a:int(b) for a,b in zip(letters,values)})
    check=sum(convert[x]*w for x,w in zip(value,[8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2]))%11
    return value[8]==('X' if check==10 else str(check))

def validated_spans(text):
    """Validators corroborate format, not identity, ownership, or validity of an account."""
    patterns={
      'EMAIL':r'(?<![\w.+-])[\w.+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?!\w)',
      'SSN':r'(?<!\d)(?!000|666|9\d\d)\d{3}[- ](?!00)\d{2}[- ](?!0000)\d{4}(?!\d)',
      'CREDIT_CARD':r'(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)',
      'VIN':r'(?<![A-Za-z0-9])[A-HJ-NPR-Z0-9]{17}(?![A-Za-z0-9])',
    }
    result=[]
    for entity,pattern in patterns.items():
        for match in re.finditer(pattern,text):
            value=match.group()
            if entity=='CREDIT_CARD' and not luhn(value):continue
            if entity=='VIN' and not vin_valid(value):continue
            result.append(Span(match.start(),match.end(),entity,1.,'validator'))
    return result

def overlaps(a,b):return max(a.start,b.start)<min(a.end,b.end)

def fuse(text, spans, minimum_model_score=.80, minimum_models=2):
    """Keep single-model/format-only evidence visible but outside consensus.

    Conservative clustering requires pairwise overlap; no transitive chain can
    turn predictions about different values into corroboration.
    """
    checked=[]
    for s in spans:
        if s.entity not in ENTITIES or s.source=='validator':continue
        if not 0<=s.start<s.end<=len(text) or not math.isfinite(s.score) or not 0<=s.score<=1:
            raise ValueError('INVALID_MODEL_SPAN')
        checked.append(s)
    checked+=validated_spans(text)
    groups=[]
    for s in sorted(checked,key=lambda s:(s.entity,s.start,s.end,s.source)):
        group=next((g for g in groups if g[0].entity==s.entity and all(overlaps(s,x) for x in g)),None)
        if group is None:groups.append([s])
        else:group.append(s)
    output=[]
    for group in groups:
        strongest={}
        for s in group:
            if s.source not in strongest or s.score>strongest[s.source].score:strongest[s.source]=s
        models=[s for s in strongest.values() if s.source!='validator' and s.score>=minimum_model_score]
        validated='validator' in strongest
        agreed=len(models)>=minimum_models or (len(models)>=1 and validated)
        output.append({'entity':group[0].entity,'start':min(s.start for s in group),'end':max(s.end for s in group),
            'model_sources':sorted(s.source for s in models),'format_validated':validated,
            'evidence_strength':min((s.score for s in models),default=0.),
            'consensus':agreed,'conflict':False})
    # Competing entity labels for the same substring need review, even when
    # several related models agree. Never add their scores as probabilities.
    for a in output:
        for b in output:
            if a is b or a['entity']==b['entity']:continue
            # General-news ORG/LOC predictions are contextual, not competing
            # sensitive identifiers. They must not veto a validated SSN/card.
            if a['entity'] in ('ORGANIZATION','LOCATION') or b['entity'] in ('ORGANIZATION','LOCATION'):continue
            if max(a['start'],b['start'])<min(a['end'],b['end']):
                if a['format_validated'] and a['model_sources'] and not b['format_validated']:continue
                a['conflict']=True;a['consensus']=False
    return output

def chunks(text, size=256, overlap=64):
    if not 0<=overlap<size:raise ValueError('INVALID_CHUNK_OVERLAP')
    for start in range(0,len(text),size-overlap):
        yield start,text[start:start+size]
        if start+size>=len(text):break

class Ensemble:
    def __init__(self,detectors,settings):
        if len({d.name for d in detectors})!=len(detectors):raise ValueError('DUPLICATE_MODEL_SOURCE')
        self.detectors=detectors;self.settings=settings

    def identify(self,value):
        return self.identify_many([value])[0]

    def identify_many(self,values):
        work=[];spans=[[] for _ in values]
        for i,value in enumerate(values):
            work.extend((i,offset,piece) for offset,piece in chunks(value,self.settings['chunk_chars'],self.settings['chunk_overlap']))
        # Bounded batching avoids one full model call per cell while limiting
        # accelerator memory. No global raw-value cache survives the batch.
        for start in range(0,len(work),32):
            group=work[start:start+32];texts=[x[2] for x in group]
            for detector in self.detectors:
                results=(detector.detect_many(texts,batch_size=8) if hasattr(detector,'detect_many')
                         else [detector.detect(t) for t in texts])
                if len(results)!=len(group):raise ValueError('INCOMPLETE_MODEL_BATCH')
                for (i,offset,_),predictions in zip(group,results):
                    for s in predictions:spans[i].append(Span(s.start+offset,s.end+offset,s.entity,s.score,s.source))
        return [fuse(value,pred,self.settings['minimum_model_score'],self.settings['minimum_models'])
                for value,pred in zip(values,spans)]
