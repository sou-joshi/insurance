"""SQL Statement Execution API transport. No Spark, external result links or secrets in SQL."""
from __future__ import annotations
import json, re, time
from .core import table, dumps, now

class SqlError(RuntimeError):
    def __init__(self,statement_id):
        self.statement_id=statement_id
        super().__init__('SQL_FAILED statement_id='+statement_id)

class Warehouse:
    def __init__(self,c,client=None):
        self.c=c
        if client is None:
            from databricks.sdk import WorkspaceClient
            client=WorkspaceClient(**({'profile':c['profile']} if c.get('profile') else {}))
        self.client=client
    def sql(self,statement,params=None):
        body={'warehouse_id':self.c['warehouse_id'],'statement':statement,
              'wait_timeout':'10s','on_wait_timeout':'CONTINUE','disposition':'INLINE','format':'JSON_ARRAY',
              'byte_limit':self.c.get('maximum_result_bytes',20000000)}
        if params: body['parameters']=[{'name':k,'value':str(v),'type':'STRING'} for k,v in params.items()]
        api=self.client.api_client
        response=api.do('POST','/api/2.0/sql/statements',body=body)
        sid=response['statement_id'];start=time.monotonic()
        while response.get('status',{}).get('state') in ('PENDING','RUNNING'):
            if time.monotonic()-start>self.c['statement_timeout_seconds']:
                api.do('POST',f'/api/2.0/sql/statements/{sid}/cancel')
                raise TimeoutError('SQL statement exceeded the configured deadline')
            time.sleep(1)
            response=api.do('GET',f'/api/2.0/sql/statements/{sid}')
        if response.get('status',{}).get('state')!='SUCCEEDED':
            # SQL error messages may contain metadata; keep them out of routine logs.
            raise SqlError(sid)
        manifest=response.get('manifest',{})
        if manifest.get('truncated'): raise RuntimeError('TRUNCATED_RESULT_REJECTED')
        names=[x['name'] for x in manifest.get('schema',{}).get('columns',[])]
        chunk=response.get('result',{});rows=[];seen=set()
        while chunk:
            if chunk.get('external_links'):raise RuntimeError('External result links are not accepted')
            if any(len(row)!=len(names) for row in chunk.get('data_array',[])):raise RuntimeError('Malformed result row')
            rows.extend(dict(zip(names,row)) for row in chunk.get('data_array',[]))
            link=chunk.get('next_chunk_internal_link')
            if not link: break
            if not re.fullmatch(r'/api/2\.0/sql/statements/[A-Za-z0-9-]+/result/chunks/\d+(?:\?[^\s]*)?',link):
                raise RuntimeError('Unexpected result chunk path')
            if link in seen: raise RuntimeError('Repeated result chunk')
            seen.add(link);chunk=api.do('GET',link)
        if manifest.get('total_row_count') is not None and len(rows)!=manifest['total_row_count']:
            raise RuntimeError('INCOMPLETE_RESULT_REJECTED')
        return rows
    def identity(self):
        r=self.sql('SELECT current_user() AS actor, current_metastore() AS metastore')[0]
        return {'metadata_reader':r['actor'],'metastore_id':r['metastore'],'workspace_host':self.client.config.host}
    def preflight(self):
        wh=self.client.api_client.do('GET','/api/2.0/sql/warehouses/'+self.c['warehouse_id'])
        if wh.get('warehouse_type')!='PRO' or wh.get('enable_serverless_compute'):
            raise RuntimeError('Select the existing approved non-serverless Pro warehouse')
    def collect(self):
        catalogs=','.join("'"+s.replace("'","''")+"'" for s in self.c['source_catalogs'])
        excluded=','.join("'"+s.replace("'","''")+"'" for s in self.c['excluded_schemas']) or "''"
        tag_names=','.join("'"+s.replace("'","''")+"'" for s in ['ifbi_sensitivity']+self.c['mapping']['signal_tags'])
        output=self.c['output_schema'].replace("'","''");outcat=self.c['output_catalog'].replace("'","''")
        description='c.comment' if self.c['include_descriptions'] else 'CAST(NULL AS STRING)'
        query=f'''WITH tags AS (
          SELECT catalog_name,schema_name,table_name,column_name,
           to_json(sort_array(collect_set(CASE WHEN tag_name='ifbi_sensitivity' THEN tag_value END))) AS sensitivity_values,
           to_json(collect_list(named_struct('tag_name',tag_name,'tag_value',tag_value))) AS signals
          FROM system.information_schema.column_tags WHERE catalog_name IN ({catalogs}) AND tag_name IN ({tag_names})
          GROUP BY catalog_name,schema_name,table_name,column_name)
        SELECT c.table_catalog AS catalog_name,c.table_schema AS schema_name,c.table_name,c.column_name,
          c.full_data_type AS data_type,{description} AS description,t.sensitivity_values,t.signals,
          'Assign steward' AS remediation_owner
        FROM system.information_schema.columns c LEFT JOIN tags t
         ON c.table_catalog=t.catalog_name AND c.table_schema=t.schema_name
         AND c.table_name=t.table_name AND c.column_name=t.column_name
        WHERE c.table_catalog IN ({catalogs}) AND c.table_schema NOT IN ({excluded})
         AND NOT(c.table_catalog='{outcat}' AND c.table_schema='{output}')
        LIMIT {self.c['maximum_columns']+1}'''
        return self.sql(query)
    def rules(self):
        if not self.c['mapping']['table']: return []
        from .core import fq
        return self.sql('SELECT source_tag_name,source_tag_value,ifbi_classification,tier_priority FROM '+fq(self.c['mapping']['table']))

class Journal:
    def __init__(self,w,c): self.w=w;self.c=c;self.name=table(c,'journal');self.framework=c['environment']
    def initialize(self):
        self.w.sql(f'''CREATE TABLE IF NOT EXISTS {self.name} (
          framework_id STRING,run_id STRING,record_type STRING,record_id STRING,
          observed_at TIMESTAMP,payload_json STRING) USING DELTA
          COMMENT 'Unified classification framework; metadata and aggregate profiles; no raw values or tag writeback'
          TBLPROPERTIES ('ucf.component'='ucf_v1') ''')
        detail=self.w.sql('DESCRIBE DETAIL '+self.name)[0]
        props=detail.get('properties',{})
        if isinstance(props,str): props=json.loads(props)
        if detail.get('format')!='delta' or props.get('ucf.component')!='ucf_v1':
            raise RuntimeError('Journal identity or storage format differs')
        # Prevent adopting a table containing another deployment's records.
        r=self.w.sql(f'SELECT COUNT(*) AS n FROM {self.name} WHERE framework_id<>:fid',{'fid':self.framework})
        if int(r[0]['n']): raise RuntimeError('Use a dedicated output prefix for this environment')
    def append(self,run_id,kind,records):
        # Idempotent batch MERGE. Only RUN markers make staged run data visible.
        pairs=list(records)
        for i in range(0,len(pairs),100):
            batch=[{'record_id':key,'payload_json':dumps(data)} for key,data in pairs[i:i+100]]
            self.w.sql(f'''MERGE INTO {self.name} t USING (
              SELECT :fid AS framework_id,:run AS run_id,:kind AS record_type,
               r.record_id,r.payload_json,current_timestamp() AS observed_at
              FROM (SELECT explode(from_json(:payload,'ARRAY<STRUCT<record_id:STRING,payload_json:STRING>>')) AS r)) s
              ON t.framework_id=s.framework_id AND t.run_id=s.run_id
               AND t.record_type=s.record_type AND t.record_id=s.record_id
              WHEN NOT MATCHED THEN INSERT *''',
              {'fid':self.framework,'run':run_id,'kind':kind,'payload':dumps(batch)})
    def read(self,kind,run_id=None,published=True):
        extra=' AND j.run_id=:run' if run_id else ''
        publication=(f" AND EXISTS(SELECT 1 FROM {self.name} p WHERE p.framework_id=j.framework_id AND p.run_id=j.run_id AND p.record_type='RUN')" if published else '')
        params={'fid':self.framework,'kind':kind}
        if run_id: params['run']=run_id
        rows=self.w.sql(f'''SELECT j.record_id,j.payload_json,j.run_id,cast(j.observed_at AS STRING) AS stored_at
          FROM {self.name} j WHERE j.framework_id=:fid AND j.record_type=:kind{extra}{publication}
          ORDER BY j.observed_at,j.run_id,j.record_id''',params)
        return [dict(json.loads(r['payload_json']),_record_id=r['record_id'],_run_id=r['run_id'],_stored_at=r['stored_at']) for r in rows]
    def latest_run(self):
        rows=self.w.sql(f'''SELECT run_id,payload_json FROM {self.name} WHERE framework_id=:fid AND record_type='RUN'
          ORDER BY observed_at DESC,run_id DESC LIMIT 1''',{'fid':self.framework})
        return dict(json.loads(rows[0]['payload_json']),run_id=rows[0]['run_id']) if rows else None
    def load_state(self,run_id):
        head=self.read('CONTROL',run_id)[0]
        return {'control':head['control'],'summary':head['summary'],
                **{key:{r['_record_id']:{k:v for k,v in r.items() if not k.startswith('_')} for r in self.read(kind,run_id)}
                   for kind,key in [('COLUMN','columns'),('ISSUE','issues'),('NOTICE','pending')]}}
    def publish(self,run_id,state,rows,recommendations,summary):
        for kind,items in [('SNAPSHOT',[(r['asset_key'],r) for r in rows]),
                           ('COLUMN',list(state['columns'].items())),('ISSUE',list(state['issues'].items())),
                           ('NOTICE',list(state['pending'].items())),('RECOMMENDATION',[(r['asset_key'],r) for r in recommendations]),
                           ('CONTROL',[(run_id,{'control':state['control'],'summary':state['summary']})])]:
            self.append(run_id,kind,items)
        self.append(run_id,'RUN',[(run_id,summary)])

