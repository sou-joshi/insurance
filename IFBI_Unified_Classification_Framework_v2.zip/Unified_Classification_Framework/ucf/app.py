from __future__ import annotations
import argparse,csv,json,os,re,sys,uuid,time
from datetime import datetime,timedelta,timezone
from pathlib import Path
from .core import *
from .warehouse import Warehouse,Journal
from .monitor import evaluate,ScopeError
from .model import train,predict,dataset_signature
from .views import install_views,dashboard_queries
from .notifications import ensure_alerts,evaluate_alert

def clean(record): return {k:v for k,v in record.items() if not k.startswith('_')}
def active_model(j,c):
    models={m['model_id']:clean(m) for m in j.read('MODEL')}
    approvals=j.read('MODEL_APPROVAL',published=False)
    if not approvals:return None
    last=approvals[-1]
    if last.get('decision')!='APPROVED' or last['model_id'] not in models:return None
    artifact=models[last['model_id']]
    expires=datetime.fromisoformat(last['expires_at'])
    if datetime.now(timezone.utc)>expires:return None
    return artifact

def recommend(rows,rules,c,artifact,previous=(),reviews=()):
    old={r['asset_key']:r for r in previous}
    latest_decisions={d['asset_key']:d for d in reviews}
    approved={key:d for key,d in latest_decisions.items() if d.get('decision')=='APPROVED'}
    dirty=[];result=[]
    rule_hash=digest(sorted(rules,key=dumps));model_id=artifact['model_id'] if artifact else 'NO_ACTIVE_MODEL'
    for row in rows:
        d=approved.get(row['asset_key'])
        text=(d['sanitized_text'] if d and d['input_hash']==row['input_hash'] and d['evidence_hash']==row['evidence_hash'] else row['feature_text'])
        signature=digest([row['input_hash'],row['evidence_hash'],model_id,rule_hash,text])
        prior=old.get(row['asset_key'])
        if prior and prior.get('recommendation_signature')==signature:
            result.append(clean(prior));continue
        dirty.append((row,text,signature))
    candidates=[d for d in dirty if not d[0]['is_connector_metadata']]
    preds=predict(artifact,[text for _,text,_ in candidates]) if artifact and candidates else [{} for _ in candidates]
    by_asset={r['asset_key']:p for (r,_,_),p in zip(candidates,preds)}
    for row,text,signature in dirty:
        p=by_asset.get(row['asset_key'],{})
        mapped,bad=mapped_requirement(row,rules,c['mapping']['signal_tags'])
        ml_label=p.get('model_label') if not p.get('abstained',True) else None
        chosen=mapped or ml_label
        if row['is_connector_metadata']:status='CONNECTOR_METADATA_REVIEW_EXCLUDED';chosen=None
        elif bad or (mapped and ml_label and mapped!=ml_label):status='CONFLICTING_EVIDENCE';chosen=None
        elif chosen is None:status='ABSTAIN_NO_APPROVED_MODEL_OR_WEAK_EVIDENCE'
        elif row['actual_priority'] and PRIORITY[chosen]>row['actual_priority']:status='REVIEW_POSSIBLE_DOWNGRADE'
        elif chosen!=row['current_sensitivity']:status='REVIEW_CLASSIFICATION_MISMATCH'
        else:status='AGREES_WITH_CURRENT_LABEL'
        result.append({'asset_key':row['asset_key'],'input_hash':row['input_hash'],'evidence_hash':row['evidence_hash'],
          'recommendation_signature':signature,'model_id':model_id,'recommended_label':chosen,
          'recommendation_status':status,'current_sensitivity':row['current_sensitivity'],
          'reason':'Exact configured source mapping' if mapped else 'Reviewed metadata model ranking' if ml_label else 'Insufficient or conflicting evidence; steward decision required',
          'generated_at':now(),'mapped_label':mapped,**p})
    return result,len(candidates) if artifact else 0

def prepare_state(rows,rules,previous,identity,c,acks):
    observations=[]
    for r in rows:
        label,bad=mapped_requirement(r,rules,c['mapping']['signal_tags'])
        observations.append(dict(r,expected_sensitivity=label,expected_priority=PRIORITY.get(label),invalid_rule_label_count=bad))
    settings=dict(c['monitor'],maximum_columns=c['maximum_columns'],maximum_inventory_drop_fraction=c['maximum_inventory_drop_fraction'])
    state=evaluate(observations,previous,datetime.now(timezone.utc),identity,scope_hash(c),settings,acks)
    if previous is None:
        # One real activation notice, not thousands of baseline incidents.
        notice_id=digest(['activation',scope_hash(c),identity])
        state['pending'][notice_id]={'notice_id':notice_id,'issue_key':'ACTIVATION','asset_key':'ACTIVATION','generation':1,
          'priority':'P3','kind':'SUMMARY','finding_type':'FRAMEWORK_ACTIVATED','owner':'Governance team',
          'catalog_name':'(configured scope)','schema_name':'(summary)','table_name':'(baseline)',
          'created_at':now(),'selected_for_batch':True}
        state['summary']['pending_notifications']=len(state['pending'])
        state['summary']['selected_notifications']=1
    return state

def run(w,j,c,run_id):
    latest=j.latest_run()
    if latest and latest['run_id']==run_id:
        state=j.load_state(run_id)
        resources=ensure_alerts(w,j,c)
        receipt=evaluate_alert(w,j,c,resources,list(state['pending'].values()))
        return dict(latest,reused_committed_run=True,notification_status=receipt)
    if j.read('ATTEMPT',run_id,published=False):
        raise RuntimeError('Unpublished run attempt exists; use a NEW run ID. Staged rows remain invisible.')
    identity=w.identity()
    if latest and (latest['identity']!=identity or latest['scope_hash']!=scope_hash(c)):
        raise ScopeError('COLLECTOR_IDENTITY_OR_SCOPE_CHANGED: review before a separate baseline')
    j.append(run_id,'ATTEMPT',[(run_id,{'started_at':now(),'parent_run_id':latest['run_id'] if latest else None})])
    try:
        raw=w.collect()
        rows=[decorate(r) for r in raw]
        if len({r['asset_key'] for r in rows})!=len(rows):raise ScopeError('DUPLICATE_COLUMN_IDENTITIES')
        if not set(c['source_catalogs']).issubset({r['catalog_name'] for r in rows}):
            raise ScopeError('CONFIGURED_CATALOG_NOT_VISIBLE_OR_EMPTY')
        rules=w.rules() # A configured source that fails is an error, not a clean result.
        prior=j.load_state(latest['run_id']) if latest else None
        acks=j.read('ACK',published=False)
        state=prepare_state(rows,rules,prior,identity,c,acks)
        reviews=j.read('REVIEW',published=False)
        gold=[]
        candidate=None;model_status={'status':'ML_DISABLED'}
        existing_models=j.read('MODEL')
        ml_healthy=True
        if c['ml']['enabled'] and not c.get('content',{}).get('enabled',False):
            try:
                gold=accepted_gold(rows,reviews)
                sig=dataset_signature(gold,c['ml'])
                same=[m for m in existing_models if m['dataset_signature']==sig]
                if same:model_status={'status':'EXISTING_CANDIDATE_REUSED','model_id':same[-1]['model_id']}
                else:
                    candidate,model_status=train(gold,c['ml'])
                    if candidate:j.append(run_id,'MODEL',[(candidate['model_id'],candidate)])
            except (ValueError,ImportError) as exc:
                ml_healthy=False
                model_status={'status':'ML_STAGE_ERROR','error_type':type(exc).__name__}
        artifact=active_model(j,c) if c['ml']['enabled'] and ml_healthy and not c.get('content',{}).get('enabled',False) else None
        previous_recs=j.read('RECOMMENDATION',latest['run_id']) if latest else []
        try:
            recs,scored=([],0) if c.get('content',{}).get('enabled',False) else recommend(rows,rules,c,artifact,previous_recs,reviews)
        except (ValueError,ImportError) as exc:
            artifact=None;model_status={'status':'ML_STAGE_ERROR','error_type':type(exc).__name__}
            recs,scored=recommend(rows,rules,c,None,previous_recs,reviews)
        content_profiles=[];content_state=None;anomaly_rows=[]
        content_summary={'status':'DISABLED'};collate_summary={'status':'DISABLED'};anomaly_summary={'status':'DISABLED'}
        if c.get('content',{}).get('enabled',False):
            from .content import scan,reconciliation
            from .content_config import content_settings
            from .collate import collect as collect_collate
            from .content_alerts import update as update_content,merge_notices
            from .anomalies import run as scan_anomalies
            cs=content_settings(c)
            prior_profiles=j.read('CONTENT_PROFILE',latest['run_id']) if latest else []
            prior_content_records=j.read('CONTENT_STATE',latest['run_id']) if latest else []
            previous_content=clean(prior_content_records[0]) if prior_content_records else None
            try:
                content_profiles,content_summary=scan(w,rows,c,prior_profiles)
            except Exception as exc:
                content_summary={'status':'CONTENT_STAGE_ERROR','error_type':type(exc).__name__}
                content_profiles=[{'asset_key':r['asset_key'],'input_hash':r['input_hash'],
                    'profile_status':'MODEL_ASSETS_OR_RUNTIME_UNAVAILABLE','profiled_at':now(),'entities':[],
                    'sensitive_signal':False,'stale':True} for r in rows]
            try:collate_rows,collate_summary=collect_collate(w,rows,c)
            except Exception as exc:
                collate_rows={};collate_summary={'status':'COLLATE_STAGE_ERROR','error_type':type(exc).__name__,
                    'statement_id':getattr(exc,'statement_id',None)}
            current_profiles={p['asset_key']:p for p in content_profiles}
            recs=[reconciliation(r,current_profiles[r['asset_key']],
                    mapped_requirement(r,rules,c['mapping']['signal_tags']),cs,
                    collate_rows.get(r['asset_key'],{'status':collate_summary['status']})) for r in rows]
            content_state=update_content(rows,recs,content_profiles,previous_content,acks,c)
            merge_notices(state,content_state,c)
            try:
                anomaly_rows,anomaly_summary=scan_anomalies(w,rows,c,j.read('ANOMALY_TABLE',latest['run_id']) if latest else [])
            except Exception as exc:anomaly_summary={'status':'ANOMALY_STAGE_ERROR','error_type':type(exc).__name__}
            acknowledged={x['notice_id'] for x in acks}
            if previous_content is not None:
                for a in anomaly_rows:
                    count=sum(x.get('outlier_count',0) for x in a.get('cohorts',[]))
                    if a.get('stale') or not count:continue
                    notice_id=digest(['ANOMALY_DIGEST',a['table_key'],datetime.now(timezone.utc).date().isoformat()])
                    if notice_id in acknowledged:continue
                    content_state['pending'][notice_id]={'notice_id':notice_id,'issue_key':'ANOMALY_DIGEST',
                        'asset_key':a['table_key'],'generation':1,'priority':'P2','kind':'SUMMARY',
                        'finding_type':'NUMERIC_RECORD_OUTLIERS','owner':'Governance team',
                        'catalog_name':'(configured scope)','schema_name':'(summary)','table_name':a['table_fqn'],
                        'created_at':now(),'outlier_count':count}
            merge_notices(state,content_state,c)
            artifact=None;scored=content_summary.get('attempted_columns',0)
            model_status={'status':'PRETRAINED_CONTENT_INFERENCE','content_status':content_summary['status']}
            j.append(run_id,'CONTENT_PROFILE',[(p['asset_key'],p) for p in content_profiles])
            j.append(run_id,'CONTENT_STATE',[(run_id,content_state)])
            j.append(run_id,'CONTENT_ISSUE',list(content_state['issues'].items()))
            j.append(run_id,'ANOMALY_TABLE',[(a['table_key'],a) for a in anomaly_rows])
            j.append(run_id,'COLLATE_FEED',[(run_id,collate_summary)])
        latest_reviews={r['asset_key']:r for r in reviews}
        pending=[]
        for r in rows:
            d=latest_reviews.get(r['asset_key'])
            if d and d.get('decision')=='APPROVED' and d.get('input_hash')==r['input_hash'] and d.get('evidence_hash')==r['evidence_hash']:continue
            pending.append(r)
        sample=review_sample(pending,c['review'])
        # Model disagreements enter the bounded review queue, while approved
        # labels remain authoritative training decisions until explicitly revised.
        selected={r['asset_key']:r for r in sample}
        current={r['asset_key']:r for r in rows}
        mismatches=[r for r in recs if r['recommendation_status'] in ('REVIEW_CLASSIFICATION_MISMATCH','CONFLICTING_EVIDENCE','REVIEW_POSSIBLE_DOWNGRADE')]
        for r in sorted(mismatches,key=lambda x:x['asset_key'])[:c['review']['per_issue']]:
            selected.setdefault(r['asset_key'],dict(current[r['asset_key']],review_bucket='RECOMMENDATION_REVIEW'))
        j.append(run_id,'REVIEW_CANDIDATE',list(selected.items()))
        summary={'release_version':RELEASE_VERSION,'started_from':'UNIFIED_VALUE_AND_METADATA_CAPTURE' if content_profiles else 'UNIFIED_METADATA_CAPTURE','completed_at':now(),'identity':identity,'scope_hash':scope_hash(c),
          'inventory_columns':len(rows),'reviewed_gold_rows':len(gold),'review_queue_rows':len(selected),
          'mapping_rows':len(rules),'model_stage':model_status,'active_model_id':content_summary.get('profile_signature') or (artifact['model_id'] if artifact else None),
          'model_scored_rows':scored,'recommendation_counts':dict(Counter(r['recommendation_status'] for r in recs)),
          'monitor':state['summary'],'content_stage':content_summary,'collate_stage':collate_summary,
          'anomaly_stage':anomaly_summary,'security_tags_changed':False}
        # Single-writer scheduling is required. This detects an intervening publish.
        current_head=j.latest_run()
        if (current_head or {}).get('run_id')!=(latest or {}).get('run_id'):
            raise RuntimeError('A concurrent writer published; discard this staged attempt')
        j.publish(run_id,state,rows,recs,summary)
        resources=ensure_alerts(w,j,c)
        receipt=evaluate_alert(w,j,c,resources,list(state['pending'].values()))
        return dict(summary,run_id=run_id,notification_status=receipt)
    except Exception as exc:
        # Do not persist arbitrary errors containing tokens, metadata or SQL samples.
        j.append(run_id,'FAILURE',[(uuid.uuid4().hex,{'failed_at':now(),'error_type':type(exc).__name__,
            'statement_id':getattr(exc,'statement_id',None)})])
        raise

def review(j,w,c,args):
    latest=j.latest_run()
    if not latest:raise ValueError('Collect metadata first')
    rows=j.read('SNAPSHOT',latest['run_id']);current={r['asset_key']:r for r in rows}
    row=current.get(args.asset)
    if not row or row['input_hash']!=args.input_hash or row['evidence_hash']!=args.evidence_hash:
        raise ValueError('Review fingerprint is stale; reopen the current column')
    text=Path(args.text_file).read_text(encoding='utf-8').strip() if args.text_file else ''
    if args.decision=='APPROVED' and (args.label not in PRIORITY or not text or not args.group):
        raise ValueError('Approval requires an allowed label, sanitized text and reviewed logical source group')
    if len(text)>4000:raise ValueError('Sanitized text exceeds 4000 characters')
    record={'asset_key':args.asset,'input_hash':args.input_hash,'evidence_hash':args.evidence_hash,
      'decision':args.decision,'label':args.label,'logical_group':args.group,'sanitized_text':text,
      'reviewer':w.identity()['metadata_reader'],'reason':args.reason,'reviewed_at':now()}
    j.append('review-'+uuid.uuid4().hex,'REVIEW',[(uuid.uuid4().hex,record)])
    return {'status':'REVIEW_RECORDED','security_tags_changed':False}

def approve_model(j,w,c,args):
    models={m['model_id']:m for m in j.read('MODEL')}
    artifact=models.get(args.model_id)
    if not artifact or not artifact['metrics']['quality_gate_passed']:raise ValueError('Candidate has not passed the configured evaluation gates')
    latest=j.latest_run();gold=accepted_gold(j.read('SNAPSHOT',latest['run_id']),j.read('REVIEW',published=False))
    if artifact['dataset_signature']!=dataset_signature(gold,c['ml']):raise ValueError('Gold set/settings changed since this evaluation; rerun training first')
    record={'model_id':args.model_id,'decision':'APPROVED','reason':args.reason,
      'approver':w.identity()['metadata_reader'],'approved_at':now(),
      'expires_at':(datetime.now(timezone.utc)+timedelta(days=c['ml']['maximum_model_age_days'])).isoformat()}
    j.append('model-approval-'+uuid.uuid4().hex,'MODEL_APPROVAL',[(uuid.uuid4().hex,record)])
    return {'status':'APPROVED_FOR_RECOMMENDATIONS_ONLY','model_id':args.model_id}

def review_export(j,args):
    latest=j.latest_run()
    if not latest:raise ValueError('Collect metadata first')
    decisions={d['asset_key']:d for d in j.read('REVIEW',published=False)}
    fields=['asset_key','input_hash','evidence_hash','catalog_name','schema_name','table_name','column_name',
      'current_sensitivity','review_bucket','expected_review_id','decision','label','logical_group','reason','sanitized_text']
    with open(args.file,'x',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for r in j.read('REVIEW_CANDIDATE',latest['run_id']):
            row={k:r.get(k,'') for k in fields}
            row.update(expected_review_id=decisions.get(r['asset_key'],{}).get('_record_id',''),
                       decision='',label='',logical_group='',reason='',sanitized_text=r['feature_text'])
            # Prevent spreadsheet formula execution from untrusted metadata.
            writer.writerow({k:("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v) for k,v in row.items()})
    return {'status':'REVIEW_TEMPLATE_WRITTEN_ON_APPROVED_RUNNER','path':args.file}

def review_import(j,w,args):
    latest=j.latest_run()
    if not latest:raise ValueError('Collect metadata first')
    current={r['asset_key']:r for r in j.read('SNAPSHOT',latest['run_id'])}
    decisions={d['asset_key']:d for d in j.read('REVIEW',published=False)}
    actor=w.identity()['metadata_reader'];batch=[];seen=set()
    raw_bytes=Path(args.file).read_bytes();batch_id=digest([raw_bytes.hex(),actor])
    with open(args.file,encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):
            if not row.get('decision','').strip():continue
            key=row['asset_key'];current_row=current.get(key)
            if key in seen:raise ValueError('Duplicate assets in review file')
            seen.add(key)
            if not current_row or any(row[k]!=current_row[k] for k in ('input_hash','evidence_hash')):
                raise ValueError('Review file contains stale fingerprints')
            record_id=digest([batch_id,key])
            expected=row.get('expected_review_id','')
            actual=decisions.get(key,{}).get('_record_id','')
            if actual not in (expected,record_id):raise ValueError('A newer stewardship decision exists; refresh the template')
            decision=row['decision'].strip();text=row.get('sanitized_text','').strip()
            if decision not in ('APPROVED','DISPUTED','REJECTED') or not row.get('reason','').strip():raise ValueError('Decision and reason required')
            if decision=='APPROVED' and (row.get('label') not in PRIORITY or not row.get('logical_group') or not text):
                raise ValueError('Approval requires label, reviewed logical group and sanitized text')
            if len(text)>4000:raise ValueError('Sanitized text exceeds 4000 characters')
            batch.append((record_id,{'asset_key':key,'input_hash':row['input_hash'],'evidence_hash':row['evidence_hash'],
              'decision':decision,'label':row.get('label'),'logical_group':row.get('logical_group'),
              'sanitized_text':text,'reason':row['reason'],'reviewer':actor,'reviewed_at':now()}))
    j.append('review-import-'+batch_id,'REVIEW',batch)
    return {'status':'REVIEW_BATCH_RECORDED','rows':len(batch),'security_tags_changed':False}

class SingleWriter:
    """Cross-platform local process lock. Use one scheduled writer across hosts."""
    def __init__(self,path):self.path=Path(path)
    def __enter__(self):
        try:self.fd=os.open(self.path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        except FileExistsError:raise RuntimeError('Writer lock exists. Check the running process before removing a stale lock.')
        os.write(self.fd,str(os.getpid()).encode());return self
    def __exit__(self,*args):os.close(self.fd);self.path.unlink(missing_ok=True)

def main():
    p=argparse.ArgumentParser(description='Unified value classification, reconciliation and monitoring framework')
    p.add_argument('--config',default='config.toml')
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('install');r=sub.add_parser('run');r.add_argument('--run-id',default=None)
    sub.add_parser('serve')
    sub.add_parser('status')
    sub.add_parser('prepare-model-volume')
    q=sub.add_parser('models-stage');q.add_argument('--destination',required=True)
    q=sub.add_parser('models-check');q.add_argument('--smoke',action='store_true')
    q=sub.add_parser('evaluate-values');q.add_argument('--file',required=True);q.add_argument('--report',required=True)
    for command in ('review-export','review-import'):
        q=sub.add_parser(command);q.add_argument('--file',required=True)
    q=sub.add_parser('dashboard-queries');q.add_argument('--file',required=True)
    a=sub.add_parser('review')
    for key in ('asset','input-hash','evidence-hash','reason'):a.add_argument('--'+key,required=True)
    a.add_argument('--decision',choices=['APPROVED','DISPUTED','REJECTED'],required=True)
    a.add_argument('--label',choices=LABELS);a.add_argument('--group');a.add_argument('--text-file')
    m=sub.add_parser('approve-model');m.add_argument('--model-id',required=True);m.add_argument('--reason',required=True)
    args=p.parse_args();c=load_config(args.config)
    if args.command=='dashboard-queries':
        with open(args.file,'x',encoding='utf-8') as f:f.write(dashboard_queries(c))
        print('Dashboard SQL generated from the shared configuration: '+args.file)
        return 0
    if args.command in ('models-stage','models-check','evaluate-values'):
        try:
            from .assets import stage_models,verify_bundle,load_ensemble
            from .content_config import content_settings
            cs=content_settings(c)
            if args.command=='models-stage':out=stage_models(cs,args.destination,c.get('anomalies',{}))
            elif args.command=='models-check':
                manifest,bundle_id=verify_bundle(cs['model_directory'],cs)
                out={'status':'MODEL_FILES_VERIFIED','bundle_id':bundle_id,'models':manifest['models']}
                if args.smoke:
                    ensemble,bundle_id=load_ensemble(cs)
                    texts=['Synthetic contact: synthetic.person@example.com',
                           'Synthetic customer name: Jane Doe','Synthetic SSN: 123-45-6789',
                           'Claim amount: 1450.50; deductible: 500.']
                    results=ensemble.identify_many(texts)
                    expected=['EMAIL','PERSON','SSN',None]
                    checks=[]
                    for required,predictions in zip(expected,results):
                        detected={x['entity'] for x in predictions if x['consensus'] and x['entity'] in cs['entity_tiers']}
                        checks.append(required in detected if required else not detected)
                    if not all(checks):raise ValueError('SYNTHETIC_CLASSIFICATION_SMOKE_FAILED')
                    out.update(status='MODEL_RUNTIME_SMOKE_PASSED',synthetic_classification_checks=checks)
                    if c.get('anomalies',{}).get('enabled',False):
                        import numpy as np
                        from .anomalies import TabPFNScorer,calibrated_findings,settings as anomaly_settings
                        ac=anomaly_settings(c);rng=np.random.default_rng(17)
                        ref=rng.normal(size=(ac['reference_rows'],3));cal=rng.normal(size=(ac['calibration_rows'],3))
                        test=rng.normal(size=(ac['minimum_candidate_rows'],3));test[0]=[20,25,30]
                        scorer=TabPFNScorer(cs['model_directory'],cs['device'],ac['permutations'],ac['seed'])
                        found=calibrated_findings(ref,cal,test,scorer,ac)
                        if not any(x['candidate_index']==0 and x['evidence']=='TABPFN_AND_ROBUST' for x in found):
                            raise ValueError('SYNTHETIC_ANOMALY_SMOKE_FAILED')
                        out['synthetic_numeric_outlier_detected']=True
            else:
                from .quality import evaluate_file
                ensemble,bundle_id=load_ensemble(cs)
                out=evaluate_file(args.file,ensemble,cs,bundle_id,c.get('quality',{}))
                with open(args.report,'x',encoding='utf-8') as f:json.dump(out,f,indent=2)
            print(dumps(out));return 0 if out.get('quality_gate_passed',True) else 2
        except Exception as exc:
            known={'INVALID_MODEL_MANIFEST','MODEL_REVISION_MISMATCH','MODEL_FILE_OUTSIDE_BUNDLE_OR_MISSING',
                'MODEL_CHECKSUM_MISMATCH','MODEL_BUNDLE_HAS_UNTRACKED_FILES','SAFETENSORS_REQUIRED',
                'STAGING_DESTINATION_MUST_BE_EMPTY','STAGE_TABPFN_V2_CHECKPOINTS','SYNTHETIC_EMAIL_SMOKE_FAILED','SYNTHETIC_CLASSIFICATION_SMOKE_FAILED','SYNTHETIC_ANOMALY_SMOKE_FAILED',
                'HELD_OUT_TEST_GROUP_AND_ID_REQUIRED','INVALID_GOLD_SPAN','EMPTY_EVALUATION_DATASET'}
            detail=str(exc) if str(exc) in known else type(exc).__name__
            print('Model operation failed: '+detail+'. Check local model assets, dependencies and configuration. No customer values printed.',file=sys.stderr)
            return 1
    if not re.fullmatch(r'[0-9a-fA-F]{16,}',c['warehouse_id']):p.error('Set the existing warehouse ID in config.toml')
    w=Warehouse(c);w.preflight();j=Journal(w,c)
    if args.command=='prepare-model-volume':
        from .content_config import content_settings
        cs=content_settings(c)
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',cs['model_volume_name']):raise ValueError('Invalid model volume name')
        w.sql('CREATE SCHEMA IF NOT EXISTS '+qi(c['output_catalog'])+'.'+qi(c['output_schema']))
        w.sql('CREATE VOLUME IF NOT EXISTS '+fq(c['output_catalog']+'.'+c['output_schema']+'.'+cs['model_volume_name']))
        print(dumps({'status':'MODEL_VOLUME_READY','model_directory':cs['model_directory']}));return 0
    try:
        lock=Path(args.config).resolve().parent/('.ucf-'+digest([c['environment'],c['output_catalog'],c['output_schema'],c['table_prefix']])[:12]+'.lock')
        if args.command=='serve':
            with SingleWriter(lock):
                j.initialize();install_views(w,c);ensure_alerts(w,j,c)
            while True:
                started=time.monotonic()
                try:
                    with SingleWriter(lock):out=run(w,j,c,uuid.uuid4().hex)
                    print(dumps(out),flush=True)
                except Exception as exc:
                    print('Scheduled iteration failed: '+type(exc).__name__+'. Previous published run is retained.',file=sys.stderr,flush=True)
                deadline=started+c['monitor']['poll_minutes']*60
                while time.monotonic()<deadline:time.sleep(min(60,max(0,deadline-time.monotonic())))
        with SingleWriter(lock):
            j.initialize()
            if args.command in ('install','run'):install_views(w,c)
            if args.command=='install':out={'status':'INSTALLED','alerts':ensure_alerts(w,j,c),'schedule_collector_separately':True}
            elif args.command=='run':out=run(w,j,c,args.run_id or uuid.uuid4().hex)
            elif args.command=='review':out=review(j,w,c,args)
            elif args.command=='approve-model':out=approve_model(j,w,c,args)
            elif args.command=='review-export':out=review_export(j,args)
            elif args.command=='review-import':out=review_import(j,w,args)
            else:out=j.latest_run() or {'status':'NO_SUCCESSFUL_RUN'}
        print(dumps(out))
    except Exception as exc:
        statement_id=getattr(exc,'statement_id',None)
        safe_id=(' SQL statement '+statement_id) if statement_id and re.fullmatch(r'[A-Za-z0-9-]+',statement_id) else ''
        print('Framework stopped: '+type(exc).__name__+safe_id+'. Inspect the run in Databricks; sensitive exception text is not printed.',file=sys.stderr)
        from .notifications import EmailDestinationSetupError
        if isinstance(exc,EmailDestinationSetupError):
            print('Published core results, if any, are retained. A workspace administrator must configure the requested email destination; set notifications.destination_ids to its ID.',file=sys.stderr)
        return 1
    return 0

