"""Optional glossary reconciliation. Glossary terms are not sensitivity labels.

Only exact configured term-to-tier mappings yield comparable classifications.
No suffix-only or case-folded FQN joins which can merge different assets.
"""
import json
from collections import defaultdict
from .core import fq,PRIORITY

def collect(w,rows,c):
    cfg=c.get('collate',{})
    if not cfg.get('enabled',False):return {},{'status':'DISABLED'}
    mapping=cfg.get('term_tiers',{})
    if any(v not in PRIORITY for v in mapping.values()):raise ValueError('INVALID_COLLATE_TERM_POLICY')
    # Build the exact service.catalog.schema.table.column FQN in SQL using the
    # configured catalog-to-service binding. No business values are collected.
    services=cfg.get('service_by_catalog',{})
    if any(cat not in services for cat in c['source_catalogs']):raise ValueError('COLLATE_SERVICE_BINDING_REQUIRED')
    clauses=[]
    for cat in c['source_catalogs']:
        prefix=services[cat]+'.'+cat+'.'
        clauses.append("starts_with(field_fqn,'"+prefix.replace("'","''")+"')")
    limit=int(cfg.get('maximum_assignments',100000))
    if not 1<=limit<=1000000:raise ValueError('INVALID_COLLATE_BUDGET')
    # Confirmed current column assignments only; non-null deletion flags required.
    data=w.sql(f'''SELECT field_fqn,term_fqn,cast(last_seen_at AS STRING) AS last_seen_at
       FROM {fq(cfg['assignment_table'])}
       WHERE assignment_level='column' AND label_state='Confirmed'
       AND term_is_deleted=false AND asset_is_deleted=false
       AND ({' OR '.join(clauses)}) LIMIT {limit+1}''')
    if len(data)>limit:raise ValueError('COLLATE_ASSIGNMENT_BUDGET_EXCEEDED')
    from datetime import datetime,timezone,timedelta
    cutoff=datetime.now(timezone.utc)-timedelta(hours=cfg.get('maximum_age_hours',48))
    lookup=defaultdict(list)
    for assignment in data:lookup[assignment['field_fqn']].append(assignment)
    result={};matches=0;fresh=0
    for row in rows:
        fqn=services[row['catalog_name']]+'.'+'.'.join(row[k] for k in ('catalog_name','schema_name','table_name','column_name'))
        candidates=lookup.get(fqn,[])
        labels=set();current=0
        for a in candidates:
            value=a.get('last_seen_at')
            try:stamp=datetime.fromisoformat(value.replace('Z','+00:00')).replace(tzinfo=timezone.utc) if '+' not in value and not value.endswith('Z') else datetime.fromisoformat(value.replace('Z','+00:00'))
            except (ValueError,TypeError,AttributeError):continue
            if stamp<cutoff:continue
            current+=1
            if a['term_fqn'] in mapping:labels.add(mapping[a['term_fqn']])
        if candidates:matches+=1
        if current:fresh+=1
        result[row['asset_key']]={'status':'CURRENT_ASSIGNMENT' if current else 'STALE_ASSIGNMENT' if candidates else 'NO_MATCHING_ASSIGNMENT',
            'assignment_count':len(candidates),'classifications':sorted(labels,key=PRIORITY.get),
            'latest_observation':max((a['last_seen_at'] for a in candidates if a.get('last_seen_at')),default=None)}
    return result,{'status':'CURRENT_RAW_ASSIGNMENTS' if fresh else 'NO_CURRENT_RAW_ASSIGNMENTS',
        'raw_assignment_rows':len(data),'matched_columns':matches,'fresh_columns':fresh,
        'mapped_terms':len(mapping),'scope':'EXACT_CONFIGURED_SERVICE_AND_CATALOG'}
