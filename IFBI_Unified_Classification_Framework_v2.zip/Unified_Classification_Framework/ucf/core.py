from __future__ import annotations
import hashlib, json, re, tomllib
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

LABELS = ('Confidential Critical','Confidential Restricted','Confidential Sensitive','Internal Use Only')
PRIORITY = {s:i+1 for i,s in enumerate(LABELS)}
VERSION = '1.0.0'
# Preserve the v1 metadata-baseline format across the v2 additive upgrade.
RELEASE_VERSION = '2.0.0'
def now(): return datetime.now(timezone.utc).isoformat()
def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()
def dumps(value): return json.dumps(value,sort_keys=True,separators=(',',':'),default=str,allow_nan=False)
def qi(value): return '`'+value.replace('`','``')+'`'
def fq(value):
    parts=value.split('.')
    if len(parts)!=3 or any(not p for p in parts): raise ValueError('Use catalog.schema.object')
    return '.'.join(map(qi,parts))
def load_config(path):
    with open(path,'rb') as f: c=tomllib.load(f)
    required=('environment','source_catalogs','output_catalog','output_schema','table_prefix','warehouse_id')
    if any(not c.get(k) for k in required): raise ValueError('Missing required configuration')
    if not re.fullmatch(r'[A-Za-z0-9_]+',c['environment']): raise ValueError('Invalid environment')
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',c['table_prefix']): raise ValueError('Invalid table prefix')
    if not 1<=c['maximum_columns']<=100000: raise ValueError('Column budget must be 1..100000')
    if not 0<=c['maximum_inventory_drop_fraction']<=.5: raise ValueError('Invalid inventory drop guard')
    if len(set(c['source_catalogs']))!=len(c['source_catalogs']): raise ValueError('Duplicate source catalog')
    if c['mapping']['table']: fq(c['mapping']['table'])
    if 'ifbi_sensitivity' in c['mapping']['signal_tags']: raise ValueError('Target label cannot also be a source feature')
    if c['monitor']['poll_minutes'] not in (15,30,60): raise ValueError('Poll minutes must be 15, 30 or 60')
    for k in ('per_label','missing','per_issue'):
        if not 1<=c['review'][k]<=500: raise ValueError('Review budget must be 1..500')
    for k in ('minimum_queue_precision','minimum_queue_coverage','minimum_critical_recall'):
        if not 0<c['ml'][k]<=1:raise ValueError('Model gate thresholds must be in (0,1]')
    if not 1<=c['ml']['maximum_model_age_days']<=365:raise ValueError('Model approval expiry must be 1..365 days')
    for k in ('minimum_train_per_class','minimum_calibration_per_class','minimum_test_per_class'):
        if not 1<=c['ml'][k]<=10000:raise ValueError('Invalid model support requirement')
    for v in c['notifications']['emails']:
        if not re.fullmatch(r'[^\s<>@]+@[^\s<>@]+\.[^\s<>@]+',v): raise ValueError('Invalid notification email')
    if c['notifications'].get('delivery_mode','workspace_user') not in ('workspace_user','managed_email_destination'):
        raise ValueError('Invalid notification delivery mode')
    if c.get('content',{}).get('enabled',False):
        from .content_config import content_settings
        from .anomalies import settings as anomaly_settings
        content_settings(c);anomaly_settings(c)
    if c['notifications']['enabled'] and not (c['notifications']['emails'] or c['notifications'].get('destination_ids')):
        raise ValueError('Configure a notification recipient or destination')
    return c
def scope_hash(c):
    return digest({k:c[k] for k in ('environment','source_catalogs','excluded_schemas','output_catalog','output_schema','include_descriptions')} | {'mapping':c['mapping'],'version':VERSION})
def table(c,name): return fq(c['output_catalog']+'.'+c['output_schema']+'.'+c['table_prefix']+'_'+name)
def redacted_text(text):
    # Basic minimization, NOT a guarantee of PII absence. No descriptions by default.
    text=re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', ' [EMAIL] ',text)
    text=re.sub(r'\b\d{5,}\b',' [NUMBER] ',text)
    text=re.sub(r'(?i)(password|secret|token)\s*[:=]\s*\S+',r'\1 [REDACTED]',text)
    return re.sub(r'\s+',' ',text).strip()[:4000]
def decorate(raw):
    row=dict(raw)
    vals=raw.get('sensitivity_values') or []
    if isinstance(vals,str): vals=json.loads(vals)
    vals=sorted(set(vals));row['sensitivity_values']=vals
    signals=raw.get('signals') or []
    if isinstance(signals,str): signals=json.loads(signals)
    row['signals']=sorted(signals,key=lambda s:(s['tag_name'],s['tag_value']))
    n=len(vals)
    row['sensitivity_state']=('Missing sensitivity tag' if n==0 else 'Conflicting sensitivity values' if n>1 else
        'Recognized sensitivity value' if vals[0] in PRIORITY else 'Explicit Unclassified' if vals[0]=='Unclassified' else 'Value outside configured taxonomy')
    row['current_sensitivity']=vals[0] if n==1 else None
    row['actual_priority']=PRIORITY.get(row['current_sensitivity'])
    row['asset_key']=digest([row[k] for k in ('catalog_name','schema_name','table_name','column_name')])
    row['table_key']=digest([row[k] for k in ('catalog_name','schema_name','table_name')])
    row['input_hash']=digest([row[k] for k in ('catalog_name','schema_name','table_name','column_name','data_type','description')])
    row['evidence_hash']=digest([row['sensitivity_values'],row['signals']])
    row['is_connector_metadata']=row['column_name'].startswith('_fivetran_')
    row['feature_text']=redacted_text(' '.join(str(row.get(k) or '') for k in ('column_name','table_name','data_type','description')))
    return row
def mapped_requirement(row,rules,signal_tags):
    signals={(s['tag_name'],s['tag_value']) for s in row['signals'] if s['tag_name'] in signal_tags}
    matched=[r for r in rules if (r.get('source_tag_name'),r.get('source_tag_value')) in signals]
    bad=0
    pairs=defaultdict(set)
    for r in matched:
        pairs[(r['source_tag_name'],r['source_tag_value'])].add(r.get('ifbi_classification'))
        if r.get('ifbi_classification') not in PRIORITY: bad+=1
        elif int(r.get('tier_priority') or 0)!=PRIORITY[r['ifbi_classification']]: bad+=1
    bad+=sum(len(v)>1 for v in pairs.values())
    valid=[r['ifbi_classification'] for r in matched if r.get('ifbi_classification') in PRIORITY]
    label=min(valid,key=PRIORITY.get) if valid and not bad else None
    return label,bad
def review_sample(rows,c):
    groups=defaultdict(lambda:defaultdict(list))
    for r in rows:
        if r['is_connector_metadata']: continue
        bucket='LABEL: '+r['current_sensitivity'] if r['actual_priority'] else 'ISSUE: '+r['sensitivity_state']
        groups[bucket][r['table_key']].append(r)
    result=[]
    for bucket,tables in sorted(groups.items()):
        picks=[]
        for group in tables.values():
            for rank,r in enumerate(sorted(group,key=lambda x:digest([x['asset_key'],c['seed']]))):
                picks.append((rank,digest([r['asset_key'],c['seed']]),r))
        limit=c['per_label'] if bucket.startswith('LABEL:') else c['missing'] if bucket=='ISSUE: Missing sensitivity tag' else c['per_issue']
        result.extend(dict(r,review_bucket=bucket) for _,_,r in sorted(picks,key=lambda x:x[:2])[:limit])
    return result
def accepted_gold(rows,reviews):
    current={r['asset_key']:r for r in rows}
    # Caller provides review records in chronological order; newest decision wins.
    latest={r['asset_key']:r for r in reviews}
    gold=[]
    for key,d in latest.items():
        r=current.get(key)
        if not r or d.get('decision')!='APPROVED' or d.get('label') not in PRIORITY: continue
        if d['input_hash']!=r['input_hash'] or d['evidence_hash']!=r['evidence_hash']: continue
        if not all(d.get(k) for k in ('reviewer','reason','logical_group','sanitized_text')): continue
        gold.append(dict(d,text=d['sanitized_text']))
    # Identical sanitized input must not have conflicting labels or cross splits.
    by_text=defaultdict(list)
    for d in gold: by_text[digest(d['text'])].append(d)
    parent={d['logical_group']:d['logical_group'] for d in gold}
    def root(g):
        while parent[g]!=g:
            parent[g]=parent[parent[g]];g=parent[g]
        return g
    for same in by_text.values():
        if len({d['label'] for d in same})>1: raise ValueError('Conflicting reviewed labels for identical model input')
        roots=sorted({root(d['logical_group']) for d in same})
        for g in roots: parent[g]=roots[0]
    for d in gold: d['logical_group']=root(d['logical_group'])
    return gold


