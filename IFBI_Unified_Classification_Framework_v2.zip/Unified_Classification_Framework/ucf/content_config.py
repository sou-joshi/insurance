"""Validated defaults for v2 value inference; no hidden training requirement."""
from copy import deepcopy
from .value_models import ENTITIES
from .core import PRIORITY

DEFAULTS={
 'enabled':False, 'model_directory':'', 'model_volume_name':'classification_models', 'device':'cpu',
 'rows_per_table':256,'maximum_tables_per_run':30,'maximum_columns_per_run':1000,
 'maximum_columns_per_query':40,'maximum_value_chars':4096,'maximum_values_per_column':64,
 'refresh_hours':24,'maximum_run_seconds':1800,'chunk_chars':256,'chunk_overlap':64,
 'minimum_model_score':.80,'minimum_models':2,'minimum_nonempty_values':10,
 'minimum_matching_values':3,'minimum_match_fraction':.02,
 'drift_fraction':.20,'sample_strategy':'RESERVOIR',
 'require_delta_snapshot':True,
 'policy_approved':False,'policy_version':'IFBI_DRAFT_ENTITY_MAPPING_V1',
 'entity_tiers':{
 'SSN':'Confidential Critical','BANK_ACCOUNT':'Confidential Critical','CREDIT_CARD':'Confidential Critical',
 'PERSON':'Confidential Restricted','ADDRESS':'Confidential Restricted','EMAIL':'Confidential Restricted',
 'PHONE':'Confidential Restricted','DATE_OF_BIRTH':'Confidential Restricted','DRIVER_LICENSE':'Confidential Restricted',
 'POLICY_ID':'Confidential Restricted','CLAIM_ID':'Confidential Restricted','VIN':'Confidential Restricted',
 'MEDICAL_RECORD':'Confidential Critical','MEDICAL_CONDITION':'Confidential Restricted'},
 'models':[
 {'name':'nvidia_pii','repo':'nvidia/gliner-PII','revision':'bd2a1727f5baa9b135bf9b994cc463f3224b44a0',
  'kind':'gliner','threshold':.65,'enabled':True},
 {'name':'bert_ner','repo':'dslim/bert-base-NER','revision':'d1a3e8f13f8c3566299d95fcfc9a8d2382a9affc',
  'kind':'bert','threshold':.80,'enabled':True},
 {'name':'gliner_general','repo':'urchade/gliner_medium-v2.1','revision':'40ec419335d09393f298636f471328b722c6da9e',
  'kind':'gliner','threshold':.65,'enabled':True}],
}

def content_settings(c):
    settings=deepcopy(DEFAULTS)
    settings.update(c.get('content',{}))
    if not settings['model_directory']:
        settings['model_directory']=f"/Volumes/{c['output_catalog']}/{c['output_schema']}/{settings['model_volume_name']}/ucf_v2"
    for key,low,high in [('rows_per_table',16,10000),('maximum_tables_per_run',1,1000),
       ('maximum_columns_per_run',1,50000),('maximum_columns_per_query',1,100),
       ('maximum_value_chars',256,65536),('maximum_values_per_column',1,10000),
       ('refresh_hours',1,720),('maximum_run_seconds',30,14400),('chunk_chars',64,256),
       ('minimum_models',1,10),('minimum_nonempty_values',1,10000),('minimum_matching_values',1,10000)]:
        if type(settings[key]) is not int or not low<=settings[key]<=high:raise ValueError('Invalid content setting: '+key)
    if not 0<=settings['chunk_overlap']<settings['chunk_chars']:raise ValueError('Invalid content chunk overlap')
    for key in ('minimum_model_score','minimum_match_fraction','drift_fraction'):
        if not 0<float(settings[key])<=1:raise ValueError('Invalid content threshold: '+key)
    if settings['sample_strategy'] not in ('RESERVOIR','PREFIX'):raise ValueError('Invalid sample strategy')
    if settings['device']!='cpu' and not str(settings['device']).startswith('cuda'):raise ValueError('Unsupported model device')
    if any(entity not in ENTITIES or tier not in PRIORITY for entity,tier in settings['entity_tiers'].items()):
        raise ValueError('Invalid entity-to-tier policy')
    if not settings['policy_version']:raise ValueError('Entity policy version required')
    enabled=[m for m in settings['models'] if m.get('enabled',True)]
    if settings['enabled'] and len(enabled)<2:raise ValueError('Value ensemble requires at least two pretrained models')
    if len({m['name'] for m in enabled})!=len(enabled):raise ValueError('Duplicate model names')
    for m in enabled:
        if m['kind'] not in ('gliner','bert') or not .01<=m['threshold']<=1:raise ValueError('Invalid model definition')
    return settings
