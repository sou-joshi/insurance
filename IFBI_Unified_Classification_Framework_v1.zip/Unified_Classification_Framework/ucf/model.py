"""Reviewed metadata baseline. JSON artifacts only; never deserializes pickle."""
from __future__ import annotations
from collections import Counter
import json
from .core import LABELS, PRIORITY, VERSION, digest, dumps, now

def split_group(group,seed):
    n=int(digest([seed,group])[:8],16)%100
    return 'TRAIN' if n<60 else 'CALIBRATION' if n<80 else 'TEST'
def dataset_signature(gold,c):
    return digest({'rows':sorted((d['asset_key'],d['input_hash'],d['evidence_hash'],d['label'],d['text'],d['logical_group']) for d in gold),
                   'settings':c,'version':VERSION})
def restore(artifact):
    import sklearn, numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    if artifact.get('format')!='UCF_TFIDF_LR_JSON_V1' or artifact.get('model_id')!=digest({k:v for k,v in artifact.items() if k!='model_id'}):
        raise ValueError('Model artifact identity or checksum differs')
    if set(artifact.get('classes',[]))!=set(LABELS):raise ValueError('Unexpected model label catalog')
    if artifact['sklearn_version']!=sklearn.__version__: raise ValueError('Model/runtime version mismatch; use the pinned environment')
    vocabulary=artifact['vocabulary']
    if len(vocabulary)>100000 or sorted(vocabulary.values())!=list(range(len(vocabulary))): raise ValueError('Invalid vocabulary')
    v=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,vocabulary=vocabulary)
    v.fit(['placeholder'])
    v.idf_=np.array(artifact['idf'],dtype=float)
    m=LogisticRegression(class_weight='balanced',max_iter=1000,random_state=42)
    m.classes_=np.array(artifact['classes']);m.coef_=np.array(artifact['coef'],dtype=float)
    m.intercept_=np.array(artifact['intercept'],dtype=float);m.n_features_in_=len(vocabulary);m.n_iter_=np.array([1])
    if m.coef_.shape!=(len(LABELS),len(vocabulary)) or len(v.idf_)!=len(vocabulary): raise ValueError('Invalid artifact dimensions')
    if not np.isfinite(m.coef_).all() or not np.isfinite(v.idf_).all(): raise ValueError('Non-finite model artifact')
    return v,m
def train(gold,c):
    import sklearn, numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import classification_report, recall_score
    partitions={part:[d for d in gold if split_group(d['logical_group'],c['seed'])==part]
                for part in ('TRAIN','CALIBRATION','TEST')}
    support={part:dict(Counter(d['label'] for d in rows)) for part,rows in partitions.items()}
    for part,setting in [('TRAIN','minimum_train_per_class'),('CALIBRATION','minimum_calibration_per_class'),('TEST','minimum_test_per_class')]:
        if any(support[part].get(label,0)<c[setting] for label in LABELS):
            return None,{'status':'WAITING_FOR_REVIEWED_CLASS_AND_GROUP_SUPPORT','support':support}
    # No test examples or calibration examples are used in vectorizer fitting.
    train_rows=partitions['TRAIN'];cal=partitions['CALIBRATION'];test=partitions['TEST']
    v=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,max_features=c['max_features'])
    x=v.fit_transform([d['text'] for d in train_rows])
    m=LogisticRegression(class_weight='balanced',max_iter=1000,random_state=42).fit(x,[d['label'] for d in train_rows])
    cal_prob=m.predict_proba(v.transform([d['text'] for d in cal]));cal_pred=m.classes_[cal_prob.argmax(axis=1)]
    # Select thresholds only on calibration groups; these scores remain uncalibrated.
    choices=[]
    for threshold in (.50,.60,.70,.80,.90,.95):
        for margin in (.10,.20,.30):
            ordered=np.sort(cal_prob,axis=1)
            mask=(ordered[:,-1]>=threshold)&((ordered[:,-1]-ordered[:,-2])>=margin)
            coverage=float(mask.mean())
            precision=float(np.mean(cal_pred[mask]==np.array([d['label'] for d in cal])[mask])) if mask.any() else 0.
            if precision>=c['minimum_queue_precision'] and coverage>=c['minimum_queue_coverage']:
                choices.append((coverage,precision,threshold,margin))
    threshold,margin=(max(choices)[2:] if choices else (1.01,1.01))
    test_prob=m.predict_proba(v.transform([d['text'] for d in test]));pred=m.classes_[test_prob.argmax(axis=1)]
    truth=np.array([d['label'] for d in test]);scores=np.sort(test_prob,axis=1)
    selected=(scores[:,-1]>=threshold)&((scores[:,-1]-scores[:,-2])>=margin)
    coverage=float(selected.mean());precision=float(np.mean(pred[selected]==truth[selected])) if selected.any() else 0.
    report=classification_report(truth,pred,labels=list(LABELS),output_dict=True,zero_division=0)
    # Abstention on a Critical example is counted as a miss for usable recall.
    critical=(truth==LABELS[0]);usable_critical=float(np.mean(selected[critical] & (pred[critical]==LABELS[0])))
    severe=sum(PRIORITY[p]>PRIORITY[t] for p,t in zip(pred,truth))
    metrics={'status':'CANDIDATE_EVALUATED','support':support,'per_class':report,
      'test_queue_precision':precision,'test_queue_coverage':coverage,'test_abstention':1-coverage,
      'test_usable_critical_recall':usable_critical,'test_weaker_tier_predictions':int(severe),
      'test_rows':len(test),'calibration_rows':len(cal),'training_rows':len(train_rows),
      'score_interpretation':'UNCALIBRATED_MODEL_SCORE','threshold':float(threshold),'margin':float(margin),
      'quality_gate_passed':bool(choices and precision>=c['minimum_queue_precision'] and coverage>=c['minimum_queue_coverage'] and usable_critical>=c['minimum_critical_recall'])}
    artifact={'format':'UCF_TFIDF_LR_JSON_V1','sklearn_version':sklearn.__version__,
      'vocabulary':v.vocabulary_,'idf':v.idf_.tolist(),'classes':m.classes_.tolist(),
      'coef':m.coef_.tolist(),'intercept':m.intercept_.tolist(),
      'threshold':float(threshold),'margin':float(margin),'metrics':metrics,
      'dataset_signature':dataset_signature(gold,c),'created_at':now()}
    artifact['training_manifest']=[{'asset_key':d['asset_key'],'input_hash':d['input_hash'],
       'evidence_hash':d['evidence_hash'],'review_record_id':d.get('_record_id'),
       'logical_group':d['logical_group'],'split':split_group(d['logical_group'],c['seed'])} for d in gold]
    # numpy integer vocabulary indexes need standard ints for portable JSON.
    artifact['vocabulary']={k:int(value) for k,value in artifact['vocabulary'].items()}
    artifact['model_id']=digest(artifact)
    if len(dumps(artifact).encode())>c['maximum_model_bytes']: raise ValueError('Model artifact exceeds budget')
    return artifact,metrics
def predict(artifact,texts):
    v,m=restore(artifact);x=v.transform(texts);p=m.predict_proba(x)
    names=v.get_feature_names_out();result=[]
    for i,scores in enumerate(p):
        ranks=scores.argsort()[::-1];a,b=int(ranks[0]),int(ranks[1]);score=float(scores[a]);gap=score-float(scores[b])
        accept=score>=artifact['threshold'] and gap>=artifact['margin'] and x[i].nnz>0
        # Local feature contributions explain a ranking, not causal truth.
        row=x[i];contributions=sorted(((float(value*m.coef_[a,index]),str(names[index]))
                    for index,value in zip(row.indices,row.data)),reverse=True)[:5]
        result.append({'model_label':str(m.classes_[a]),'model_score':score,'score_margin':gap,
          'abstained':not accept,'top_candidates':[{'label':str(m.classes_[j]),'score':float(scores[j])} for j in ranks[:3]],
          'reason_features':[name for value,name in contributions if value>0],
          'score_interpretation':'UNCALIBRATED_MODEL_SCORE'})
    return result

