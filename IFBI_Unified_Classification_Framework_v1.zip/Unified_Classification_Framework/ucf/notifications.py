"""Native Databricks alerts; receipts attest evaluation, not email delivery."""
import time
from .core import digest,table,now

def alert_definitions(c):
    key=digest([c['environment'],c['output_catalog'],c['output_schema'],c['table_prefix']])[:12]
    prefix='/* UCF:'+key+' */\n'
    interval=c['monitor']['poll_minutes']
    cron='0 7 * * * ?' if interval==60 else f'0 7/{interval} * * * ?'
    base={'warehouse_id':c['warehouse_id'],'custom_template_format':'MARKDOWN',
      'custom_description':'Classification framework notification. Counts are metadata findings, not confirmed PII exposures.\n\n@QUERY_RESULT_TABLE\n\n@ALERT_URL'}
    result={}
    for kind,column,query in [
      ('changes','notice_count',f'''SELECT priority,kind,finding_type,owner,catalog_name,schema_name,table_name,
        COUNT(*) AS notice_count FROM {table(c,'pending_notices')}
        GROUP BY priority,kind,finding_type,owner,catalog_name,schema_name,table_name
        UNION ALL SELECT 'P3','NONE','NO_PENDING_NOTICES','','','','',0
        WHERE NOT EXISTS(SELECT 1 FROM {table(c,'pending_notices')})'''),
      ('health','attention_required',f'SELECT * FROM {table(c,"health")}')]:
        definition=dict(base,display_name=f'Classification Framework {kind} - {c["environment"]} {key}',query_text=prefix+query,
          evaluation={'source':{'name':column,'aggregation':'MAX'},'comparison_operator':'GREATER_THAN',
            'threshold':{'value':{'double_value':0}},'empty_result_state':'ERROR',
            'notification':{'subscriptions':[{'user_email':s} for s in c['notifications']['emails']],
                            'retrigger_seconds':1 if kind=='changes' else 86400,'notify_on_ok':kind=='health'}},
          schedule={'quartz_cron_schedule':cron,'timezone_id':c['notifications']['timezone'],
                    'pause_status':'PAUSED' if kind=='changes' else 'UNPAUSED'})
        result[kind]=definition
    return result

def ensure_alerts(w,j,c):
    if not c['notifications']['enabled']: return {}
    api=w.client.api_client;resources={}
    definitions=alert_definitions(c)
    token=None;found=[]
    while True:
        q={'page_size':100}
        if token:q['page_token']=token
        response=api.do('GET','/api/2.0/alerts',query=q);found.extend(response.get('alerts',[]))
        token=response.get('next_page_token')
        if not token:break
    for kind,body in definitions.items():
        matches=[a for a in found if a.get('display_name')==body['display_name']]
        if len(matches)>1: raise RuntimeError('Duplicate managed alert names; inspect before retrying')
        if matches:
            alert_id=matches[0]['id'];old=api.do('GET','/api/2.0/alerts/'+alert_id)
            if not old.get('query_text','').startswith(body['query_text'].split('\n')[0]):
                raise RuntimeError('Alert ownership marker differs')
            api.do('PATCH','/api/2.0/alerts/'+alert_id,query={'update_mask':','.join(body)},body=body)
        else:
            # Do not blindly retry an uncertain create: the next invocation finds
            # the deterministic name. Never updates an unrelated existing alert.
            alert_id=api.do('POST','/api/2.0/alerts',body=body)['id']
        resources[kind]=alert_id
    j.append('resources-'+digest(resources),'RESOURCE',[('native_alerts',dict(resources,recorded_at=now()))])
    return resources

def evaluate_alert(w,j,c,resources,notices):
    selected=[n for n in notices if n.get('selected_for_batch')]
    if not c['notifications']['enabled'] or not selected:return 'DISABLED' if not c['notifications']['enabled'] else 'NO_NOTICES'
    api=w.client.api_client
    notice_ids=sorted(n['notice_id'] for n in selected)
    token=digest([resources['changes'],notice_ids])
    response=api.do('POST','/api/2.2/jobs/runs/submit',body={
      'run_name':'Classification notification '+c['environment'], 'idempotency_token':token,
      'tasks':[{'task_key':'evaluate_alert','timeout_seconds':900,
                'alert_task':{'alert_id':resources['changes'],'warehouse_id':c['warehouse_id']}}]})
    run_id=response['run_id'];start=time.monotonic()
    while True:
        response=api.do('GET','/api/2.2/jobs/runs/get',query={'run_id':run_id})
        state=response.get('state',{})
        if state.get('life_cycle_state') in ('TERMINATED','SKIPPED','INTERNAL_ERROR'):
            if state.get('result_state')!='SUCCESS':raise RuntimeError('Native alert evaluation job failed; notices remain pending')
            break
        if time.monotonic()-start>1200:raise TimeoutError('Alert evaluation status unknown; notices remain pending')
        time.sleep(2)
    # Same token reuses the same submitted job after uncertain HTTP outcomes.
    records=[(n['notice_id'],{'notice_id':n['notice_id'],'accepted_at':now(),
        'meaning':'NATIVE_ALERT_EVALUATION_SUCCEEDED_NOT_DELIVERY_ATTESTATION','job_run_id':str(run_id)}) for n in selected]
    j.append('ack-'+token,'ACK',records)
    return 'EVALUATION_SUCCEEDED_DELIVERY_NOT_ATTESTED'

