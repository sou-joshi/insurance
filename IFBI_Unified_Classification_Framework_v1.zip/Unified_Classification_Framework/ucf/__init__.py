"""Metadata-only classification assistance; never writes security tags."""
__version__ = '1.0.0'

