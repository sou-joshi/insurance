# Unified Classification and Monitoring Framework

Version 1.0.0 · 19 November 2026 · metadata-only implementation

One configuration, one entry point and one run history connect all four stages:

| Stage | Implemented behavior |
|---|---|
| Collect | Read Unity Catalog column metadata and tag evidence once per iteration; capture source identity, input/evidence fingerprints and source mapping rules. |
| Learn | Build a bounded review queue; accept reviewed labels; train a TF-IDF/logistic classifier only when the reviewed dataset/settings change; evaluate on separate logical source groups. |
| Recommend | Reuse an approved model for unchanged inputs; score changed inputs in a batch; reconcile exact source mappings with model rankings; abstain on weak/conflicting evidence; preserve review decisions. |
| Monitor | Maintain a baseline, grace periods, tag-loss/downgrade findings, reminders and recoveries; submit grouped native alert evaluations; retain receipts; run an independent native health alert. |

This framework replaces the separate Story 3 preparation workflow for new runs. **Do not keep running the earlier preparation script as another collector.** Its tables and the existing dashboard/Step 2 monitor are left intact. This package creates only its own `ucf_*` objects and its own explicitly named alerts. Existing review rows are not automatically treated as approved gold labels.

## Important execution boundary

The SQL warehouse executes all source queries and Delta writes. An approved **Python 3.11+ runner** executes orchestration and the metadata model. It can be an existing IFBI-controlled VM, agent or VDI with approved Python; **Spark and a new serverless cluster are not required**. Use approved internal package distribution/offline wheels if internet package installation is restricted.

**A notebook attached only to a SQL warehouse cannot execute the Python ML stages.** Do not import the ZIP as a notebook and expect training to run there. The SQL warehouse alone is insufficient for this complete supervised framework. The package is ready for a platform-approved Python runner; no such runtime, schedule or connection has been provisioned by this delivery.

All metadata sent through the SQL API goes only between that runner and the authenticated Databricks workspace. Keep the runner inside IFBI's approved processing boundary. Do not run it on a personal computer or send review datasets/model vocabularies to ChatGPT. Metadata and model artifacts can contain sensitive information even though business values are never selected.

## Start here

1. Extract this package on the approved runner. Open **`config.toml`**.
2. Set `warehouse_id` to the existing non-serverless Pro warehouse ID. Find it in **SQL Warehouses → your warehouse → Connection details**; it is the final portion of the HTTP path `/sql/1.0/warehouses/<id>`. Keep the current DEV catalogs/schema unless intentionally changing environment.
3. Configure approved Databricks SDK unified authentication. Prefer an environment-specific workload identity with OAuth for unattended operation. Credentials belong in approved secrets/environment/profile configuration, never in TOML. The collector needs stable metadata visibility across runs.
4. Install the pinned packages in an isolated, approved Python environment:

```shell
python -m pip install -r requirements.txt
```

5. Run one complete iteration:

```shell
python run_framework.py run
```

The first invocation installs the owned journal/views and then collects, prepares reviews, attempts training if labels are ready, generates recommendations, publishes the run and configures/evaluates native notifications. A missing reviewed dataset produces a readiness status, not a fabricated model. No active model means exact mapping suggestions and abstention, rather than guessed probabilities.

6. For continuous operation under the host's approved service/process manager:

```shell
python run_framework.py serve
```

`serve` runs every `monitor.poll_minutes` and permits only one iteration at a time. Alternatively schedule the `run` command in the existing enterprise scheduler or Windows Task Scheduler at that frequency. Use **one scheduled writer total** for each environment/output prefix. Never run `serve` and a second scheduled `run` simultaneously. The local lock is cross-platform but is not a distributed lock across hosts. The service/process manager must restart a failed process and capture exit status; the independent native health alert detects stale successful runs.

Notifications are configured for **C000926@infarmbureau.com**. That address must resolve to an active workspace user or be replaced by an approved subscriber. Two new native alerts are managed: changes (independent schedule paused; evaluated by the pipeline) and health (independent schedule enabled). Databricks alert-task support and its Jobs API permissions are prerequisites; the current vendor API marks alert tasks Public Preview. Unsupported capabilities cause an explicit failed evaluation and leave notices pending. Do not substitute legacy API paths or import alert JSON through Import Notebooks.

## What happens on the first run

- One stable metadata scope is captured; the earlier 7,847/507 counts are not hardcoded.
- Columns with multiple sensitivity values retain the conflict. Missing values remain missing.
- `_fivetran_*` columns stay in inventory but are excluded from business review/model suggestions; this is not an automatic Internal label.
- Existing initial findings remain baseline backlog. One activation notice summarizes initialization; the framework does not open 7,340 column incidents.
- The review queue samples up to 50 per observed valid tier, 100 missing-label columns and 50 per issue bucket, rotating across tables. Up to 50 model/rule disagreements supplement that queue. Counts depend on actual available evidence.
- If no reviewed labels exist, `model_stage.status` is `WAITING_FOR_REVIEWED_CLASS_AND_GROUP_SUPPORT`. All non-rule model suggestions abstain.
- A successful native evaluation is acknowledged; **email delivery/read is not attested by that receipt**. Validate the first actual received notification before operational acceptance.

## Steward loop: review a sample, not the entire backlog

Run the following on the same approved host. These CSVs contain metadata and must remain within the approved boundary.

```shell
python run_framework.py review-export --file review_round1.csv
```

The export refuses to overwrite an existing file. Reviewers fill these fields:

| Field | Required meaning |
|---|---|
| `decision` | APPROVED, DISPUTED or REJECTED. A blank row is ignored. |
| `label` | For APPROVED: one of the four current IFBI sensitivity labels. |
| `logical_group` | Reviewed original source-table/lineage family. Replicated environments, renamed copies and related source tables belong together. Do not enter a random per-column ID. |
| `reason` | Why the decision is justified; no business values or secrets. |
| `sanitized_text` | Reviewed metadata suitable for the model. Prefilled basic redaction does not itself constitute approval. |

Do not edit asset keys, fingerprints or `expected_review_id`. The current label is evidence, not automatic truth. Dispute ambiguous cases; do not force them into Internal Use Only.

```shell
python run_framework.py review-import --file review_round1.csv
```

The import validates current metadata/evidence fingerprints and conflicting newer decisions before writing. It records the authenticated reviewer; it does not modify source tags. Re-importing the same file is idempotent. Use a separately authorized steward identity for review actions, with the same TOML and an approved SDK profile/environment. Do not give ordinary dashboard users journal-write access.

The next pipeline iteration reads the approved gold pool, groups identical text and source families together, and trains only if its signature changed. Manual review is a bootstrap and ongoing audit step. Existing tags, rule rows and model predictions never approve themselves.

## Model evaluation and activation

The implemented baseline is character TF-IDF plus class-balanced logistic regression; no internet model weights, LLM, embeddings or external inference endpoint are used. The default metadata excludes descriptions. Exact rule evidence uses configured source tags (`auto_class` by default); it does not use `ifbi_sensitivity` as an input feature.

Groups receive a deterministic 60/20/20 training/calibration/test assignment. These percentages apply to groups, not exact row counts. Preprocessing fits training rows only. Every tier needs the configured minimum support in all three partitions. The framework waits if support is insufficient; it does not search random seeds until a favorable evaluation appears. Review source families properly: software cannot infer every replica relationship from names.

The calibration partition selects score/margin thresholds; the untouched test partition reports per-class precision/recall, weaker-tier predictions, abstention and selected-queue precision/coverage. Critical usable recall counts abstentions as misses. Reported scores are **uncalibrated model scores**, not established probabilities of correctness. Configured quality targets are proposed gates, not achieved IFBI results.

Candidates that pass the gates still need explicit human activation:

```shell
python run_framework.py approve-model --model-id MODEL_ID_FROM_STATUS --reason "Reviewed grouped evaluation and intended advisory scope"
```

Activation is only for recommendations and expires after the configured period. It refuses an outdated gold-set/settings signature. The next scheduled run uses that model. Training is not repeated for every column or every polling interval; unchanged recommendation signatures are reused. A single batch transformation scores dirty columns. JSON artifacts contain vocabulary, IDF and coefficients with exact scikit-learn version checks; pickle is never loaded.

If a review conflict, invalid artifact or dependency problem occurs, metadata collection and deterministic monitoring continue in a degraded mode and the health view flags `ML_STAGE_ERROR`. Nothing silently counts as a model pass.

## Dashboard and operational outputs

The installer creates these views in the configured output schema:

| View | Use |
|---|---|
| `ucf_current_inventory` | Current visible scope, types, labels and input/evidence fingerprints. |
| `ucf_review_queue` | Current sampled candidates, actual review status and pending/stale reviews. |
| `ucf_recommendations` | Current model/rule recommendations, abstentions and disagreements. |
| `ucf_models` | Candidate model IDs and evaluation metrics JSON. |
| `ucf_incidents` | Stateful metadata change incidents and status. |
| `ucf_pending_notices` | Selected, unacknowledged grouped-notification inputs. |
| `ucf_runs` | Published run history, readiness, inference counts and monitoring summary. |
| `ucf_health` | Stale collection, failed attempts and ML-stage errors. |

Use these as datasets for an ML/operations page in the working dashboard. Generate the dataset SQL from the same environment configuration:

```shell
python run_framework.py dashboard-queries --file Dashboard_Queries.sql
```

This command needs no workspace connection and refuses to overwrite an existing file. There is no second set of DEV catalog literals to edit. **This release does not rewrite or publish the existing dashboard**, attest ABAC enforcement, or collect/test policy/UDF definitions. The separate policy review remains applicable. Collate glossary synchronization/reconciliation in the existing dashboard also remains separate; the current Raw glossary feed previously had zero Raw candidates, so it is not treated as gold data here.

## Permissions, environment portability and cutover

Use a separate output schema/prefix, workload identity and approved warehouse per environment. Change source catalogs, mapping table, output bindings and notifications in TOML. Rules/taxonomy are explicit IFBI defaults, not universal labels. No DEV group names are embedded in the classifier. Collector identity and scope hashes are checked against the baseline; a changed scope/identity requires a reviewed separate baseline, not silent reset.

The collector needs metadata/reference SELECT, the existing warehouse/API entitlement and USE/CREATE/MODIFY rights on its own output objects. Native alert creation/update, Jobs submit/get and relevant run-as privileges are required for integrated notifications. Use narrow source access; it needs no business-table value reads, ASSIGN TAG or policy/UDF mutation privileges. The package creates no warehouse, cluster, catalog, schema, group or grants. Existing inherited privileges apply; deploy the journal only to an approved restricted schema.

The shared journal contains review/control data and learned vocabulary. Separate runner, steward and model-approver credentials operationally and protect journal-write authority; a principal with unrestricted journal writes can falsify decisions. This release does not provision IAM or claim an application-only review flag is an authorization boundary. Native alert identities need read access to the managed views; ordinary dashboard users need only the approved views.

Leave the working Step 2 monitor unchanged while validating this framework. Before routine cutover, compare the same scope and confirm first email, failure alert and recovery. Then pause the earlier collector/changes alert through the approved change process to avoid duplicate notification streams. Historical baselines differ; this framework starts one new baseline and does not silently migrate prior incidents. Keep the same stable metadata-reader identity afterward.

## Failures, retries, cost and retained history

- The warehouse API reads every inline result chunk and rejects truncation/incomplete results. It never downloads external result links. Reduce scope or raise reviewed limits if results exceed the configured budget.
- Journal records stage under a run ID. One final RUN marker publishes that snapshot; current views ignore incomplete attempts. A retry of an already committed latest run reuses it and retries notification, not collection.
- A partially staged unpublished attempt requires a new run ID. It is not mixed with a fresh capture. A later writer is detected before publication. One scheduler across hosts remains mandatory.
- Use `--run-id YOUR_STABLE_SCHEDULER_RUN_ID` for controlled retries; IDs must be unique per actual collection attempt. Native notification submissions use an idempotency token derived from selected notice IDs.
- An alert job failure/unknown status does not acknowledge notices. A successful evaluation receipt is not evidence of recipient delivery. Notification delivery may be at least once after operational recovery; notice IDs support investigation/deduplication.
- Historical snapshots and review/model lineage are append-only in this release. **There is no automatic purge or VACUUM.** Agree retention and Delta maintenance before long-running production operation. Protect active state, unresolved notices, reviewed decisions and model lineage when designing archival. Track journal bytes and warehouse/Python time; scope/column/result budgets are enforced, but this is not a cost guarantee.
- Do not delete the journal to clear an error or improve a KPI. A missing schema/large visibility drop fails the collection and retains the last published state. A missing column is evidence loss, not proof of deletion or resolution.

Useful commands:

```shell
python run_framework.py status
python run_framework.py install
python run_framework.py run --run-id FIRST_VALIDATION_01
python -m unittest discover -s tests -v
```

`install` creates owned objects and native alert resources without performing collection. `run` is the normal single iteration; `serve` is the repeating entry point. CLI output is a metadata-safe status summary; sensitive exception text is not printed. Inspect SQL statement IDs and warehouse query history with an authorized operator for detailed failures.

## Validation and deployment status

Local tests cover the complete synthetic collection → review → candidate training → evaluation → explicit approval → incremental inference loop; monitor baseline/grace/visibility behavior; stale/disputed labels; grouped leakage controls; JSON artifact round trips; SQL pagination/truncation; pending receipts; and native notification request definitions. Optional SQLGlot/DuckDB tests parse generated Databricks SQL and execute translated current-view logic against synthetic journal records. These checks do not substitute for live Databricks execution.

Nothing has been deployed to IFBI by this package. Live warehouse permissions, API capability, non-serverless runtime suitability, authentication, native alerts and receipt behavior need the first controlled deployment. No IFBI model accuracy, email delivery, content-scanning coverage or ABAC enforcement pass is claimed. See `VALIDATION.json` for the packaged local result.

## Primary references

- [Databricks SDK authentication](https://databricks-sdk-py.readthedocs.io/en/stable/authentication.html)
- [SQL Statement Execution API](https://docs.databricks.com/api/statement-execution/v1/statement-execution)
- [Native alert create/update API](https://docs.databricks.com/api/alerts/v2/alert)
- [One-time Jobs run and alert tasks](https://docs.databricks.com/api/jobs/v2/submit-run)
- [TF-IDF vectorizer](https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html)
- [Logistic regression](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)

