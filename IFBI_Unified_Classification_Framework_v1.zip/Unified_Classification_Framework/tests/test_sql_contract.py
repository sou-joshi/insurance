"""Optional developer SQL checks: pip install sqlglot duckdb (not runtime deps)."""
import importlib.util,json,unittest
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
from test_framework import config,MemoryJournal,FakeWarehouse,raw
from ucf.app import run
from ucf.core import table
from ucf.views import definitions,install_views,dashboard_queries
from ucf.warehouse import Warehouse,Journal
from ucf.notifications import alert_definitions

AVAILABLE=importlib.util.find_spec('sqlglot') and importlib.util.find_spec('duckdb')

@unittest.skipUnless(AVAILABLE,'Optional SQLGlot/DuckDB developer dependencies absent')
class SqlContract(unittest.TestCase):
    def test_all_generated_sql_parses(self):
        import sqlglot
        c=config();queries=[]
        class Recorder:
            def sql(self,q,params=None):
                queries.append(q)
                if q.startswith('DESCRIBE DETAIL'):return [{'format':'delta','properties':{'ucf.component':'ucf_v1'}}]
                if 'COUNT(*) AS n' in q:return [{'n':'0'}]
                return []
        w=Recorder();j=Journal(w,c);j.initialize();j.append('run','NOTICE',[('id',{'x':'value'})])
        j.read('ACK',published=False);j.read('SNAPSHOT','run');j.latest_run();install_views(w,c)
        Warehouse.collect(SimpleNamespace(c=c,sql=w.sql));Warehouse.rules(SimpleNamespace(c=c,sql=w.sql))
        queries.extend(d['query_text'] for d in alert_definitions(c).values())
        for q in queries:
            try:sqlglot.parse_one(q,read='databricks',error_level='RAISE')
            except Exception as e:self.fail(str(e)+'\n'+q)
        self.assertGreaterEqual(len(queries),19)
        for q in sqlglot.parse(dashboard_queries(c),read='databricks',error_level='RAISE'):self.assertIsNotNone(q)
    def test_published_views_and_receipts(self):
        import duckdb,sqlglot
        from sqlglot import exp
        c=config();j=MemoryJournal();w=FakeWarehouse([raw()]);run(w,j,c,'success')
        # A staged but unpublished inventory must not appear in any current view.
        j.append('broken','SNAPSHOT',[('invisible',{'asset_key':'invisible'})])
        con=duckdb.connect();con.execute('CREATE TABLE journal(framework_id VARCHAR,run_id VARCHAR,record_type VARCHAR,record_id VARCHAR,observed_at TIMESTAMP,payload_json VARCHAR)')
        stamp=datetime.now(timezone.utc).replace(tzinfo=None)
        for i,r in enumerate(j.records):
            body={k:v for k,v in r.items() if not k.startswith('_')}
            con.execute('INSERT INTO journal VALUES (?,?,?,?,?,?)',[c['environment'],r['_run_id'],r['_kind'],r['_record_id'],stamp+timedelta(microseconds=i),json.dumps(body)])
        def translated(q):
            node=sqlglot.parse_one(q,read='databricks')
            def tr(n):
                if isinstance(n,exp.Table) and n.name==c['table_prefix']+'_journal':
                    return exp.Table(this=exp.to_identifier('journal'),alias=n.args.get('alias'))
                return n
            return node.transform(tr).sql(dialect='duckdb')
        for name,query in definitions(c).items():
            con.execute('CREATE VIEW '+name+' AS '+translated(query))
        self.assertEqual(con.execute('SELECT COUNT(*) FROM current_inventory').fetchone()[0],1)
        self.assertEqual(con.execute('SELECT COUNT(*) FROM pending_notices').fetchone()[0],1)
        notice=j.read('NOTICE','success')[0]['notice_id']
        con.execute('INSERT INTO journal VALUES (?,?,?,?,?,?)',[c['environment'],'ack','ACK',notice,stamp,'{}'])
        self.assertEqual(con.execute('SELECT COUNT(*) FROM pending_notices').fetchone()[0],0)
        self.assertEqual(con.execute('SELECT review_status FROM review_queue').fetchone()[0],'PENDING_STEWARD_REVIEW')

if __name__=='__main__':unittest.main()
